# Quartet distance and sign covariance

Lean 4 supplement aligned to the 22 November 2026 v14 manuscript by
Stefan Grünewald and Libo Huang.

The desktop v8 supplement supplies the graph model, quartet-count
identities, four square families and the proofs of the results in
Sections 2–4. The 142 original Lean files are carried over byte for byte.
The v14 additions are in `CTV14/` and use the original `QDFull.XTree`
and the original coefficients.

Theorem 5.1 is proved for arbitrary finite binary phylogenetic
`XTree` pairs. Theorem 5.2's logarithmic lower inequality is proved for
the attained maximum over finite binary phylogenetic trees on `Fin n`.
For the upper inequality, Lean proves the internal coefficient
formula, the local estimate under the stated mass hypotheses, the
interval counts and the implication from per-depth estimates to the
desired bound. The prefix and suffix tree construction and its
per-depth estimates remain to be connected to those results.

See [the manuscript-to-Lean map](FORMALIZATION_MAP.md) for exact
statements and the verification record.

## Build

The project is pinned to Lean `v4.32.0` and mathlib revision
`81a5d257c8e410db227a6665ed08f64fea08e997`. From this directory,
run the following with Elan and Lake available.

```sh
lake exe cache get
lake --no-cache build
lake env lean verification/AxiomAudit.lean
```

Import `CTV14` to use the formalization. The build also checks the
original Bernoulli supplement and the quartet syntax library. The
audit inspects transitive axiom dependencies of all declarations
loaded from those modules, including private declarations.
