import CTV14
import QuartetDistance
import BernoulliSupplementAudit
import Lean.Util.CollectAxioms

open Lean Elab Command

set_option maxRecDepth 10000
set_option maxHeartbeats 0

/- Inspect every declaration from the supplement modules, including private
   and generated declarations. Select them by source module. -/
run_cmd do
  let env ← getEnv
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let groups := #["QDFull", "QDTauStar", "QuartetV060", "QuartetDistance",
    "BernoulliSupplementAudit", "CTV14"]
  let mut modules : Std.HashSet Name := {}
  let mut count : Nat := 0
  let mut thms : Nat := 0
  let mut newCount : Nat := 0
  let mut newThms : Nat := 0
  let mut bad : Nat := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.header.moduleNames[idx.toNat]!
      let s := mod.toString
      if groups.any (fun p => s == p || s.startsWith (p ++ ".")) then
        count := count + 1
        if info.isTheorem then thms := thms + 1
        modules := modules.insert mod
        if s == "CTV14" || s.startsWith "CTV14." then
          newCount := newCount + 1
          if info.isTheorem then newThms := newThms + 1
        let axioms ← collectAxioms name
        let unexpected := axioms.filter (fun ax => !allowed.contains ax)
        if !unexpected.isEmpty then
          bad := bad + 1
          logError m!"Unexpected axiom dependencies for {name}: {unexpected}"
  logInfo m!"AUDIT_TOTAL declarations={count} theorems={thms} modules={modules.size} unexpected={bad}"
  logInfo m!"AUDIT_CTV14 declarations={newCount} theorems={newThms}"
  if count < 1000 ∨ thms < 100 ∨ newThms < 50 then
    throwError "Audit selection unexpectedly small"
  if bad != 0 then
    throwError "Unexpected foundational dependencies"

#check @CTV14.quartetBound_eq_polynomial
#check @CTV14.scaled_leafCentredSquares_eq_leafDistance
#check @CTV14.leafDistanceSum_eq_sum_unordered
#check @CTV14.binaryDeficitFormula
#check @CTV14.quartetDistance_le_shape_bound
#check @CTV14.maximumQuartetDistance_attained
#check @CTV14.log_lower_le_maximumQuartetDeficit
#check @CTV14.centredSquares_eq_internalCoefficients
#check @CTV14.centredSquares_le_childMasses
#check @CTV14.abs_card_Ico_filter_mod_sub_length_div_le_one
#check @CTV14.highDepthBlock_le
#check @CTV14.lowDepthBlock_le
#check @CTV14.maximumQuartetDeficit_le_of_depth_estimates
#check @CTV14.FiniteTreeLaw.expectedDistance_eq_two_thirds
#print axioms CTV14.quartetDistance_le_shape_bound
#print axioms CTV14.log_lower_le_maximumQuartetDeficit
#print axioms CTV14.centredSquares_eq_internalCoefficients
#print axioms CTV14.centredSquares_le_childMasses
#print axioms CTV14.maximumQuartetDeficit_le_of_depth_estimates
#print axioms QDTauStar.populationTauStar_eq_zero_iff_coordinatesIndependent
