import QDFull

/-!
Reindexing the v8 coefficient set at a trivalent centre. The centre
itself carries no mass, leaving the two orders of the complementary
branches in the coefficient sum.
-/

namespace CTV14

open QDFull
open scoped BigOperators

variable {X V : Type*} [Fintype X] [Fintype V]

theorem sum_indexI_trivalent {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (u t a b : V)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) (f : V × V → M)
    (hf₁ : ∀ z, f (u, z) = 0) (hf₂ : ∀ z, f (z, u) = 0) :
    (∑ z ∈ T.indexIFinset t u, f z) = f (a, b) + f (b, a) := by
  classical
  have hAdj (z : V) : T.graph.Adj u z ↔ z = t ∨ z = a ∨ z = b := by
    rw [← T.mem_neighborFinset, hN]
    simp
  have hmem (x y : V) : (x, y) ∈ T.indexIFinset t u ↔
      (x = u ∨ ((x = t ∨ x = a ∨ x = b) ∧ x ≠ t)) ∧
      (y = u ∨ y = t ∨ y = a ∨ y = b) ∧
      (x = u ∨ (y ≠ t ∧ y ≠ x)) := by
    rw [T.mem_indexIFinset, T.mem_indexI, T.mem_neighborsAwayPlus, T.mem_neighborsPlus,
      hAdj, hAdj]
  have hsubset : ({(a, b), (b, a)} : Finset (V × V)) ⊆ T.indexIFinset t u := by
    intro z hz
    simp only [Finset.mem_insert, Finset.mem_singleton] at hz
    rcases hz with rfl | rfl <;> simp [hmem, Ne.symm hta, Ne.symm htb, hab, Ne.symm hab]
  calc
    _ = ∑ z ∈ ({(a, b), (b, a)} : Finset (V × V)), f z := by
      symm
      apply Finset.sum_subset hsubset
      rintro ⟨x, y⟩ hxy hnot
      by_cases hx : x = u
      · exact hx ▸ hf₁ y
      · by_cases hy : y = u
        · exact hy ▸ hf₂ x
        · simp only [hmem, Finset.mem_insert, Finset.mem_singleton, Prod.mk.injEq] at hxy hnot
          grind
    _ = _ := by simp [Finset.sum_insert, hab]

theorem sum_branchIndices_trivalent {M : Type*} [AddCommMonoid M]
    (T : XTree X V) (u t a b : V)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b)
    (f : V → M) (hf : f u = 0) :
    (∑ z ∈ T.branchIndices u, f z) = f t + f a + f b := by
  classical
  have hI : T.branchIndices u = insert u (T.neighborFinset u) := by
    ext v
    simp [T.mem_branchIndices]
  have hself : u ∉ T.neighborFinset u := by simp
  rw [hI, Finset.sum_insert hself, hf, zero_add, hN]
  simp [Finset.sum_insert, hta, htb, hab, add_assoc]

theorem neighbour_mass_sum_trivalent (T : XTree X V) (hT : T.IsPhylogenetic)
    (u t a b : V) (hu : ¬ T.IsLeaf u)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    T.rowMass t u t + T.rowMass t u a + T.rowMass t u b = 1 := by
  have hcentre : T.rowMass t u u = 0 := by
    simp [XTree.rowMass, hT.labelFiber_eq_empty_of_not_leaf T hu, normalizedCard]
  rw [← sum_branchIndices_trivalent T u t a b hN hta htb hab _ hcentre]
  exact sum_rowMass_allBranches T t u

theorem exists_ordered_neighbor_triple [LinearOrder V]
    (T : XTree X V) (hT : T.IsBinaryPhylogenetic) {u : V} (hu : ¬ T.IsLeaf u) :
    letI := Classical.decEq V
    ∃ a b c : V, a < b ∧ b < c ∧ T.neighborFinset u = {a, b, c} := by
  classical
  letI : DecidableEq V := Classical.decEq V
  have hk : (T.neighborFinset u).card = 3 := by
    rw [XTree.card_neighborFinset, hT.2 u hu]
  let e := (T.neighborFinset u).orderIsoOfFin hk
  refine ⟨e 0, e 1, e 2, e.strictMono (by decide : (0 : Fin 3) < 1),
    e.strictMono (by decide : (1 : Fin 3) < 2), ?_⟩
  ext z
  simp only [Finset.mem_insert, Finset.mem_singleton]
  constructor
  · intro hz
    obtain ⟨k, hk'⟩ := e.surjective ⟨z, hz⟩
    have hval : ((e k : T.neighborFinset u) : V) = z := congrArg Subtype.val hk'
    fin_cases k
    · exact Or.inl hval.symm
    · exact Or.inr (Or.inl hval.symm)
    · exact Or.inr (Or.inr hval.symm)
  · rintro (rfl | rfl | rfl)
    · exact (e 0).2
    · exact (e 1).2
    · exact (e 2).2

end CTV14
