import CTV14.DepthSummation
import CTV14.LocalUpperBound

/-!
The high- and low-depth block estimates from the pointwise mass and
contrast bounds in Theorem 5.2.
-/

namespace CTV14

open scoped BigOperators

variable {U W : Type*} (rows : Finset U) (cols : Finset W)
  (p : U → ℝ) (s : W → ℝ)

private theorem sum_parent_mass_products_le
    (hs : ∀ w ∈ cols, 0 ≤ s w)
    (hpSum : (∑ u ∈ rows, p u) ≤ 1) (hsSum : (∑ w ∈ cols, s w) ≤ 1) :
    (∑ u ∈ rows, ∑ w ∈ cols, p u * s w) ≤ 1 := by
  simp_rw [← Finset.mul_sum, ← Finset.sum_mul]
  simpa only [mul_one] using
    mul_le_mul hpSum hsSum (Finset.sum_nonneg hs) (by norm_num : (0 : ℝ) ≤ 1)

/-- The estimate for one depth pair in the range (d+e\ge m-1). -/
theorem highDepthBlock_le (d e : ℕ) (μ : ℝ) (hμ : 0 ≤ μ) (B F : U → W → ℝ)
    (hp : ∀ u ∈ rows, 0 ≤ p u) (hs : ∀ w ∈ cols, 0 ≤ s w)
    (hB : ∀ u ∈ rows, ∀ w ∈ cols, 0 ≤ B u w ∧ B u w ≤ 2 * μ)
    (hpd : ∀ u ∈ rows, p u ≤ 2 * depthWeight d)
    (hse : ∀ w ∈ cols, s w ≤ 2 * depthWeight e)
    (hpSum : (∑ u ∈ rows, p u) ≤ 1) (hsSum : (∑ w ∈ cols, s w) ≤ 1)
    (hBSum : (∑ u ∈ rows, ∑ w ∈ cols, B u w) ≤ 1)
    (hF : ∀ u ∈ rows, ∀ w ∈ cols,
      F u w ≤ 378 * (p u * s w * (B u w + p u * s w)^2)) :
    (∑ u ∈ rows, ∑ w ∈ cols, F u w) ≤
      12096 * (μ * depthWeight (d + e) + depthWeight (d + e)^2) := by
  let q := depthWeight (d + e)
  have hq : 0 ≤ q := pow_nonneg (by norm_num) _
  have hpoint (u : U) (hu : u ∈ rows) (w : W) (hw : w ∈ cols) :
      F u w ≤ 12096 * (μ * q * B u w + q^2 * (p u * s w)) := by
    let a := p u * s w
    let b := B u w
    have ha : 0 ≤ a := mul_nonneg (hp u hu) (hs w hw)
    have hb : 0 ≤ b := (hB u hu w hw).1
    have ha' : a ≤ 4 * q := by
      have H := mul_le_mul (hpd u hu) (hse w hw) (hs w hw)
        (show 0 ≤ 2 * depthWeight d by unfold depthWeight; positivity)
      have hq' : q = depthWeight d * depthWeight e := by simp [q, depthWeight, pow_add]
      nlinarith only [H, hq']
    have hb' : b ≤ 2 * μ := (hB u hu w hw).2
    have h₁ := mul_le_mul_of_nonneg_left (sq_nonneg (a - b)) ha
    have h₂ := mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_right hb' hb) ha
    have h₃ := mul_le_mul_of_nonneg_right ha' (mul_nonneg hμ hb)
    have h₄ := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ ha ha' 2) ha
    have h₅ := mul_nonneg (mul_nonneg hμ hq) hb
    have h := hF u hu w hw
    change F u w ≤ 378 * (a * (b + a)^2) at h
    change F u w ≤ 12096 * (μ * q * b + q^2 * a)
    nlinarith only [h₁, h₂, h₃, h₄, h₅, h]
  refine (Finset.sum_le_sum fun u hu => Finset.sum_le_sum fun w hw => hpoint u hu w hw).trans ?_
  simp only [← Finset.mul_sum, Finset.sum_add_distrib]
  have h₁ := mul_le_mul_of_nonneg_left hBSum (mul_nonneg hμ hq)
  have h₂ := mul_le_mul_of_nonneg_left
    (sum_parent_mass_products_le rows cols p s hs hpSum hsSum) (sq_nonneg q)
  simp only [← Finset.mul_sum] at h₂
  change _ ≤ 12096 * (μ * q + q^2)
  nlinarith only [h₁, h₂]

/-- The estimate for one depth pair in the range (d+e\le m-2).
The exceptional rows can contain at most one truncated interval. -/
theorem lowDepthBlock_le [DecidableEq U] (d : ℕ) (μ : ℝ) (F : U → W → ℝ)
    (exceptional : Finset U) (hcard : exceptional.card ≤ 1)
    (hp : ∀ u ∈ rows, 0 ≤ p u) (hs : ∀ w ∈ cols, 0 ≤ s w)
    (hpd : ∀ u ∈ rows, p u ≤ 2 * depthWeight d)
    (hpSum : (∑ u ∈ rows, p u) ≤ 1) (hsSum : (∑ w ∈ cols, s w) ≤ 1)
    (hF : ∀ u ∈ rows, ∀ w ∈ cols,
      F u w ≤ 378 * (p u * s w * (if u ∈ exceptional then (8 * μ)^2 else (4 * p u * μ)^2))) :
    (∑ u ∈ rows, ∑ w ∈ cols, F u w) ≤
      48384 * (μ^2 * (depthWeight d ^ 2 + depthWeight d)) := by
  let q := depthWeight d
  have hq : 0 ≤ q := pow_nonneg (by norm_num) _
  have hpoint (u : U) (hu : u ∈ rows) (w : W) (hw : w ∈ cols) :
      F u w ≤ (6048 * μ^2 * p u^3 +
        (if u ∈ exceptional then 24192 * μ^2 * p u else 0)) * s w := by
    have h₁ := hF u hu w hw
    have hn := mul_nonneg (sq_nonneg μ) (mul_nonneg (pow_nonneg (hp u hu) 3) (hs w hw))
    by_cases h : u ∈ exceptional
    · rw [if_pos h] at h₁ ⊢
      nlinarith only [h₁, hn]
    · rw [if_neg h] at h₁ ⊢
      nlinarith only [h₁]
  have hrow (u : U) (hu : u ∈ rows) :
      (∑ w ∈ cols, F u w) ≤
        6048 * μ^2 * p u^3 + (if u ∈ exceptional then 24192 * μ^2 * p u else 0) := by
    refine (Finset.sum_le_sum fun w hw => hpoint u hu w hw).trans ?_
    rw [← Finset.mul_sum]
    apply mul_le_of_le_one_right _ hsSum
    apply add_nonneg
    · exact mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _)) (pow_nonneg (hp u hu) 3)
    · split_ifs
      · exact mul_nonneg (mul_nonneg (by norm_num) (sq_nonneg _)) (hp u hu)
      · exact le_rfl
  have hPcube : (∑ u ∈ rows, p u ^ 3) ≤ 4 * q^2 := by
    calc
      _ ≤ ∑ u ∈ rows, 4 * q^2 * p u := by
        refine Finset.sum_le_sum fun u hu => ?_
        have h := mul_le_mul_of_nonneg_right (pow_le_pow_left₀ (hp u hu) (hpd u hu) 2) (hp u hu)
        change p u ^ 2 * p u ≤ (2 * q)^2 * p u at h
        nlinarith only [h]
      _ ≤ _ := by
        rw [← Finset.mul_sum]
        exact mul_le_of_le_one_right (by positivity) hpSum
  have hbad : (∑ u ∈ rows.filter (· ∈ exceptional), p u) ≤ 2 * q := by
    have hsub : rows.filter (· ∈ exceptional) ⊆ exceptional :=
      fun u hu => (Finset.mem_filter.mp hu).2
    have hcard' : ((rows.filter (· ∈ exceptional)).card : ℝ) ≤ 1 := by
      exact_mod_cast (Finset.card_le_card hsub).trans hcard
    calc
      _ ≤ ∑ _u ∈ rows.filter (· ∈ exceptional), 2 * q :=
        Finset.sum_le_sum fun u hu => hpd u (Finset.mem_filter.mp hu).1
      _ ≤ _ := by
        rw [Finset.sum_const, nsmul_eq_mul]
        exact mul_le_of_le_one_left (by positivity) hcard'
  refine (Finset.sum_le_sum hrow).trans ?_
  rw [Finset.sum_add_distrib, ← Finset.sum_filter, ← Finset.mul_sum, ← Finset.mul_sum]
  have h₁ := mul_le_mul_of_nonneg_left hPcube
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 6048) (sq_nonneg μ))
  have h₂ := mul_le_mul_of_nonneg_left hbad
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 24192) (sq_nonneg μ))
  have h₃ := mul_nonneg (sq_nonneg μ) (sq_nonneg q)
  change _ ≤ 48384 * (μ^2 * (q^2 + q))
  nlinarith only [h₁, h₂, h₃]

end CTV14
