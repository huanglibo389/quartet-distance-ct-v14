import QDFull
import CTV14.LeafDistance

/-!
Counting branch-size products in a binary phylogenetic tree. The
three-branch count can be obtained by pairing the two sides of every
edge, without constructing the median of each individual leaf triple.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

/-- Number of taxa in the branch from a centre toward its neighbour. -/
noncomputable def branchSize (T : XTree X V) (v u : V) : ℝ := (T.edgeSide v u).card

private theorem branchSize_add_reverse (T : XTree X V) {u v : V}
    (h : T.graph.Adj u v) :
    branchSize T u v + branchSize T v u = (Fintype.card X : ℝ) := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  unfold branchSize
  rw [T.edgeSide_reverse_eq_compl h]
  exact_mod_cast (Finset.card_add_card_compl (T.edgeSide u v))

private theorem sum_branchSize_internal (T : XTree X V) (hT : T.IsPhylogenetic)
    (v : V) (hv : ¬ T.IsLeaf v) :
    ∑ u ∈ T.neighborFinset v, branchSize T v u = (Fintype.card X : ℝ) := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  have hpart : T.branchIndices v = insert v (T.neighborFinset v) := by
    ext u
    simp [T.mem_branchIndices]
  have hself : v ∉ T.neighborFinset v := by simp
  have hcentre : T.rowMass v v v = 0 := by
    rw [XTree.rowMass, T.rowBlock_center, hT.labelFiber_eq_empty_of_not_leaf T hv]
    simp [normalizedCard]
  have hmass := sum_rowMass_allBranches T v v
  rw [hpart, Finset.sum_insert hself, hcentre, zero_add] at hmass
  calc
    _ = (Fintype.card X : ℝ) * ∑ u ∈ T.neighborFinset v, T.rowMass v v u := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun u hu => ?_
      rw [XTree.rowMass, T.rowBlock_of_adj v ((T.mem_neighborFinset _ _).mp hu)]
      unfold branchSize normalizedCard
      field_simp [show (Fintype.card X : ℝ) ≠ 0 by exact_mod_cast Fintype.card_ne_zero]
    _ = _ := by rw [hmass, mul_one]

private theorem branches_at_leaf (T : XTree X V) (hT : T.IsPhylogenetic)
    (v : V) (hv : T.IsLeaf v) :
    ∃ u, T.neighborFinset v = {u} ∧ branchSize T v u = (Fintype.card X : ℝ) - 1 := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  obtain ⟨x, hx⟩ := hT.2.2 v hv
  subst v
  obtain ⟨u, hu, _⟩ := hT.exists_unique_neighbor_label T x
  have hg : (T.neighborFinset (T.label x)).card = 1 := by
    rw [XTree.card_neighborFinset]
    exact hv
  obtain ⟨u', hu'⟩ := Finset.card_eq_one.mp hg
  have hmem : u ∈ T.neighborFinset (T.label x) := by simpa using hu
  rw [hu', Finset.mem_singleton] at hmem
  subst u'
  refine ⟨u, hu', ?_⟩
  have hh := branchSize_add_reverse T hu.symm
  have hpend := hT.edgeSide_pendant_eq_singleton T x hu
  simp only [branchSize, hpend, Finset.card_singleton, Nat.cast_one] at hh
  linarith [show branchSize T (T.label x) u =
    ((T.edgeSide (T.label x) u).card : ℝ) from rfl]

private theorem sum_neighbour_eq_sum_directed [AddCommMonoid M] (T : XTree X V)
    (f : V → V → M) :
    (∑ v : V, ∑ u ∈ T.neighborFinset v, f v u) =
      ∑ e ∈ T.directedEdgeFinset, f e.1 e.2 := by
  classical
  simp [XTree.neighborFinset, XTree.directedEdgeFinset, XTree.directedEdges, Finset.sum_filter,
    Fintype.sum_prod_type]

/-- The leaves of the tree, indexed here by vertices. -/
noncomputable def leafVertices (T : XTree X V) : Finset V := by
  classical
  exact Finset.univ.filter T.IsLeaf

/-- The internal vertices of the tree. -/
noncomputable def internalVertices (T : XTree X V) : Finset V := by
  classical
  exact Finset.univ.filter fun v => ¬ T.IsLeaf v

theorem leafVertices_eq_map (T : XTree X V) (hT : T.IsPhylogenetic) :
    leafVertices T = Finset.univ.map ⟨T.label, hT.1⟩ := by
  classical
  ext v
  simp only [leafVertices, Finset.mem_map, Finset.mem_filter, Finset.mem_univ, true_and,
    Function.Embedding.coeFn_mk]
  exact ⟨hT.2.2 v, fun ⟨x, hx⟩ => hx ▸ hT.2.1 x⟩

private theorem card_leaf_vertices (T : XTree X V) (hT : T.IsPhylogenetic) :
    (leafVertices T).card = Fintype.card X := by
  rw [leafVertices_eq_map T hT, Finset.card_map, Finset.card_univ]

private def cubicMoment (n x : ℝ) : ℝ := 2 * x^3 - 3 * n * x^2

/-- On an internal vertex, this is \(e_3\) of the three branch sizes. -/
noncomputable def branchProduct (T : XTree X V) (v : V) : ℝ :=
  ∏ u ∈ T.neighborFinset v, branchSize T v u

theorem branchProduct_eq_triple (T : XTree X V) {u t a b : V}
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    branchProduct T u = branchSize T u t * branchSize T u a * branchSize T u b := by
  classical
  unfold branchProduct
  rw [hN]
  simp [Finset.prod_insert, hta, htb, hab, mul_assoc]

private theorem cubicMoment_at_internal (T : XTree X V) (hT : T.IsBinaryPhylogenetic)
    {v : V} (hv : ¬ T.IsLeaf v) :
    ∑ u ∈ T.neighborFinset v, cubicMoment (Fintype.card X : ℝ) (branchSize T v u) =
      6 * branchProduct T v - (Fintype.card X : ℝ)^3 := by
  classical
  have hdegree : (T.neighborFinset v).card = 3 := by
    rw [XTree.card_neighborFinset, hT.2 v hv]
  obtain ⟨a, b, c, hab, hac, hbc, hN⟩ := Finset.card_eq_three.mp hdegree
  have hsum := sum_branchSize_internal T hT.1 v hv
  have hbN : b ∉ ({c} : Finset V) := by simpa using hbc
  have haN : a ∉ ({b, c} : Finset V) := by simp [hab, hac]
  have hsc : branchSize T v a + branchSize T v b + branchSize T v c =
      (Fintype.card X : ℝ) := by
    simpa [hN, Finset.sum_insert haN, Finset.sum_insert hbN, add_assoc] using hsum
  unfold branchProduct
  rw [hN, Finset.sum_insert haN, Finset.sum_insert hbN,
    Finset.prod_insert haN, Finset.prod_insert hbN, Finset.sum_singleton, Finset.prod_singleton]
  rw [← hsc]
  unfold cubicMoment
  ring

/-- Summing the products of the three branch sizes over internal
vertices counts precisely \(n(n-1)(n-2)/6\) triples. -/
theorem sum_internal_branchProduct (T : XTree X V) (hT : T.IsBinaryPhylogenetic) :
    (∑ v ∈ internalVertices T, branchProduct T v) =
      (Fintype.card X : ℝ) * ((Fintype.card X : ℝ) - 1) *
        ((Fintype.card X : ℝ) - 2) / 6 := by
  classical
  let n : ℝ := Fintype.card X
  let L := leafVertices T
  let I := internalVertices T
  let moment v := ∑ u ∈ T.neighborFinset v, cubicMoment n (branchSize T v u)
  letI : LinearOrder V := LinearOrder.lift' (Fintype.equivFin V) (Fintype.equivFin V).injective
  have hL : (L.card : ℝ) = n := by
    exact congrArg (fun k : ℕ => (k : ℝ)) (card_leaf_vertices T hT.1)
  have hIL : (I.card : ℝ) + n = (Fintype.card V : ℝ) := by
    have h := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset V)) T.IsLeaf
    rw [Finset.card_univ] at h
    have h' : (L.card : ℝ) + (I.card : ℝ) = (Fintype.card V : ℝ) := by exact_mod_cast h
    linarith
  have hE : (T.canonicalEdgeFinset.card : ℝ) = (I.card : ℝ) + n - 1 := by
    have h := Fintype.card_congr T.canonicalEdgeEquivEdgeSet
    rw [Fintype.card_coe, ← SimpleGraph.edgeFinset_card] at h
    have hn : T.canonicalEdgeFinset.card + 1 = Fintype.card V := by
      rw [h, T.isTree.card_edgeFinset]
    have hr : (T.canonicalEdgeFinset.card : ℝ) + 1 = (Fintype.card V : ℝ) := by exact_mod_cast hn
    linarith
  have hsum : (∑ v : V, moment v) = -(T.canonicalEdgeFinset.card : ℝ) * n^3 := by
    unfold moment
    rw [sum_neighbour_eq_sum_directed, T.sum_directedEdge_eq_sum_canonical_with_reverse]
    calc
      _ = ∑ _e ∈ T.canonicalEdgeFinset, -n^3 := by
        refine Finset.sum_congr rfl fun e he => ?_
        have hadj := ((T.mem_canonicalEdgeFinset _ _).mp he).1
        have heq : branchSize T e.2 e.1 = n - branchSize T e.1 e.2 := by
          have h := branchSize_add_reverse T hadj
          change branchSize T e.1 e.2 + branchSize T e.2 e.1 = n at h
          linarith
        change cubicMoment n (branchSize T e.1 e.2) +
          cubicMoment n (branchSize T e.2 e.1) = _
        rw [heq]
        unfold cubicMoment
        ring
      _ = _ := by rw [Finset.sum_const, nsmul_eq_mul]; ring
  have hLeafSum : (∑ v ∈ L, moment v) = n * cubicMoment n (n - 1) := by
    calc
      _ = ∑ _v ∈ L, cubicMoment n (n - 1) := by
        refine Finset.sum_congr rfl fun v hv => ?_
        obtain ⟨u, hu, hsize⟩ := branches_at_leaf T hT.1 v ((Finset.mem_filter.mp hv).2)
        unfold moment
        rw [hu, Finset.sum_singleton, hsize]
      _ = _ := by rw [Finset.sum_const, nsmul_eq_mul, hL]
  have hInternalSum : (∑ v ∈ I, moment v) =
      6 * (∑ v ∈ I, branchProduct T v) - (I.card : ℝ) * n^3 := by
    calc
      _ = ∑ v ∈ I, (6 * branchProduct T v - n^3) := by
        refine Finset.sum_congr rfl fun v hv => ?_
        exact cubicMoment_at_internal T hT (Finset.mem_filter.mp hv).2
      _ = _ := by rw [Finset.sum_sub_distrib, ← Finset.mul_sum, Finset.sum_const, nsmul_eq_mul]
  have hsplit : (∑ v ∈ L, moment v) + (∑ v ∈ I, moment v) = ∑ v : V, moment v :=
    Finset.sum_filter_add_sum_filter_not _ _ _
  rw [hLeafSum, hInternalSum, hsum, hE] at hsplit
  unfold cubicMoment at hsplit
  change (∑ v ∈ I, branchProduct T v) = n * (n - 1) * (n - 2) / 6
  linear_combination hsplit / 6

section CutSum

variable [LinearOrder V]

private theorem dist_eq_sum_path_edges (T : XTree X V) (a b : X) :
    (T.graph.dist (T.label a) (T.label b) : ℝ) =
      ∑ e ∈ T.canonicalEdgeFinset, if s(e.1, e.2) ∈ (T.taxonPath a b).edges then 1 else 0 := by
  classical
  let P := (T.taxonPath a b).edges.toFinset
  have hcard : P.card = T.graph.dist (T.label a) (T.label b) := by
    change (T.taxonPath a b).edges.toFinset.card = _
    rw [List.toFinset_card_of_nodup
      (SimpleGraph.Walk.edges_nodup_of_support_nodup (T.taxonPath_isPath a b).support_nodup),
      SimpleGraph.Walk.length_edges]
    exact T.vertexPath_length_eq_dist _ _
  let edgeMap (e : V × V) : Sym2 V := s(e.1, e.2)
  have hImage : T.canonicalEdgeFinset.image edgeMap = T.graph.edgeFinset := by
    ext e
    constructor
    · rintro he
      obtain ⟨uv, huv, rfl⟩ := Finset.mem_image.mp he
      exact SimpleGraph.mem_edgeFinset.mpr (T.canonicalEdgeToEdgeSet ⟨uv, huv⟩).2
    · intro he
      let e' : T.graph.edgeSet := ⟨e, SimpleGraph.mem_edgeFinset.mp he⟩
      obtain ⟨uv, huv⟩ := T.canonicalEdgeToEdgeSet_surjective e'
      exact Finset.mem_image.mpr ⟨uv.1, uv.2, congrArg Subtype.val huv⟩
  have hinj : Set.InjOn edgeMap (↑T.canonicalEdgeFinset : Set (V × V)) := by
    intro e he f hf h
    exact congrArg Subtype.val
      (T.canonicalEdgeToEdgeSet_injective (a₁ := ⟨e, he⟩) (a₂ := ⟨f, hf⟩) (Subtype.ext h))
  have hsub : P ⊆ T.graph.edgeFinset := by
    intro e he
    exact SimpleGraph.mem_edgeFinset.mpr
      ((T.taxonPath a b).edges_subset_edgeSet (List.mem_toFinset.mp he))
  calc
    _ = (P.card : ℝ) := by rw [hcard]
    _ = ∑ _e ∈ P, (1 : ℝ) := by simp [nsmul_eq_mul]
    _ = ∑ e ∈ P, (if e ∈ (T.taxonPath a b).edges then 1 else 0 : ℝ) := by
      exact Finset.sum_congr rfl fun e he => (if_pos (List.mem_toFinset.mp he)).symm
    _ = ∑ e ∈ T.graph.edgeFinset, (if e ∈ (T.taxonPath a b).edges then 1 else 0 : ℝ) := by
      apply Finset.sum_subset hsub
      intro e _ he
      exact if_neg (he ∘ List.mem_toFinset.mpr)
    _ = _ := by rw [← hImage, Finset.sum_image hinj]

private noncomputable def oppositeIndicator (A B : Finset X) (x y : X) : ℝ := by
  classical
  exact if (x ∈ A ∧ y ∈ B) ∨ (x ∈ B ∧ y ∈ A) then 1 else 0

private theorem sum_opposite_indicators (A B : Finset X) (hAB : Disjoint A B) :
    (∑ x : X, ∑ y : X, oppositeIndicator A B x y) =
        2 * (A.card : ℝ) * (B.card : ℝ) := by
  classical
  have hA :
      (∑ y : X, if y ∈ A then (1 : ℝ) else 0) = A.card := by
    rw [← Finset.sum_filter]
    simp [nsmul_eq_mul]
  have hB : (∑ y : X, if y ∈ B then (1 : ℝ) else 0) = B.card := by
    rw [← Finset.sum_filter]
    simp [nsmul_eq_mul]
  have hk (x : X) :
      (∑ y : X, oppositeIndicator A B x y) =
      (if x ∈ A then (B.card : ℝ) else 0) + (if x ∈ B then (A.card : ℝ) else 0) := by
    unfold oppositeIndicator
    by_cases hxA : x ∈ A
    · have hxB : x ∉ B := fun hb => Finset.disjoint_left.mp hAB hxA hb
      simp [hxA, hxB, hB]
    · by_cases hxB : x ∈ B
      · simp [hxA, hxB, hA]
      · simp [hxA, hxB]
  simp_rw [hk, Finset.sum_add_distrib, ← Finset.sum_filter]
  simp only [Finset.filter_mem_eq_inter, Finset.univ_inter, Finset.sum_const, nsmul_eq_mul]
  ring

/-- The leaf distance sum is the sum of cut-size products over tree edges. -/
theorem leafDistanceSum_eq_edgeProducts (T : XTree X V) :
    leafDistanceSum T =
      ∑ e ∈ T.canonicalEdgeFinset, branchSize T e.1 e.2 * branchSize T e.2 e.1 := by
  classical
  unfold leafDistanceSum
  simp_rw [dist_eq_sum_path_edges]
  rw [Finset.sum_comm]
  simp_rw [Finset.sum_comm (s := (Finset.univ : Finset X)) (t := T.canonicalEdgeFinset)]
  rw [Finset.sum_div]
  refine Finset.sum_congr rfl fun e he => ?_
  have hadj := ((T.mem_canonicalEdgeFinset _ _).mp he).1
  rw [Finset.sum_comm]
  have hterm (x y : X) :
      (if s(e.1, e.2) ∈ (T.taxonPath x y).edges then (1 : ℝ) else 0) =
      oppositeIndicator (T.edgeSide e.1 e.2) (T.edgeSide e.2 e.1) x y := by
    simp [oppositeIndicator, T.edge_mem_taxonPath_iff_opposite_sides hadj]
  simp_rw [hterm]
  rw [sum_opposite_indicators _ _ (T.edgeSide_disjoint_reverse_of_adj hadj)]
  unfold branchSize
  ring

/-- For an internal vertex, this is \(e_2\) of the three branch sizes. -/
noncomputable def branchPairProducts (T : XTree X V) (v : V) : ℝ :=
  (∑ u ∈ T.neighborFinset v, branchSize T v u * branchSize T u v) / 2

omit [LinearOrder V] in
theorem branchPairProducts_eq_triple (T : XTree X V) (hT : T.IsPhylogenetic)
    {u t a b : V} (hu : ¬ T.IsLeaf u)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    branchPairProducts T u = branchSize T u t * branchSize T u a +
      branchSize T u a * branchSize T u b + branchSize T u b * branchSize T u t := by
  classical
  have hAdj (z : V) (hz : z = t ∨ z = a ∨ z = b) : T.graph.Adj u z := by
    rw [← T.mem_neighborFinset, hN]
    simpa using hz
  have hsum := sum_branchSize_internal T hT u hu
  rw [hN] at hsum
  simp [Finset.sum_insert, hta, htb, hab] at hsum
  have hreverse (z : V) (hz : z = t ∨ z = a ∨ z = b) :
      branchSize T z u = (Fintype.card X : ℝ) - branchSize T u z := by
    have h := branchSize_add_reverse T (hAdj z hz)
    linarith only [h]
  unfold branchPairProducts
  rw [hN]
  simp [Finset.sum_insert, hta, htb, hab, hreverse t (Or.inl rfl), hreverse a (Or.inr (Or.inl rfl)),
    hreverse b (Or.inr (Or.inr rfl))]
  rw [← hsum]
  ring

/-- The internal branch-pair sum in the proof of Theorem 5.1. -/
theorem leafDistanceSum_eq_choose_two_add_branchPairProducts
    (T : XTree X V) (hT : T.IsBinaryPhylogenetic) :
    leafDistanceSum T = ((Fintype.card X).choose 2 : ℝ) +
      ∑ v ∈ internalVertices T, branchPairProducts T v := by
  classical
  let n : ℝ := Fintype.card X
  let f (v u : V) := branchSize T v u * branchSize T u v
  let moment v := ∑ u ∈ T.neighborFinset v, f v u
  have hsplit :
      (∑ v ∈ leafVertices T, moment v) + (∑ v ∈ internalVertices T, moment v) =
        ∑ v : V, moment v :=
    Finset.sum_filter_add_sum_filter_not _ _ _
  have hleaf : (∑ v ∈ leafVertices T, moment v) = n * (n - 1) := by
    calc
      _ = ∑ _v ∈ leafVertices T, (n - 1) := by
        refine Finset.sum_congr rfl fun v hv => ?_
        have hv' : T.IsLeaf v := (Finset.mem_filter.mp hv).2
        obtain ⟨u, hu, hsize⟩ := branches_at_leaf T hT.1 v hv'
        unfold moment f
        rw [hu, Finset.sum_singleton]
        have h := branchSize_add_reverse T ((T.mem_neighborFinset _ _).mp
          (by rw [hu]; exact Finset.mem_singleton_self u))
        change branchSize T v u + branchSize T u v = n at h
        change branchSize T v u = n - 1 at hsize
        rw [hsize, show branchSize T u v = 1 by linarith, mul_one]
      _ = _ := by rw [Finset.sum_const, nsmul_eq_mul, card_leaf_vertices T hT.1]
  have hsum : (∑ v : V, moment v) = 2 * leafDistanceSum T := by
    unfold moment
    rw [sum_neighbour_eq_sum_directed, T.sum_directedEdge_eq_sum_canonical_with_reverse,
      leafDistanceSum_eq_edgeProducts, Finset.mul_sum]
    exact Finset.sum_congr rfl fun e _ => by dsimp [f, XTree.reverseEdge]; ring
  rw [hleaf, hsum] at hsplit
  rw [Nat.cast_choose_two]
  simp only [branchPairProducts, ← Finset.sum_div]
  change leafDistanceSum T = n * (n - 1) / 2 + (∑ v ∈ internalVertices T, moment v) / 2
  linear_combination -hsplit / 2

end CutSum

end CTV14
