import CTV14.InternalBranchTable

/-!
A uniform estimate for the actual internal square contribution in
Theorem 5.2. Branch 0 is the complement and branches 1 and 2 are the
two children.
-/

namespace CTV14

open scoped BigOperators

def rowChildMass (A : BranchMassTable) : ℝ := rowTotal A 1 + rowTotal A 2

def colChildMass (A : BranchMassTable) : ℝ := colTotal A 1 + colTotal A 2

def jointChildMass (A : BranchMassTable) : ℝ :=
  A 1 1 + A 1 2 + A 2 1 + A 2 2

private def otherChild (i : Fin 3) : Fin 3 := if i = 1 then 2 else 1

private theorem otherChild_ne_zero (i : Fin 3) : otherChild i ≠ 0 := by
  fin_cases i <;> decide

private theorem child_cases (i : Fin 3) (hi : i ≠ 0) : i = 1 ∨ i = 2 := by
  exact (show ∀ i : Fin 3, i ≠ 0 → i = 1 ∨ i = 2 by decide) i hi

private def twoRowPermanent (A : BranchMassTable) (h i j k : Fin 3) : ℝ :=
  A h j * A i k + A h k * A i j

private theorem twoRowPermanent_swap (A : BranchMassTable) (h i j k : Fin 3) :
    twoRowPermanent A h i j k = twoRowPermanent A i h j k := by
  unfold twoRowPermanent
  ring

private theorem complementPermanent_child (A : BranchMassTable) (i j k : Fin 3) (hi : i ≠ 0) :
    complementPermanent A i j k = twoRowPermanent A (otherChild i) 0 j k := by
  rcases child_cases i hi with rfl | rfl
  · rfl
  · exact twoRowPermanent_swap A 0 1 j k

private theorem complementPermanent_zero (A : BranchMassTable) (j k : Fin 3) :
    complementPermanent A 0 j k = twoRowPermanent A 1 2 j k := rfl

private theorem beta_child (A : BranchMassTable) (i j : Fin 3) (hj : j ≠ 0) :
    internalCoefficient A i j =
      complementPermanent A i 0 (otherChild j) +
      (colTotal A (otherChild j) / colTotal A j) * complementPermanent A i 0 j +
      (colTotal A 0 / colTotal A j) * complementPermanent A i j (otherChild j) := by
  have h₁ : (1 + 1 : Fin 3) = 2 := rfl
  have h₂ : (1 + 2 : Fin 3) = 0 := rfl
  have h₃ : (2 + 1 : Fin 3) = 0 := rfl
  have h₄ : (2 + 2 : Fin 3) = 1 := rfl
  rcases child_cases j hj with rfl | rfl <;>
    (simp only [internalCoefficient, internalEdgeWeight, complementPermanent, otherChild,
      h₁, h₂, h₃, h₄, if_true, if_neg (by decide : (2 : Fin 3) ≠ 1)]; ring)

section Estimates

variable (A : BranchMassTable) (hA : ∀ i j, 0 ≤ A i j)
include hA

local notation "p" => rowChildMass A
local notation "s" => colChildMass A
local notation "B" => jointChildMass A

private theorem row_nonneg (i : Fin 3) : 0 ≤ rowTotal A i :=
  Finset.sum_nonneg fun j _ => hA i j

private theorem col_nonneg (j : Fin 3) : 0 ≤ colTotal A j :=
  Finset.sum_nonneg fun i _ => hA i j

private theorem entry_le_row (i j : Fin 3) : A i j ≤ rowTotal A i :=
  Finset.single_le_sum (fun k _ => hA i k) (Finset.mem_univ j)

private theorem entry_le_col (i j : Fin 3) : A i j ≤ colTotal A j :=
  Finset.single_le_sum (fun k _ => hA k j) (Finset.mem_univ i)

private theorem row_le_child (i : Fin 3) (hi : i ≠ 0) : rowTotal A i ≤ p := by
  rcases child_cases i hi with rfl | rfl
  · unfold rowChildMass
    linarith only [row_nonneg A hA 2]
  · unfold rowChildMass
    linarith only [row_nonneg A hA 1]

private theorem col_le_child (j : Fin 3) (hj : j ≠ 0) : colTotal A j ≤ s := by
  rcases child_cases j hj with rfl | rfl
  · unfold colChildMass
    linarith only [col_nonneg A hA 2]
  · unfold colChildMass
    linarith only [col_nonneg A hA 1]

private theorem child_row_entry_le (i j : Fin 3) (hi : i ≠ 0) : A i j ≤ p :=
  (entry_le_row A hA i j).trans (row_le_child A hA i hi)

private theorem child_col_entry_le (i j : Fin 3) (hj : j ≠ 0) : A i j ≤ s :=
  (entry_le_col A hA i j).trans (col_le_child A hA j hj)

private theorem row_child_entries_le_joint (i : Fin 3) (hi : i ≠ 0) :
    A i 1 + A i 2 ≤ B := by
  rcases child_cases i hi with rfl | rfl
  · unfold jointChildMass
    linarith only [hA 2 1, hA 2 2]
  · unfold jointChildMass
    linarith only [hA 1 1, hA 1 2]

omit hA in
private theorem row_otherChild_entries (i j : Fin 3) (hj : j ≠ 0) :
    A i j + A i (otherChild j) = A i 1 + A i 2 := by
  rcases child_cases j hj with rfl | rfl
  · rfl
  · exact add_comm _ _

omit hA in
private theorem sum_cols (hMass : (∑ i, ∑ j, A i j) = 1) :
    colTotal A 0 + colTotal A 1 + colTotal A 2 = 1 := by
  rw [← Fin.sum_univ_three]
  unfold colTotal
  rwa [Finset.sum_comm]

private theorem col_le_one (hMass : (∑ i, ∑ j, A i j) = 1) (j : Fin 3) :
    colTotal A j ≤ 1 := by
  have h := sum_cols A hMass
  rw [← Fin.sum_univ_three] at h
  rw [← h]
  exact Finset.single_le_sum (fun k _ => col_nonneg A hA k) (Finset.mem_univ j)

private theorem twoRowPermanent_nonneg (a b j k : Fin 3) : 0 ≤ twoRowPermanent A a b j k :=
  add_nonneg (mul_nonneg (hA _ _) (hA _ _)) (mul_nonneg (hA _ _) (hA _ _))

private theorem twoRowPermanent_le_p_col (a b j k : Fin 3) (ha : a ≠ 0) :
    twoRowPermanent A a b j k ≤ p * (colTotal A j + colTotal A k) := by
  unfold twoRowPermanent
  rw [mul_add]
  exact add_le_add
    (mul_le_mul (child_row_entry_le A hA a j ha) (entry_le_col A hA b k) (hA b k)
      (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)))
    (mul_le_mul (child_row_entry_le A hA a k ha) (entry_le_col A hA b j) (hA b j)
      (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2))) |>.trans (le_of_eq (add_comm _ _))

private theorem permanent_le_p_col (i j k : Fin 3) :
    complementPermanent A i j k ≤ p * (colTotal A j + colTotal A k) := by
  by_cases hi : i = 0
  · subst i
    exact twoRowPermanent_le_p_col A hA 1 2 j k (by decide)
  · rw [complementPermanent_child A i j k hi]
    exact twoRowPermanent_le_p_col A hA _ 0 j k (otherChild_ne_zero i)

private theorem beta_zero_le (hMass : (∑ i, ∑ j, A i j) = 1)
    (hc0 : 1 / 3 ≤ colTotal A 0) (i : Fin 3) :
    internalCoefficient A i 0 ≤ 7 * (p * s) := by
  have hp : 0 ≤ p := add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)
  have hsum := sum_cols A hMass
  have hc0' : 0 < colTotal A 0 := by linarith only [hc0]
  have hRatio (j : Fin 3) (hj : j ≠ 0) : colTotal A j / colTotal A 0 ≤ 3 * s := by
    apply (div_le_iff₀ hc0').mpr
    have hm := mul_le_mul_of_nonneg_left hc0
      (show 0 ≤ 3 * s by exact mul_nonneg (by norm_num) (add_nonneg (col_nonneg A hA 1) (col_nonneg A hA 2)))
    linarith only [col_le_child A hA j hj, hm]
  have hp01 : complementPermanent A i 0 1 ≤ p := by
    have h := permanent_le_p_col A hA i 0 1
    have hs : colTotal A 0 + colTotal A 1 ≤ 1 := by linarith only [hsum, col_nonneg A hA 2]
    exact h.trans (by simpa using mul_le_mul_of_nonneg_left hs hp)
  have hp02 : complementPermanent A i 0 2 ≤ p := by
    have h := permanent_le_p_col A hA i 0 2
    have hs : colTotal A 0 + colTotal A 2 ≤ 1 := by linarith only [hsum, col_nonneg A hA 1]
    exact h.trans (by simpa using mul_le_mul_of_nonneg_left hs hp)
  have hperm (j k : Fin 3) : 0 ≤ complementPermanent A i j k := by
    unfold complementPermanent
    exact add_nonneg (mul_nonneg (hA _ _) (hA _ _)) (mul_nonneg (hA _ _) (hA _ _))
  have h₁ := mul_le_mul (hRatio 2 (by decide)) hp01 (hperm 0 1)
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 3) (add_nonneg (col_nonneg A hA 1) (col_nonneg A hA 2)))
  have h₂ := mul_le_mul (hRatio 1 (by decide)) hp02 (hperm 0 2)
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 3) (add_nonneg (col_nonneg A hA 1) (col_nonneg A hA 2)))
  have h₀ : complementPermanent A i 1 2 ≤ p * s := permanent_le_p_col A hA i 1 2
  change complementPermanent A i 1 2 + (colTotal A 2 / colTotal A 0 * complementPermanent A i 0 1 +
    colTotal A 1 / colTotal A 0 * complementPermanent A i 0 2) ≤ _
  linarith only [h₀, h₁, h₂]

private theorem ratio_child_le_three (hs : 0 < s)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (j k : Fin 3) (hj : j ≠ 0) (hk : k ≠ 0) :
    colTotal A k / colTotal A j ≤ 3 := by
  have hj' : 0 < colTotal A j := by linarith only [hs, hbalance j hj]
  apply (div_le_iff₀ hj').mpr
  linarith only [col_le_child A hA k hk, hbalance j hj]

private theorem twoRowPermanent_zero_col_le
    (hMass : (∑ i, ∑ j, A i j) = 1) (a b j : Fin 3) (ha : a ≠ 0) (hj : j ≠ 0) :
    twoRowPermanent A a b 0 j ≤ p * s + A a j := by
  have hp : 0 ≤ p := add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)
  have h₁ := mul_le_mul (child_row_entry_le A hA a 0 ha) (child_col_entry_le A hA b j hj)
    (hA b j) hp
  have h₂ := mul_le_mul_of_nonneg_left ((entry_le_col A hA b 0).trans (col_le_one A hA hMass 0))
    (hA a j)
  unfold twoRowPermanent
  linarith only [h₁, h₂]

private theorem twoRowPermanent_child_cols_div_le
    (hMass : (∑ i, ∑ j, A i j) = 1) (hs : 0 < s)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (a b j k : Fin 3) (hj : j ≠ 0) (hk : k ≠ 0) :
    colTotal A 0 / colTotal A j * twoRowPermanent A a b j k ≤ 3 * (A a j + A a k) := by
  have hj' : 0 < colTotal A j := by linarith only [hs, hbalance j hj]
  have hkp : A b k ≤ 3 * colTotal A j := by
    linarith only [entry_le_col A hA b k, col_le_child A hA k hk, hbalance j hj]
  have h' : twoRowPermanent A a b j k ≤ 3 * colTotal A j * (A a j + A a k) := by
    have h₁ := mul_le_mul_of_nonneg_left hkp (hA a j)
    have h₂ := mul_le_mul_of_nonneg_left (entry_le_col A hA b j) (hA a k)
    have h₃ := mul_nonneg hj'.le (hA a k)
    unfold twoRowPermanent
    nlinarith only [h₁, h₂, h₃]
  calc
    _ ≤ 1 / colTotal A j * twoRowPermanent A a b j k :=
      mul_le_mul_of_nonneg_right (div_le_div_of_nonneg_right (col_le_one A hA hMass 0) hj'.le)
        (twoRowPermanent_nonneg A hA a b j k)
    _ ≤ 1 / colTotal A j * (3 * colTotal A j * (A a j + A a k)) :=
      mul_le_mul_of_nonneg_left h' (by positivity)
    _ = _ := by field_simp [hj'.ne']

private theorem beta_child_le_of_complement_row
    (hMass : (∑ i, ∑ j, A i j) = 1) (hs : 0 < s)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (i j a b : Fin 3) (hj : j ≠ 0) (ha : a ≠ 0)
    (hperm : ∀ k l, complementPermanent A i k l = twoRowPermanent A a b k l) :
    internalCoefficient A i j ≤ 4 * (p * s) + 6 * (A a 1 + A a 2) := by
  let k := otherChild j
  have hk : k ≠ 0 := otherChild_ne_zero j
  have h₁ := twoRowPermanent_zero_col_le A hA hMass a b k ha hk
  have h₂ := mul_le_mul (ratio_child_le_three A hA hs hbalance j k hj hk)
    (twoRowPermanent_zero_col_le A hA hMass a b j ha hj) (twoRowPermanent_nonneg A hA a b 0 j)
    (by norm_num : (0 : ℝ) ≤ 3)
  have h₃ := twoRowPermanent_child_cols_div_le A hA hMass hs hbalance a b j k hj hk
  have hsum : A a j + A a k = A a 1 + A a 2 := row_otherChild_entries A a j hj
  have hk' : 0 ≤ A a k := hA a k
  rw [beta_child A i j hj]
  simp only [hperm, ← show k = otherChild j from rfl]
  linarith only [h₁, h₂, h₃, hsum, hk']

omit hA in
private theorem complement_row (i : Fin 3) :
    ∃ a b : Fin 3, a ≠ 0 ∧ ∀ j k, complementPermanent A i j k = twoRowPermanent A a b j k := by
  by_cases hi : i = 0
  · subst i
    exact ⟨1, 2, by decide, complementPermanent_zero A⟩
  · exact ⟨otherChild i, 0, otherChild_ne_zero i, fun j k => complementPermanent_child A i j k hi⟩

private theorem beta_le_of_dense
    (hMass : (∑ i, ∑ j, A i j) = 1) (hs : 0 < s)
    (hc0 : 1 / 3 ≤ colTotal A 0)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (hdense : B ≤ 4 * (p * s)) (i j : Fin 3) :
    internalCoefficient A i j ≤ 28 * (p * s) := by
  by_cases hj : j = 0
  · subst j
    have hps : 0 ≤ p * s := mul_nonneg (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)) hs.le
    linarith only [beta_zero_le A hA hMass hc0 i, hps]
  · obtain ⟨a, b, ha, hab⟩ := complement_row A i
    have h := beta_child_le_of_complement_row A hA hMass hs hbalance i j a b hj ha hab
    linarith only [h, hdense, row_child_entries_le_joint A hA a ha]

/-- At most one cell in the two child rows and two child columns has mass. -/
def SingleChildCell : Prop :=
  ∃ i j : Fin 3, i ≠ 0 ∧ j ≠ 0 ∧
    ∀ k l, k ≠ 0 → l ≠ 0 → (k, l) ≠ (i, j) → A k l = 0

omit hA in
private theorem joint_eq_occupied {i j : Fin 3} (hi : i ≠ 0) (hj : j ≠ 0)
    (hz : ∀ k l, k ≠ 0 → l ≠ 0 → (k, l) ≠ (i, j) → A k l = 0) :
    B = A i j := by
  rcases child_cases i hi with rfl | rfl <;> rcases child_cases j hj with rfl | rfl <;>
    simp (disch := decide) only [jointChildMass, hz, add_zero, zero_add]

private theorem beta_row_zero_le_of_single (hs : 0 < s)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (hSingle : SingleChildCell A) (j : Fin 3) (hj : j ≠ 0) :
    internalCoefficient A 0 j ≤ 4 * (p * s) := by
  let k := otherChild j
  have hk : k ≠ 0 := otherChild_ne_zero j
  have hp : 0 ≤ p := add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)
  have hcross (l : Fin 3) (hl : l ≠ 0) : twoRowPermanent A 1 2 0 l ≤ p * s := by
    have h₁ := mul_le_mul_of_nonneg_right (child_row_entry_le A hA 1 0 (by decide)) (hA 2 l)
    have h₂ := mul_le_mul_of_nonneg_left (child_row_entry_le A hA 2 0 (by decide)) (hA 1 l)
    have hsum : A 1 l + A 2 l ≤ s := by
      have ht : A 0 l + A 1 l + A 2 l = colTotal A l := by simp [colTotal, Fin.sum_univ_three]
      linarith only [ht, hA 0 l, col_le_child A hA l hl]
    have h₃ := mul_le_mul_of_nonneg_left hsum hp
    unfold twoRowPermanent
    nlinarith only [h₁, h₂, h₃]
  obtain ⟨i₀, j₀, _, _, hz⟩ := hSingle
  have hprod : twoRowPermanent A 1 2 j k = 0 := by
    by_cases h : i₀ = 1
    · have hz₂ (l : Fin 3) (hl : l ≠ 0) : A 2 l = 0 :=
        hz 2 l (by decide) hl (fun he => (by decide : (2 : Fin 3) ≠ 1) ((congrArg Prod.fst he).trans h))
      simp [twoRowPermanent, hz₂ j hj, hz₂ k hk]
    · have hz₁ (l : Fin 3) (hl : l ≠ 0) : A 1 l = 0 :=
        hz 1 l (by decide) hl (fun he => h (congrArg Prod.fst he).symm)
      simp [twoRowPermanent, hz₁ j hj, hz₁ k hk]
  have hr := mul_le_mul (ratio_child_le_three A hA hs hbalance j k hj hk)
    (hcross j hj) (twoRowPermanent_nonneg A hA 1 2 0 j) (by norm_num : (0 : ℝ) ≤ 3)
  rw [beta_child A 0 j hj]
  simp only [complementPermanent_zero, ← show k = otherChild j from rfl, hprod, mul_zero, add_zero]
  linarith only [hcross k hk, hr]

omit hA in
private theorem sq_le_of_abs_le {x z : ℝ} (h : |x| ≤ z) : x^2 ≤ z^2 := by
  rw [← sq_abs]
  exact pow_le_pow_left₀ (abs_nonneg x) h 2

omit hA in
private theorem weighted_beta_le (hps : 0 ≤ p * s) {Z : ℝ}
    (hZ : ∀ i j : Fin 3, |centredEntry A i j| ≤ Z)
    (i j : Fin 3) (hβ : internalCoefficient A i j ≤ 28 * (p * s)) :
    internalCoefficient A i j * centredEntry A i j ^ 2 ≤ 28 * (p * s * Z^2) := by
  have h := mul_le_mul hβ (sq_le_of_abs_le (hZ i j)) (sq_nonneg _)
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 28) hps)
  simpa only [mul_assoc] using h

private theorem weighted_beta_le_of_single
    (hMass : (∑ i, ∑ j, A i j) = 1) (hs : 0 < s)
    (hc0 : 1 / 3 ≤ colTotal A 0)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (hdense : 4 * (p * s) < B) (hSingle : SingleChildCell A)
    (Z : ℝ) (hZ : ∀ i j : Fin 3, |centredEntry A i j| ≤ Z)
    (i j : Fin 3) :
    internalCoefficient A i j * centredEntry A i j ^ 2 ≤ 28 * (p * s * Z^2) := by
  have hps : 0 ≤ p * s := mul_nonneg (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)) hs.le
  by_cases hj : j = 0
  · subst j
    exact weighted_beta_le A hps hZ i 0 (by linarith only [beta_zero_le A hA hMass hc0 i, hps])
  by_cases hi : i = 0
  · subst i
    exact weighted_beta_le A hps hZ 0 j
      (by linarith only [beta_row_zero_le_of_single A hA hs hbalance hSingle j hj, hps])
  obtain ⟨i₀, j₀, hi₀, hj₀, hz⟩ := hSingle
  let M := A (otherChild i) 1 + A (otherChild i) 2
  have hMb : M ≤ B := row_child_entries_le_joint A hA (otherChild i) (otherChild_ne_zero i)
  have hβ : internalCoefficient A i j ≤ 4 * (p * s) + 6 * M :=
    beta_child_le_of_complement_row A hA hMass hs hbalance i j (otherChild i) 0 hj
      (otherChild_ne_zero i) (fun _ _ => complementPermanent_child A i _ _ hi)
  have hchild (a b : Fin 3) (ha : a ≠ 0) (hb : b ≠ 0) :
      rowTotal A a * colTotal A b ≤ p * s :=
    mul_le_mul (row_le_child A hA a ha) (col_le_child A hA b hb) (col_nonneg A hA b)
      (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2))
  by_cases hrow : i = i₀
  · have hother : otherChild i ≠ i :=
      (show ∀ i : Fin 3, i ≠ 0 → otherChild i ≠ i by decide) i hi
    have hother0 : otherChild i ≠ i₀ := fun h => hother (h.trans hrow.symm)
    have hzero (l : Fin 3) (hl : l ≠ 0) : A (otherChild i) l = 0 :=
      hz _ _ (otherChild_ne_zero i) hl (fun h => hother0 (congrArg Prod.fst h))
    have hM : M = 0 := by simp [M, hzero, show (1 : Fin 3) ≠ 0 by decide,
      show (2 : Fin 3) ≠ 0 by decide]
    exact weighted_beta_le A hps hZ i j (by linarith only [hβ, hM, hps])
  have hz' : A i j = 0 := hz i j hi hj (fun h => hrow (congrArg Prod.fst h))
  have hsmall : |centredEntry A i j| ≤ p * s := by
    have hsign := mul_nonneg (row_nonneg A hA i) (col_nonneg A hA j)
    unfold centredEntry
    rw [hz', zero_sub, abs_neg, abs_of_nonneg hsign]
    exact hchild i j hi hj
  have hdiff : B - p * s ≤ Z := by
    have he := joint_eq_occupied A hi₀ hj₀ hz
    linarith only [he, hchild i₀ j₀ hi₀ hj₀, le_abs_self (centredEntry A i₀ j₀), hZ i₀ j₀,
      show centredEntry A i₀ j₀ = A i₀ j₀ - rowTotal A i₀ * colTotal A j₀ from rfl]
  have hprod : B * (p * s) ≤ Z^2 := by
    have hnonneg : 0 ≤ B := by linarith only [hdense, hps]
    have hz₁ : 0 ≤ 2 * (p * s) := by linarith only [hps]
    have hz₂ : 2 * (p * s) ≤ Z := by linarith only [hdiff, hdense, hps]
    have hz₃ : B / 2 ≤ Z := by linarith only [hdiff, hdense, hps]
    have hm := mul_le_mul hz₂ hz₃ (by linarith only [hnonneg] : 0 ≤ B / 2)
      (hz₁.trans hz₂)
    nlinarith only [hm]
  have hM : 0 ≤ M := add_nonneg (hA _ _) (hA _ _)
  have h₁ := mul_le_mul_of_nonneg_right hβ (sq_nonneg (centredEntry A i j))
  have h₂ := mul_le_mul_of_nonneg_left (sq_le_of_abs_le (hZ i j))
    (mul_nonneg (by norm_num : (0 : ℝ) ≤ 4) hps)
  have h₃ := mul_le_mul hMb (sq_le_of_abs_le hsmall) (sq_nonneg _) (hM.trans hMb)
  have h₄ := mul_le_mul_of_nonneg_left hprod hps
  have h₅ := mul_nonneg hps (sq_nonneg Z)
  nlinarith only [h₁, h₂, h₃, h₄, h₅]

/-- A normalized table with balanced child columns has the local
(O(ps Z^2)) bound in both the dense and the single-child-cell cases. -/
theorem internalFourFamilies_le_childMasses
    (hMass : (∑ i, ∑ j, A i j) = 1) (hs : 0 < s)
    (hc0 : 1 / 3 ≤ colTotal A 0)
    (hbalance : ∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j)
    (hcases : B ≤ 4 * (p * s) ∨ SingleChildCell A)
    (Z : ℝ) (hZ : ∀ i j : Fin 3, |centredEntry A i j| ≤ Z) :
    internalFourFamilies A ≤ 378 * (p * s * Z^2) := by
  have hps : 0 ≤ p * s := mul_nonneg (add_nonneg (row_nonneg A hA 1) (row_nonneg A hA 2)) hs.le
  have hb (i j : Fin 3) : internalCoefficient A i j * centredEntry A i j ^ 2 ≤
      28 * (p * s * Z^2) := by
    by_cases h : B ≤ 4 * (p * s)
    · exact weighted_beta_le A hps hZ i j (beta_le_of_dense A hA hMass hs hc0 hbalance h i j)
    · exact weighted_beta_le_of_single A hA hMass hs hc0 hbalance (lt_of_not_ge h)
        (hcases.resolve_left h) Z hZ i j
  rw [internalFourFamilies_eq_coefficients A hMass]
  have hsum : (∑ i : Fin 3, ∑ j : Fin 3, internalCoefficient A i j * centredEntry A i j ^ 2) ≤
      ∑ _i : Fin 3, ∑ _j : Fin 3, 28 * (p * s * Z^2) :=
    Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => hb i j))
  norm_num [Finset.sum_const, nsmul_eq_mul] at hsum
  linarith only [hsum]

/-- The high-depth contrast bound (Z\le B+ps). -/
theorem abs_centredEntry_le_joint_add_product
    (hMass : (∑ i, ∑ j, A i j) = 1) (i j : Fin 3) :
    |centredEntry A i j| ≤ B + p * s := by
  have h (a b : Fin 3) : |centredEntry A a b| ≤ A a b + rowTotal A a * colTotal A b := by
    unfold centredEntry
    rw [abs_le]
    have hm := mul_nonneg (row_nonneg A hA a) (col_nonneg A hA b)
    constructor <;> linarith only [hA a b, hm]
  refine (abs_centredEntry_le_child_abs_sum A hMass i j).trans ?_
  unfold jointChildMass rowChildMass colChildMass
  nlinarith only [h 1 1, h 1 2, h 2 1, h 2 2]

omit hA in
/-- The bound for the full contrast table from the four child-cell bounds. -/
theorem abs_centredEntry_le_four_mul_child_bound
    (hMass : (∑ i, ∑ j, A i j) = 1) {δ : ℝ}
    (h : ∀ a b : Fin 3, a ≠ 0 → b ≠ 0 → |centredEntry A a b| ≤ δ) (i j : Fin 3) :
    |centredEntry A i j| ≤ 4 * δ := by
  refine (abs_centredEntry_le_child_abs_sum A hMass i j).trans ?_
  linarith only [h 1 1 (by decide) (by decide), h 1 2 (by decide) (by decide),
    h 2 1 (by decide) (by decide), h 2 2 (by decide) (by decide)]

end Estimates

theorem centredSquares_le_childMasses
    {X V W : Type*} [Fintype X] [Fintype V] [Fintype W] [LinearOrder V] [LinearOrder W]
    (T₁ : QDFull.XTree X V) (T₂ : QDFull.XTree X W) {u : V} {w : W}
    (e : BranchEnumeration T₁ u) (g : BranchEnumeration T₂ w)
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (Z : ℝ) :
    let A := graphBranchTable T₁ T₂ e g
    let p := rowChildMass A
    let s := colChildMass A
    0 < s → 1 / 3 ≤ colTotal A 0 →
      (∀ j : Fin 3, j ≠ 0 → s / 3 ≤ colTotal A j) →
      (jointChildMass A ≤ 4 * (p * s) ∨ SingleChildCell A) →
      (∀ i j : Fin 3, |centredEntry A i j| ≤ Z) →
      centredSquares T₁ T₂ u w ≤ 378 * (p * s * Z^2) := by
  dsimp only
  intro hs hc0 hbalance hcases hZ
  rw [centredSquares_eq_internalFourFamilies T₁ T₂ e g h₁ h₂ hu hw]
  exact internalFourFamilies_le_childMasses _ (graphBranchTable_nonneg T₁ T₂ e g)
    (sum_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw) hs hc0 hbalance hcases Z hZ

end CTV14
