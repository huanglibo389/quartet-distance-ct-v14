import QDFull.PhyloSyntaxBridge

/-!
The expectation in the abstract, for independent finite laws on the
realized binary phylogenetic trees. The v8 three-cycle acts on one
four-taxon set at a time.
-/

namespace CTV14

open QuartetDistance
open scoped BigOperators

abbrev PhyloTree (n : ℕ) := Tree.PhyloTree (Fin n)

/-- A finite law of labelled binary trees. -/
structure FiniteTreeLaw (n : ℕ) where
  support : Finset (PhyloTree n)
  mass : PhyloTree n → ℝ
  nonneg : ∀ T ∈ support, 0 ≤ mass T
  total : ∑ T ∈ support, mass T = 1

namespace FiniteTreeLaw

variable {n : ℕ}

/-- Relabellings preserve the set of outcomes and the mass of each
outcome in that set. -/
def Exchangeable (P : FiniteTreeLaw n) : Prop :=
  ∀ (π : Equiv.Perm (Fin n)) (T : PhyloTree n),
    (Lower.relabel π T ∈ P.support ↔ T ∈ P.support) ∧
      (T ∈ P.support → P.mass (Lower.relabel π T) = P.mass T)

private def relabelEquiv (π : Equiv.Perm (Fin n)) : PhyloTree n ≃ PhyloTree n where
  toFun := Lower.relabel π
  invFun := Lower.relabel π.symm
  left_inv T := by rw [Lower.relabel_trans, Equiv.self_trans_symm, Lower.relabel_refl]
  right_inv T := by rw [Lower.relabel_trans, Equiv.symm_trans_self, Lower.relabel_refl]

/-- The probability of one of the three induced splits on a fixed quartet. -/
noncomputable def topologyMass (P : FiniteTreeLaw n) (q : Upper.Quartet n) (j : Fin 3) : ℝ :=
  ∑ T ∈ P.support, if Upper.displayedTopology T q = j then P.mass T else 0

theorem topologyMass_eq_one_third (P : FiniteTreeLaw n) (hP : P.Exchangeable)
    (q : Upper.Quartet n) (j : Fin 3) :
    P.topologyMass q j = 1 / 3 := by
  classical
  have hcycle (k : Fin 3) : P.topologyMass q k = P.topologyMass q (Lower.topologyCycle k) := by
    let π := Lower.quartetCycle q
    let e := relabelEquiv π
    unfold topologyMass
    refine Finset.sum_equiv e (fun T => (hP π T).1.symm) (fun T hT => ?_)
    change (if Upper.displayedTopology T q = k then P.mass T else 0) =
      if Upper.displayedTopology (Lower.relabel π T) q = Lower.topologyCycle k then
        P.mass (Lower.relabel π T) else 0
    rw [Lower.displayedTopology_quartetCycle T q, (hP π T).2 hT]
    simp
  have heq (k : Fin 3) : P.topologyMass q k = P.topologyMass q 0 := by
    fin_cases k
    · rfl
    · simpa [Lower.topologyCycle] using hcycle 1
    · simpa [Lower.topologyCycle] using (hcycle 0).symm
  have hsum : (∑ k : Fin 3, P.topologyMass q k) = 1 := by
    unfold topologyMass
    rw [Finset.sum_comm]
    simpa using P.total
  simp only [heq, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul,
    Nat.cast_ofNat] at hsum
  rw [heq]
  linarith

/-- The product law represents independent draws. Distances are measured
on the graph realizations used by the v8 bridge. -/
noncomputable def expectedDistance (P Q : FiniteTreeLaw n) : ℝ :=
  ∑ T ∈ P.support, P.mass T * ∑ U ∈ Q.support, Q.mass U *
    (QDFull.quartetDistance (QDFull.PhyloSyntaxBridge.realizedXTree T)
      (QDFull.PhyloSyntaxBridge.realizedXTree U) : ℝ)

private theorem mean_distance_from_fixed (Q : FiniteTreeLaw n) (hQ : Q.Exchangeable)
    (T : PhyloTree n) :
    (∑ U ∈ Q.support, Q.mass U * (Upper.quartetDistance T U : ℝ)) =
      (2 / 3 : ℝ) * n.choose 4 := by
  classical
  have hagree (q : Upper.Quartet n) :
      (∑ U ∈ Q.support, Q.mass U *
        (if Upper.displayedTopology T q ≠ Upper.displayedTopology U q then 1 else 0)) =
        (2 / 3 : ℝ) := by
    have hp := Q.topologyMass_eq_one_third hQ q (Upper.displayedTopology T q)
    unfold topologyMass at hp
    calc
      _ = ∑ U ∈ Q.support, (Q.mass U -
          if Upper.displayedTopology U q = Upper.displayedTopology T q then Q.mass U else 0) := by
        apply Finset.sum_congr rfl
        intro U _
        by_cases h : Upper.displayedTopology U q = Upper.displayedTopology T q
        · simp [h]
        · simp [h, Ne.symm h]
      _ = 2 / 3 := by rw [Finset.sum_sub_distrib, Q.total, hp]; norm_num
  simp_rw [Upper.quartetDistance, Counting.truthDistance, Finset.card_eq_sum_ones,
    Finset.sum_filter, Nat.cast_sum, Nat.cast_ite, Nat.cast_one, Nat.cast_zero,
    Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    _ = ∑ _q : Upper.Quartet n, (2 / 3 : ℝ) :=
      Finset.sum_congr rfl fun q _ => hagree q
    _ = _ := by simp [mul_comm]

theorem expectedDistance_comm (P Q : FiniteTreeLaw n) :
    P.expectedDistance Q = Q.expectedDistance P := by
  simp_rw [expectedDistance, QDFull.PhyloSyntaxBridge.quartetDistance_realized_eq_upper,
    Finset.mul_sum, ← mul_assoc]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro U _
  apply Finset.sum_congr rfl
  intro T _
  have h : Upper.quartetDistance T U = Upper.quartetDistance U T := by
    simp [Upper.quartetDistance, Counting.truthDistance, ne_comm]
  rw [h, mul_comm (P.mass T)]

/-- Independent draws have mean \((2/3)\binom n4\) when at least one of
the finite laws is invariant under relabelling. -/
theorem expectedDistance_eq_two_thirds (P Q : FiniteTreeLaw n)
    (h : P.Exchangeable ∨ Q.Exchangeable) :
    P.expectedDistance Q = (2 / 3 : ℝ) * n.choose 4 := by
  have right (A B : FiniteTreeLaw n) (hB : B.Exchangeable) :
      A.expectedDistance B = (2 / 3 : ℝ) * n.choose 4 := by
    simp_rw [expectedDistance, QDFull.PhyloSyntaxBridge.quartetDistance_realized_eq_upper,
      mean_distance_from_fixed B hB]
    rw [← Finset.sum_mul, A.total, one_mul]
  rcases h with h | h
  · rw [expectedDistance_comm]
    exact right Q P h
  · exact right P Q h

end FiniteTreeLaw

end CTV14
