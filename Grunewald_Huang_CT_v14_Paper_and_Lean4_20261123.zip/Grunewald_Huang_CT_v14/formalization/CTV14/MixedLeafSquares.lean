import CTV14.BranchIndex
import CTV14.CentredSquares
import CTV14.PendantSquares

/-!
Evaluate the mixed leaf and internal contributions using the exact
coefficient sets and the singleton block at a leaf.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV uW

section Mass

variable {X : Type uX} [Fintype X]

noncomputable local instance : DecidableEq X := Classical.decEq X

/-- The normalized mass of one taxon. -/
noncomputable def unitMass (X : Type uX) [Fintype X] : ℝ :=
  1 / Fintype.card X

private noncomputable def memberMass (A : Finset X) (x : X) : ℝ :=
  if x ∈ A then unitMass X else 0

private noncomputable def leafContrast (A : Finset X) (x : X) : ℝ :=
  unitMass X * normalizedCard A - memberMass A x

private theorem singleton_mass_inter (A : Finset X) (x : X) :
    normalizedCard ({x} ∩ A) = memberMass A x := by
  by_cases h : x ∈ A
  · rw [Finset.singleton_inter_of_mem h, memberMass, if_pos h]
    simp [normalizedCard, unitMass]
  · rw [Finset.singleton_inter_of_notMem h, memberMass, if_neg h]
    simp [normalizedCard]

private theorem compl_singleton_mass_inter (A : Finset X) (x : X) :
    normalizedCard (({x} : Finset X)ᶜ ∩ A) = normalizedCard A - memberMass A x := by
  have hsub : ({x} : Finset X) ∩ A ⊆ A := Finset.inter_subset_right
  have h := Finset.card_sdiff_add_card_eq_card hsub
  have hdiff : A \ (({x} : Finset X) ∩ A) = ({x} : Finset X)ᶜ ∩ A := by
    ext y
    simp only [Finset.mem_sdiff, Finset.mem_inter, Finset.mem_compl]
    tauto
  rw [hdiff] at h
  rw [← singleton_mass_inter]
  have hr := congrArg (fun k : ℕ => (k : ℝ) / Fintype.card X) h
  push_cast at hr
  rw [add_div] at hr
  unfold normalizedCard
  linarith only [hr]

private theorem sum_memberMass (A : Finset X) :
    (∑ x : X, memberMass A x) = normalizedCard A := by
  unfold memberMass
  rw [← Finset.sum_filter, Finset.filter_mem_eq_inter, Finset.univ_inter]
  simp [unitMass, normalizedCard, nsmul_eq_mul, div_eq_mul_inv]

private theorem memberMass_mul_square_of_disjoint (A B : Finset X) (h : Disjoint A B)
    (x : X) :
    memberMass A x * (unitMass X * normalizedCard B - memberMass B x)^2 =
      memberMass A x * (unitMass X * normalizedCard B)^2 := by
  by_cases hx : x ∈ A
  · have hxB : x ∉ B := fun hB => Finset.disjoint_left.mp h hx hB
    simp [memberMass, hxB]
  · simp [memberMass, hx]

private theorem memberMass_mul_own_square (A : Finset X) (x : X) :
    memberMass A x * (unitMass X * normalizedCard A - memberMass A x)^2 =
      memberMass A x * (unitMass X * (1 - normalizedCard A))^2 := by
  by_cases hx : x ∈ A
  · simp only [memberMass, if_pos hx]
    ring
  · simp [memberMass, hx]

private theorem sum_cross_mass_mul_square (A B C : Finset X)
    (hAC : Disjoint A C) (hBC : Disjoint B C) :
    (∑ x : X, (normalizedCard B * memberMass A x +
         normalizedCard A * memberMass B x) / 2 * leafContrast C x ^ 2) =
      unitMass X ^ 2 * normalizedCard A * normalizedCard B * normalizedCard C ^ 2 := by
  calc
    _ = ∑ x : X, (normalizedCard B / 2 * (memberMass A x * leafContrast C x ^ 2) +
          normalizedCard A / 2 * (memberMass B x * leafContrast C x ^ 2)) := by
      exact Finset.sum_congr rfl fun x _ => by ring
    _ = _ := by
      simp_rw [leafContrast, memberMass_mul_square_of_disjoint A C hAC,
        memberMass_mul_square_of_disjoint B C hBC, ← mul_assoc, Finset.sum_add_distrib,
        ← Finset.sum_mul, ← Finset.mul_sum, sum_memberMass]
      ring

private theorem sum_own_mass_mul_square (A B C : Finset X) (hc : normalizedCard C ≠ 0) :
    (∑ x : X, normalizedCard A * normalizedCard B * memberMass C x / normalizedCard C *
        leafContrast C x ^ 2) =
      unitMass X ^ 2 * normalizedCard A * normalizedCard B * (1 - normalizedCard C)^2 := by
  calc
    _ = ∑ x : X, normalizedCard A * normalizedCard B / normalizedCard C *
          (memberMass C x * leafContrast C x ^ 2) := by
      exact Finset.sum_congr rfl fun x _ => by ring
    _ = _ := by
      simp_rw [leafContrast, memberMass_mul_own_square, ← mul_assoc, ← Finset.sum_mul,
        ← Finset.mul_sum, sum_memberMass]
      field_simp [hc]

private theorem normalizedCard_compl_singleton (x : X) :
    normalizedCard (({x} : Finset X)ᶜ) = 1 - unitMass X := by
  letI : Nonempty X := ⟨x⟩
  simpa [memberMass, normalizedCard, Fintype.card_ne_zero] using
    compl_singleton_mass_inter (Finset.univ : Finset X) x

private theorem memberMass_mul_of_disjoint (A B : Finset X) (h : Disjoint A B) (x : X) :
    memberMass A x * memberMass B x = 0 := by
  by_cases hx : x ∈ A
  · have hxB : x ∉ B := fun hB => Finset.disjoint_left.mp h hx hB
    simp [memberMass, hxB]
  · simp [memberMass, hx]

end Mass

section Mixed

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W]
  (T₁ : XTree X V) (T₂ : XTree X W)

noncomputable local instance : DecidableEq X := Classical.decEq X

private theorem leafBlock_compl (T : XTree X V) (h : T.IsPhylogenetic) (x : X) :
    T.branchBlock (T.label x) (leafNeighbour T h x) = ({x} : Finset X)ᶜ := by
  letI : Nonempty X := ⟨x⟩
  have ha := adj_leafNeighbour T h x
  rw [T.branchBlock_of_adj ha, T.edgeSide_reverse_eq_compl ha.symm,
    h.edgeSide_pendant_eq_singleton T x ha]

private theorem leafBlock_singleton (T : XTree X V) (h : T.IsPhylogenetic) (x : X) :
    T.branchBlock (T.label x) (T.label x) = ({x} : Finset X) := by
  rw [T.branchBlock_self, labelFiber_eq_singleton T h x]

theorem adj_of_neighbor_triple
    (T : XTree X V) {u t a b : V}
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b}) :
    T.graph.Adj u t ∧ T.graph.Adj u a ∧ T.graph.Adj u b := by
  classical
  simp only [← T.mem_neighborFinset, hN]
  simp

private theorem leafContrast_sum_trivalent (T : XTree X V) (h : T.IsPhylogenetic)
    (x : X) {u t a b : V} (hu : ¬ T.IsLeaf u)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    leafContrast (T.edgeSide u a) x + leafContrast (T.edgeSide u b) x =
      -leafContrast (T.edgeSide u t) x := by
  classical
  have ⟨ht, ha, hb⟩ := adj_of_neighbor_triple T hN
  let f z := memberMass (T.branchBlock u z) x
  have hu0 : f u = 0 := by
    simp [f, h.labelFiber_eq_empty_of_not_leaf T hu, memberMass]
  have hf : f t + f a + f b = unitMass X := by
    rw [← sum_branchIndices_trivalent T u t a b hN hta htb hab f hu0]
    unfold f
    simp_rw [← singleton_mass_inter]
    rw [T.sum_normalizedCard_inter_allBranches]
    simp [normalizedCard, unitMass]
  have hg := neighbour_mass_sum_trivalent T h u t a b hu hN hta htb hab
  dsimp [f] at hf
  unfold XTree.rowMass XTree.rowBlock at hg
  rw [T.branchBlock_of_adj ht, T.branchBlock_of_adj ha, T.branchBlock_of_adj hb] at hf hg
  unfold leafContrast
  linear_combination -hf + unitMass X * hg

private theorem leaf_row_contrast (h₁ : T₁.IsPhylogenetic) (x : X)
    {v w : W} (hvw : T₂.graph.Adj v w) :
    xCoefficient T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x) v w =
      leafContrast (T₂.edgeSide w v) x := by
  have hc (y : W) : T₂.columnBlock v w y = T₂.branchBlock w y := rfl
  rw [xCoefficient_eq_centered_jointMass T₁ T₂ (adj_leafNeighbour T₁ h₁ x).symm hvw]
  unfold jointMass jointBlock XTree.rowMass XTree.columnMass XTree.rowBlock leafContrast
  rw [leafBlock_compl T₁ h₁ x, hc, T₂.branchBlock_of_adj hvw.symm,
    compl_singleton_mass_inter, normalizedCard_compl_singleton]
  ring

private theorem leaf_column_contrast (h₂ : T₂.IsPhylogenetic) (x : X)
    {t u : V} (htu : T₁.graph.Adj t u) :
    xCoefficient T₁ T₂ t u (leafNeighbour T₂ h₂ x) (T₂.label x) =
      leafContrast (T₁.edgeSide u t) x := by
  rw [xCoefficient_eq_centered_jointMass T₁ T₂ htu (adj_leafNeighbour T₂ h₂ x).symm]
  unfold jointMass jointBlock XTree.rowMass XTree.columnMass XTree.columnBlock leafContrast
  rw [leafBlock_compl T₂ h₂ x, T₁.rowBlock_of_adj t htu.symm,
    Finset.inter_comm, compl_singleton_mass_inter, normalizedCard_compl_singleton]
  ring

private theorem leaf_row_jointMass (h₁ : T₁.IsPhylogenetic) (x : X)
    (v w z : W) :
    jointMass T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x) v w (T₁.label x) z =
      memberMass (T₂.branchBlock w z) x := by
  unfold jointMass jointBlock XTree.rowBlock XTree.columnBlock
  rw [leafBlock_singleton T₁ h₁ x, singleton_mass_inter]

private theorem leaf_column_jointMass (h₂ : T₂.IsPhylogenetic) (x : X)
    (t u z : V) :
    jointMass T₁ T₂ t u (leafNeighbour T₂ h₂ x) (T₂.label x) z (T₂.label x) =
      memberMass (T₁.branchBlock u z) x := by
  unfold jointMass jointBlock XTree.rowBlock XTree.columnBlock
  rw [leafBlock_singleton T₂ h₂ x, Finset.inter_comm, singleton_mass_inter]

private theorem leaf_column_other_jointMass (h₂ : T₂.IsPhylogenetic) (x : X)
    (t u z : V) :
    jointMass T₁ T₂ t u (leafNeighbour T₂ h₂ x) (T₂.label x) z (leafNeighbour T₂ h₂ x) =
      normalizedCard (T₁.branchBlock u z) - memberMass (T₁.branchBlock u z) x := by
  unfold jointMass jointBlock XTree.rowBlock XTree.columnBlock
  rw [leafBlock_compl T₂ h₂ x, Finset.inter_comm, compl_singleton_mass_inter]

private theorem leaf_row_q_coefficient
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic) (x : X)
    {w v a b : W} (hw : ¬ T₂.IsLeaf w)
    (hN : letI := Classical.decEq W; T₂.neighborFinset w = {v, a, b})
    (hva : v ≠ a) (hvb : v ≠ b) (hab : a ≠ b) :
    let c z := normalizedCard (T₂.branchBlock w z)
    let p z := memberMass (T₂.branchBlock w z) x
    lemma3CoefficientSum T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x) v w =
      (c b * p a + c a * p b) / 2 + c a * c b * p v / c v := by
  classical
  dsimp only
  let u := T₁.label x
  let t := leafNeighbour T₁ h₁ x
  let c z := T₂.columnMass v w z
  let p z := jointMass T₁ T₂ t u v w u z
  have hvw : T₂.graph.Adj v w := by
    apply SimpleGraph.Adj.symm
    apply (T₂.mem_neighborFinset w v).mp
    rw [hN]
    simp
  have hc0 : c w = 0 := by
    simp [c, XTree.columnMass, h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]
  have hp0 : p w = 0 := by
    simp [p, jointMass, jointBlock, h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]
  unfold lemma3CoefficientSum
  rw [leaf_index_eq_map T₁ h₁ x (adj_leafNeighbour T₁ h₁ x), Finset.sum_map, Finset.sum_comm]
  change (∑ z ∈ T₂.indexIFinset v w, ∑ y ∈ T₁.branchIndices u,
    qCoefficient T₁ T₂ t u v w u y z.1 z.2) = _
  simp_rw [sum_qCoefficient_centralRow T₁ T₂ t u v w _ _ hvw]
  let f (z : W × W) := (1 / 2 : ℝ) * c z.2 * (p z.1 + c z.1 * p v / c v)
  change (∑ z ∈ T₂.indexIFinset v w, f z) = _
  rw [sum_indexI_trivalent T₂ w v a b hN hva hvb hab f]
  · dsimp [f, c, p, t, u]
    rw [leaf_row_jointMass, leaf_row_jointMass, leaf_row_jointMass]
    unfold XTree.columnMass XTree.columnBlock
    ring
  · intro z
    simp [f, hc0, hp0]
  · intro z
    simp [f, hc0]

/-- The (q)-part of the mixed contribution for the edge (v	o w). -/
theorem sum_leaf_internal_qTerm
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    {w v a b : W} (hw : ¬ T₂.IsLeaf w)
    (hN : letI := Classical.decEq W; T₂.neighborFinset w = {v, a, b})
    (hva : v ≠ a) (hvb : v ≠ b) (hab : a ≠ b) :
    let c z := normalizedCard (T₂.edgeSide w z)
    (∑ x : X, qTerm T₁ T₂ (leafNeighbour T₁ h₁ x, T₁.label x) (v, w)) =
      unitMass X ^ 2 * c a * c b * ((1 - c v)^2 + (c v)^2) := by
  classical
  dsimp only
  have ⟨hv, ha, hb⟩ := adj_of_neighbor_triple T₂ hN
  have hAC := T₂.edgeSide_disjoint_sidePair ha.symm hv hva.symm
  have hBC := T₂.edgeSide_disjoint_sidePair hb.symm hv hvb.symm
  have hc := ne_of_gt (T₂.columnMass_pos_of_adj hv.symm)
  unfold XTree.columnMass at hc
  rw [T₂.columnBlock_of_adj v hv] at hc
  simp_rw [qTerm, leaf_row_q_coefficient T₁ T₂ h₁ h₂ _ hw hN hva hvb hab,
    leaf_row_contrast T₁ T₂ h₁ _ hv.symm, T₂.branchBlock_of_adj hv, T₂.branchBlock_of_adj ha,
    T₂.branchBlock_of_adj hb, add_mul, Finset.sum_add_distrib,
    sum_cross_mass_mul_square _ _ _ hAC hBC, sum_own_mass_mul_square _ _ _ hc]
  ring

private theorem leaf_row_s_coefficient
    (h₁ : T₁.IsPhylogenetic) (x : X)
    {w a b : W} (ha : T₂.graph.Adj w a) (hb : T₂.graph.Adj w b) :
    (∑ z ∈ T₁.indexIFinset (leafNeighbour T₁ h₁ x) (T₁.label x),
      sCoefficient T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x) z.1 z.2 a w b) =
      (normalizedCard (T₂.edgeSide w a) * memberMass (T₂.edgeSide w b) x +
        normalizedCard (T₂.edgeSide w b) * memberMass (T₂.edgeSide w a) x) / 2 := by
  classical
  let t := leafNeighbour T₁ h₁ x
  let u := T₁.label x
  unfold sCoefficient
  rw [leaf_index_eq_map T₁ h₁ x (adj_leafNeighbour T₁ h₁ x), Finset.sum_map]
  change (∑ z ∈ T₁.branchIndices u, qCoefficient T₁ T₂ t u a w u z b a) = _
  rw [sum_qCoefficient_centralRow T₁ T₂ t u a w b a ha.symm]
  simp_rw [t, u, leaf_row_jointMass T₁ T₂ h₁ x, T₂.branchBlock_of_adj ha,
    T₂.branchBlock_of_adj hb, XTree.columnMass, T₂.columnBlock_of_adj a ha,
    T₂.columnBlock_of_adj a hb]
  have hc := ne_of_gt (T₂.columnMass_pos_of_adj ha.symm)
  unfold XTree.columnMass at hc
  rw [T₂.columnBlock_of_adj a ha] at hc
  field_simp [hc]

/-- The (s)-part for the column path (a,w,b), with either orientation. -/
theorem sum_leaf_internal_sTerm
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    {w v a b : W} (hw : ¬ T₂.IsLeaf w)
    (hN : letI := Classical.decEq W; T₂.neighborFinset w = {v, a, b})
    (hva : v ≠ a) (hvb : v ≠ b) (hab : a ≠ b) :
    let c z := normalizedCard (T₂.edgeSide w z)
    (∑ x : X, sTerm T₁ T₂ (leafNeighbour T₁ h₁ x, T₁.label x) (a, w, b)) =
      unitMass X ^ 2 * c a * c b * (c v)^2 := by
  classical
  dsimp only
  have ⟨hv, ha, hb⟩ := adj_of_neighbor_triple T₂ hN
  have hAC := T₂.edgeSide_disjoint_sidePair ha.symm hv hva.symm
  have hBC := T₂.edgeSide_disjoint_sidePair hb.symm hv hvb.symm
  calc
    _ = ∑ x : X, (normalizedCard (T₂.edgeSide w b) * memberMass (T₂.edgeSide w a) x +
          normalizedCard (T₂.edgeSide w a) * memberMass (T₂.edgeSide w b) x) / 2 *
          leafContrast (T₂.edgeSide w v) x ^ 2 := by
      refine Finset.sum_congr rfl fun x _ => ?_
      simp only [sTerm, ← Finset.sum_mul,
        leaf_row_s_coefficient T₁ T₂ h₁ x ha hb, leaf_row_contrast T₁ T₂ h₁ x ha.symm,
        leaf_row_contrast T₁ T₂ h₁ x hb.symm,
        leafContrast_sum_trivalent T₂ h₂ x hw hN hva hvb hab, neg_sq, add_comm]
    _ = _ := sum_cross_mass_mul_square _ _ _ hAC hBC

private theorem leaf_column_pair_q_coefficient
    (h₂ : T₂.IsPhylogenetic) (x : X) (t : V)
    {u a b : V} (ha : T₁.graph.Adj u a) (hb : T₁.graph.Adj u b) (hab : a ≠ b) :
    (∑ z ∈ T₂.indexIFinset (leafNeighbour T₂ h₂ x) (T₂.label x),
        qCoefficient T₁ T₂ t u (leafNeighbour T₂ h₂ x) (T₂.label x) a b z.1 z.2) =
      ((normalizedCard (T₁.edgeSide u b) * memberMass (T₁.edgeSide u a) x +
        normalizedCard (T₁.edgeSide u a) * memberMass (T₁.edgeSide u b) x) / 2) /
          (1 - unitMass X) := by
  classical
  let v := leafNeighbour T₂ h₂ x
  let w := T₂.label x
  rw [leaf_index_eq_map T₂ h₂ x (adj_leafNeighbour T₂ h₂ x), Finset.sum_map]
  change (∑ z ∈ T₂.branchIndices w, qCoefficient T₁ T₂ t u v w a b w z) = _
  unfold qCoefficient
  rw [← Finset.sum_mul, ← Finset.mul_sum, sum_columnMass_allBranches, mul_one]
  simp_rw [v, w, leaf_column_jointMass T₁ T₂ h₂ x, leaf_column_other_jointMass T₁ T₂ h₂ x,
    T₁.branchBlock_of_adj ha, T₁.branchBlock_of_adj hb]
  have hcv : T₂.columnMass v w v = 1 - unitMass X := by
    unfold XTree.columnMass XTree.columnBlock
    rw [leafBlock_compl T₂ h₂ x, normalizedCard_compl_singleton]
  rw [hcv]
  have hz := memberMass_mul_of_disjoint _ _
    (T₁.edgeSide_disjoint_sidePair ha.symm hb hab) x
  have hz' := memberMass_mul_of_disjoint _ _
    (T₁.edgeSide_disjoint_sidePair hb.symm ha hab.symm) x
  rw [mul_sub, mul_sub, hz, hz', sub_zero, sub_zero]
  ring

private theorem internal_row_q_coefficient
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic) (x : X)
    {u t a b : V} (hu : ¬ T₁.IsLeaf u)
    (hN : letI := Classical.decEq V; T₁.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    lemma3CoefficientSum T₁ T₂ t u (leafNeighbour T₂ h₂ x) (T₂.label x) =
      (normalizedCard (T₁.edgeSide u b) * memberMass (T₁.edgeSide u a) x +
        normalizedCard (T₁.edgeSide u a) * memberMass (T₁.edgeSide u b) x) /
          (1 - unitMass X) := by
  classical
  have ⟨_, ha, hb⟩ := adj_of_neighbor_triple T₁ hN
  let v := leafNeighbour T₂ h₂ x
  let w := T₂.label x
  let f (z : V × V) := ∑ y ∈ T₂.indexIFinset v w,
    qCoefficient T₁ T₂ t u v w z.1 z.2 y.1 y.2
  have hz (y : W) : jointMass T₁ T₂ t u v w u y = 0 := by
    simp [jointMass, jointBlock, h₁.labelFiber_eq_empty_of_not_leaf T₁ hu, normalizedCard]
  change (∑ z ∈ T₁.indexIFinset t u, f z) = _
  rw [sum_indexI_trivalent T₁ u t a b hN hta htb hab f]
  · dsimp [f, v, w]
    rw [leaf_column_pair_q_coefficient T₁ T₂ h₂ x t ha hb hab,
      leaf_column_pair_q_coefficient T₁ T₂ h₂ x t hb ha hab.symm]
    ring
  · intro z
    simp [f, qCoefficient, hz]
  · intro z
    simp [f, qCoefficient, hz]

/-- The (q)-part of the mixed contribution for the edge (t	o u). -/
theorem sum_internal_leaf_qTerm
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    {u t a b : V} (hu : ¬ T₁.IsLeaf u)
    (hN : letI := Classical.decEq V; T₁.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    let r z := normalizedCard (T₁.edgeSide u z)
    (∑ x : X, qTerm T₁ T₂ (t, u) (leafNeighbour T₂ h₂ x, T₂.label x)) =
      2 * (unitMass X ^ 2 * r a * r b * (r t)^2) / (1 - unitMass X) := by
  classical
  dsimp only
  have ⟨ht, ha, hb⟩ := adj_of_neighbor_triple T₁ hN
  have hAC := T₁.edgeSide_disjoint_sidePair ha.symm ht hta.symm
  have hBC := T₁.edgeSide_disjoint_sidePair hb.symm ht htb.symm
  calc
    _ = ∑ x : X, 2 * (((normalizedCard (T₁.edgeSide u b) * memberMass (T₁.edgeSide u a) x +
          normalizedCard (T₁.edgeSide u a) * memberMass (T₁.edgeSide u b) x) / 2) *
          leafContrast (T₁.edgeSide u t) x ^ 2) / (1 - unitMass X) := by
      refine Finset.sum_congr rfl fun x _ => ?_
      simp only [qTerm, internal_row_q_coefficient T₁ T₂ h₁ h₂ x hu hN hta htb hab,
        leaf_column_contrast T₁ T₂ h₂ x ht.symm]
      ring
    _ = _ := by
      rw [← Finset.sum_div, ← Finset.mul_sum, sum_cross_mass_mul_square _ _ _ hAC hBC]

/-- The (b)-part for the row path (a,u,b), with either orientation. -/
theorem sum_internal_leaf_bTerm
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    {u t a b : V} (hu : ¬ T₁.IsLeaf u)
    (hN : letI := Classical.decEq V; T₁.neighborFinset u = {t, a, b})
    (hta : t ≠ a) (htb : t ≠ b) (hab : a ≠ b) :
    let r z := normalizedCard (T₁.edgeSide u z)
    (∑ x : X, bTerm T₁ T₂ (a, u, b) (leafNeighbour T₂ h₂ x, T₂.label x)) =
      unitMass X ^ 2 * r a * r b * (r t)^2 / (1 - unitMass X) := by
  classical
  dsimp only
  have ⟨ht, ha, hb⟩ := adj_of_neighbor_triple T₁ hN
  have hAC := T₁.edgeSide_disjoint_sidePair ha.symm ht hta.symm
  have hBC := T₁.edgeSide_disjoint_sidePair hb.symm ht htb.symm
  calc
    _ = ∑ x : X, (((normalizedCard (T₁.edgeSide u b) * memberMass (T₁.edgeSide u a) x +
          normalizedCard (T₁.edgeSide u a) * memberMass (T₁.edgeSide u b) x) / 2) *
          leafContrast (T₁.edgeSide u t) x ^ 2) / (1 - unitMass X) := by
      refine Finset.sum_congr rfl fun x _ => ?_
      simp only [bTerm, bCoefficient, ← Finset.sum_mul,
        leaf_column_pair_q_coefficient T₁ T₂ h₂ x a hb ha hab.symm,
        leaf_column_contrast T₁ T₂ h₂ x ha.symm, leaf_column_contrast T₁ T₂ h₂ x hb.symm,
        leafContrast_sum_trivalent T₁ h₁ x hu hN hta htb hab, neg_sq]
      ring
    _ = _ := by
      rw [← Finset.sum_div, sum_cross_mass_mul_square _ _ _ hAC hBC]

end Mixed

end CTV14
