import CTV14.MaximumDeficit
import Mathlib.Algebra.Order.Field.GeomSum

/-!
Sum the two depth ranges in Theorem 5.2. The final implication is
formulated for actual trees with certified bounds on their depth blocks.
-/

namespace CTV14

open QDFull
open scoped BigOperators

/-- The depth factor (2^{-d}). -/
noncomputable def depthWeight (d : ℕ) : ℝ := (1 / 2 : ℝ)^d

private theorem sum_shifted_depthWeight (d m : ℕ) (hd : d < m) :
    (∑ e ∈ (Finset.range m).filter (fun e => m - 1 ≤ d + e), depthWeight (d + e)) ≤
      2 * depthWeight (m - 1) := by
  let shift : ℕ ↪ ℕ := ⟨fun e => d + e, fun _ _ h => Nat.add_left_cancel h⟩
  let S := (Finset.range m).filter (fun e => m - 1 ≤ d + e)
  have hsub : S.map shift ⊆ Finset.Ico (m - 1) (2 * m) := by
    intro k hk
    obtain ⟨e, he, heq⟩ := Finset.mem_map.mp hk
    obtain ⟨hm, hme⟩ := Finset.mem_filter.mp he
    have hlt := Finset.mem_range.mp hm
    change d + e = k at heq
    exact Finset.mem_Ico.mpr ⟨by omega, by omega⟩
  have htail := geom_sum_Ico_le_of_lt_one (m := m - 1) (n := 2 * m)
    (by norm_num : (0 : ℝ) ≤ 1 / 2) (by norm_num : (1 / 2 : ℝ) < 1)
  calc
    _ = ∑ k ∈ S.map shift, depthWeight k := by rw [Finset.sum_map]; rfl
    _ ≤ ∑ k ∈ Finset.Ico (m - 1) (2 * m), depthWeight k :=
      Finset.sum_le_sum_of_subset_of_nonneg hsub (fun k _ _ => pow_nonneg (by norm_num) k)
    _ ≤ _ := by
      unfold depthWeight
      calc
        _ ≤ (1 / 2 : ℝ)^(m - 1) / (1 - 1 / 2) := htail
        _ = _ := by ring

private theorem depthWeight_pred_le {n m : ℕ} (hn : 0 < n) (hm : 0 < m)
    (hnm : n ≤ 2 ^ m) : depthWeight (m - 1) ≤ 2 * (1 / (n : ℝ)) := by
  have hc : (0 : ℝ) < n := by exact_mod_cast hn
  have hp : (0 : ℝ) < (2 : ℝ)^(m - 1) := by positivity
  have hr : (n : ℝ) ≤ (2 : ℝ)^m := by exact_mod_cast hnm
  have he : (2 : ℝ)^m = (2 : ℝ)^(m - 1) * 2 := by
    conv_lhs => rw [← show m - 1 + 1 = m by omega, pow_succ]
  rw [he] at hr
  unfold depthWeight
  rw [div_pow, one_pow, ← mul_div_assoc, mul_one]
  apply (div_le_div_iff₀ hp hc).mpr
  simpa [mul_comm] using hr

private theorem sum_depthWeight_le (m : ℕ) :
    (∑ d ∈ Finset.range m, depthWeight d) ≤ 2 := by
  have h := geom_sum_Ico_le_of_lt_one (m := 0) (n := m)
    (by norm_num : (0 : ℝ) ≤ 1 / 2) (by norm_num : (1 / 2 : ℝ) < 1)
  unfold depthWeight
  norm_num [Nat.Ico_zero_eq_range] at h
  simpa only [one_div] using h

private theorem depthWeight_nonneg (d : ℕ) : 0 ≤ depthWeight d :=
  pow_nonneg (by norm_num) d

private theorem depthWeight_sq_le (d : ℕ) : depthWeight d ^ 2 ≤ depthWeight d := by
  have h := pow_le_one₀ (by norm_num : (0 : ℝ) ≤ 1 / 2)
    (by norm_num : (1 / 2 : ℝ) ≤ 1) (n := d)
  have h' := mul_le_mul_of_nonneg_left h (depthWeight_nonneg d)
  unfold depthWeight at h' ⊢
  simpa only [pow_two, mul_one] using h'

/-- The geometric part of the upper bound, including both depth ranges.
The same constant (C) can be used for the two per-depth estimates. -/
theorem sum_depth_contributions_le
    (n m : ℕ) (hn : 0 < n) (hm : 0 < m) (hnm : n ≤ 2 ^ m)
    (C : ℝ) (hC : 0 ≤ C) (F : ℕ → ℕ → ℝ)
    (hF : ∀ d e, d < m → e < m →
      F d e ≤ C * (if m - 1 ≤ d + e then
        (1 / (n : ℝ)) * depthWeight (d + e) + depthWeight (d + e)^2
      else (1 / (n : ℝ))^2 * (depthWeight d ^ 2 + depthWeight d))) :
    (∑ d ∈ Finset.range m, ∑ e ∈ Finset.range m, F d e) ≤
      16 * C * m * (1 / (n : ℝ))^2 := by
  let μ : ℝ := 1 / n
  have hμ : 0 ≤ μ := by dsimp [μ]; positivity
  have hW (d e : ℕ) (hde : m - 1 ≤ d + e) : depthWeight (d + e) ≤ 2 * μ := by
    have hmono : depthWeight (d + e) ≤ depthWeight (m - 1) := by
      unfold depthWeight
      exact pow_le_pow_of_le_one (by norm_num) (by norm_num) hde
    exact hmono.trans (depthWeight_pred_le hn hm hnm)
  have hcell (d e : ℕ) (hd : d < m) (he : e < m) :
      F d e ≤
        C * (3 * μ * (if m - 1 ≤ d + e then depthWeight (d + e) else 0) +
          2 * μ^2 * depthWeight d) := by
    refine (hF d e hd he).trans (mul_le_mul_of_nonneg_left ?_ hC)
    change (if m - 1 ≤ d + e then μ * depthWeight (d + e) + depthWeight (d + e)^2
      else μ^2 * (depthWeight d^2 + depthWeight d)) ≤ _
    by_cases h : m - 1 ≤ d + e
    · rw [if_pos h, if_pos h]
      have hp := mul_le_mul_of_nonneg_right (hW d e h) (depthWeight_nonneg (d + e))
      have hl := mul_nonneg (sq_nonneg μ) (depthWeight_nonneg d)
      nlinarith only [hp, hl]
    · rw [if_neg h, if_neg h]
      have hp := mul_le_mul_of_nonneg_left (depthWeight_sq_le d) (sq_nonneg μ)
      nlinarith only [hp]
  have hshift (d : ℕ) (hd : d < m) :
      (∑ e ∈ Finset.range m, if m - 1 ≤ d + e then depthWeight (d + e) else 0) ≤ 4 * μ := by
    rw [← Finset.sum_filter]
    have h := sum_shifted_depthWeight d m hd
    linarith only [h, depthWeight_pred_le hn hm hnm]
  have hrow (d : ℕ) (hd : d < m) :
      (∑ e ∈ Finset.range m, F d e) ≤ C * (12 * μ^2 + m * (2 * μ^2 * depthWeight d)) := by
    refine (Finset.sum_le_sum (fun e he => hcell d e hd (Finset.mem_range.mp he))).trans ?_
    simp only [← Finset.mul_sum, Finset.sum_add_distrib, Finset.sum_const, Finset.card_range,
      nsmul_eq_mul]
    apply mul_le_mul_of_nonneg_left _ hC
    have h := mul_le_mul_of_nonneg_left (hshift d hd) (by linarith only [hμ] : 0 ≤ 3 * μ)
    nlinarith only [h]
  refine (Finset.sum_le_sum (fun d hd => hrow d (Finset.mem_range.mp hd))).trans ?_
  simp only [← Finset.mul_sum, ← mul_assoc, Finset.sum_add_distrib,
    Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  have hm' : 0 ≤ (m : ℝ) := Nat.cast_nonneg _
  have H := mul_le_mul_of_nonneg_left (sum_depthWeight_le m)
    (mul_nonneg (mul_nonneg hC hm') (mul_nonneg (by norm_num : (0 : ℝ) ≤ 2) (sq_nonneg μ)))
  change _ ≤ 16 * C * (m : ℝ) * μ^2
  nlinarith only [H]

section TreeBounds

variable {n : ℕ} {V W : Type} [Fintype V] [Fintype W] [LinearOrder V] [LinearOrder W]
  (T₁ : XTree (Fin n) V) (T₂ : XTree (Fin n) W)
  (depth₁ : V → ℕ) (depth₂ : W → ℕ)

/-- The internal contributions at a given pair of original depths. -/
noncomputable def squaresAtDepths (d e : ℕ) : ℝ :=
  ∑ u ∈ (internalVertices T₁).filter (fun u => depth₁ u = d),
    ∑ w ∈ (internalVertices T₂).filter (fun w => depth₂ w = e), centredSquares T₁ T₂ u w

theorem internalCentredSquares_eq_sum_depths (m : ℕ)
    (h₁ : ∀ u ∈ internalVertices T₁, depth₁ u < m)
    (h₂ : ∀ w ∈ internalVertices T₂, depth₂ w < m) :
    internalCentredSquares T₁ T₂ =
      ∑ d ∈ Finset.range m, ∑ e ∈ Finset.range m, squaresAtDepths T₁ T₂ depth₁ depth₂ d e := by
  classical
  have hsum :
      internalCentredSquares T₁ T₂ =
        ∑ u ∈ internalVertices T₁, ∑ w ∈ internalVertices T₂, centredSquares T₁ T₂ u w := by
    unfold internalCentredSquares internalVertices
    simp only [Finset.sum_filter]
    refine Finset.sum_congr rfl fun u _ => ?_
    by_cases hu : T₁.IsLeaf u <;> simp [hu]
  rw [hsum]
  unfold squaresAtDepths
  have hfin₁ : ∀ u ∈ internalVertices T₁, depth₁ u ∈ Finset.range m :=
    fun u hu => Finset.mem_range.mpr (h₁ u hu)
  have hfin₂ : ∀ w ∈ internalVertices T₂, depth₂ w ∈ Finset.range m :=
    fun w hw => Finset.mem_range.mpr (h₂ w hw)
  conv_rhs =>
    enter [2, d]
    rw [Finset.sum_comm]
  simp_rw [Finset.sum_fiberwise_of_maps_to hfin₂]
  exact (Finset.sum_fiberwise_of_maps_to hfin₁ _).symm

omit [LinearOrder V] in
private theorem leafDistanceSum_le_of_diameter (T : XTree (Fin n) V) (m : ℕ)
    (hdiam : ∀ x y, T.graph.dist (T.label x) (T.label y) ≤ 2 * m) :
    leafDistanceSum T ≤ (n : ℝ)^2 * m := by
  unfold leafDistanceSum
  have hc (x y : Fin n) : (T.graph.dist (T.label x) (T.label y) : ℝ) ≤ 2 * m := by
    exact_mod_cast hdiam x y
  have hsum : (∑ x : Fin n, ∑ y : Fin n, (T.graph.dist (T.label x) (T.label y) : ℝ)) ≤
      ∑ _x : Fin n, ∑ _y : Fin n, (2 : ℝ) * m :=
    Finset.sum_le_sum fun x _ => Finset.sum_le_sum fun y _ => hc x y
  simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hsum
  nlinarith only [hsum]

/-- From the diameter and per-depth estimates for a pair of trees, the
claimed order of the maximum deficit follows. -/
theorem maximumQuartetDeficit_le_of_depth_estimates (hn : 4 ≤ n)
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) (C : ℝ) (hC : 0 ≤ C)
    (hdepth₁ : ∀ u ∈ internalVertices T₁, depth₁ u < Nat.clog 2 n)
    (hdepth₂ : ∀ w ∈ internalVertices T₂, depth₂ w < Nat.clog 2 n)
    (hdiam : ∀ x y, T₂.graph.dist (T₂.label x) (T₂.label y) ≤ 2 * Nat.clog 2 n)
    (hblocks : ∀ d e, d < Nat.clog 2 n → e < Nat.clog 2 n →
      squaresAtDepths T₁ T₂ depth₁ depth₂ d e ≤
        C * (if Nat.clog 2 n - 1 ≤ d + e then
          (1 / (n : ℝ)) * depthWeight (d + e) + depthWeight (d + e)^2
        else (1 / (n : ℝ))^2 * (depthWeight d ^ 2 + depthWeight d))) :
    quartetBound n - (maximumQuartetDistance n : ℝ) ≤
      (1 + 16 * C) / 3 * (n : ℝ)^2 * Real.logb 2 (n : ℝ) := by
  let m := Nat.clog 2 n
  have hn0 : (0 : ℝ) < n := by exact_mod_cast (by omega : 0 < n)
  have hm : 0 < m := Nat.clog_pos (by decide : 1 < 2) (by omega)
  have hnm : n ≤ 2 ^ m := (Nat.clog_le_iff_le_pow (by decide : 1 < 2)).mp le_rfl
  have hsum := sum_depth_contributions_le n m (by omega) hm hnm C hC
    (squaresAtDepths T₁ T₂ depth₁ depth₂) hblocks
  rw [← internalCentredSquares_eq_sum_depths T₁ T₂ depth₁ depth₂ m hdepth₁ hdepth₂] at hsum
  have hscale := mul_le_mul_of_nonneg_left hsum (by positivity : 0 ≤ (n : ℝ)^4 / 6)
  have hμ : (n : ℝ)^4 / 6 * (16 * C * (m : ℝ) * (1 / (n : ℝ))^2) =
      16 * C * (n : ℝ)^2 * (m : ℝ) / 6 := by field_simp [hn0.ne']
  rw [hμ] at hscale
  have hdef := binaryDeficitFormula T₁ T₂ h₁ h₂
  rw [Fintype.card_fin] at hdef
  have hdist := leafDistanceSum_le_of_diameter T₂ m hdiam
  have hmember : quartetDistance T₁ T₂ ∈ attainedQuartetDistances n :=
    ⟨V, W, inferInstance, inferInstance, T₁, T₂, h₁, h₂, rfl⟩
  have hmax : (quartetDistance T₁ T₂ : ℝ) ≤ (maximumQuartetDistance n : ℝ) := by
    exact_mod_cast le_maximumQuartetDistance hmember
  have hdef' : quartetBound n - (maximumQuartetDistance n : ℝ) ≤
      (1 + 16 * C) / 6 * (n : ℝ)^2 * m := by
    nlinarith only [hscale, hdef, hdist, hmax]
  refine hdef'.trans ?_
  have hn' : (4 : ℝ) ≤ n := by exact_mod_cast hn
  have hlog := Real.logb_le_logb_of_le (by norm_num : (1 : ℝ) < 2)
    (by norm_num : (0 : ℝ) < 2) (by linarith only [hn'] : (2 : ℝ) ≤ n)
  rw [Real.logb_self_eq_one (by norm_num)] at hlog
  have hceil := Nat.ceil_lt_add_one (show 0 ≤ Real.logb 2 (n : ℝ) by linarith only [hlog])
  have hceil_eq : ⌈Real.logb 2 (n : ℝ)⌉₊ = Nat.clog 2 n := by
    simpa only [Nat.cast_ofNat] using Real.natCeil_logb_natCast 2 n
  rw [hceil_eq] at hceil
  have hm_le : (m : ℝ) ≤ 2 * Real.logb 2 (n : ℝ) := by
    change (Nat.clog 2 n : ℝ) ≤ _
    linarith only [hceil, hlog]
  have hmul := mul_le_mul_of_nonneg_left hm_le
    (show 0 ≤ (1 + 16 * C) / 6 * (n : ℝ)^2 by positivity)
  nlinarith only [hmul]

end TreeBounds

end CTV14
