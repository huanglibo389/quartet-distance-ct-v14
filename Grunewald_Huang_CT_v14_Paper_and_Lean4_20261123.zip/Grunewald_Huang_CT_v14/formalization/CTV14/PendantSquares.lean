import CTV14.QuartetDeficit
import QDFull.CoefficientLowerBound

/-!
The first row of the leaf contribution calculation in Theorem 5.1.
All square terms here are the original v8 coefficients, restricted to
directed edges entering labelled leaves.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV uW

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W]

noncomputable local instance : DecidableEq X := Classical.decEq X

noncomputable def leafNeighbour (T : XTree X V) (h : T.IsPhylogenetic) (x : X) : V :=
  Classical.choose (h.exists_unique_neighbor_label T x)

theorem adj_leafNeighbour (T : XTree X V) (h : T.IsPhylogenetic) (x : X) :
    T.graph.Adj (T.label x) (leafNeighbour T h x) :=
  (Classical.choose_spec (h.exists_unique_neighbor_label T x)).1

def centralPair (u : V) : V ↪ V × V :=
  ⟨fun z => (u, z), fun _ _ h => congrArg Prod.snd h⟩

theorem leaf_index_eq_map
    (T : XTree X V) (h : T.IsPhylogenetic) (x : X) {t : V}
    (ht : T.graph.Adj (T.label x) t) :
    T.indexIFinset t (T.label x) =
      (T.branchIndices (T.label x)).map (centralPair (T.label x)) := by
  classical
  let u := T.label x
  have huniq {z : V} (hz : T.graph.Adj u z) : z = t :=
    (h.exists_unique_neighbor_label T x).unique hz ht
  ext ⟨a, b⟩
  change (a, b) ∈ T.indexIFinset t u ↔ (a, b) ∈ (T.branchIndices u).map (centralPair u)
  rw [T.mem_indexIFinset, T.mem_indexI]
  constructor
  · rintro ⟨ha, hb, -⟩
    have hau : a = u := by
      rcases (T.mem_neighborsAwayPlus a t u).mp ha with ha | ha
      · exact ha
      · exact False.elim (ha.2 (huniq ha.1))
    subst a
    exact Finset.mem_map.mpr ⟨b, (T.mem_branchIndices u b).mpr hb, rfl⟩
  · intro hp
    obtain ⟨z, hz, heq⟩ := Finset.mem_map.mp hp
    change (u, z) = (a, b) at heq
    cases heq
    exact ⟨(T.mem_neighborsAwayPlus u t u).mpr (Or.inl rfl),
      (T.mem_branchIndices u _).mp hz, Or.inl rfl⟩

theorem labelFiber_eq_singleton (T : XTree X V)
    (h : T.IsPhylogenetic) (x : X) :
    T.labelFiber (T.label x) = ({x} : Finset X) := by
  classical
  ext y
  rw [T.mem_labelFiber, Finset.mem_singleton]
  exact ⟨fun he => h.1 he, fun he => congrArg T.label he⟩

private theorem pendant_coefficient_sum
    (T₁ : XTree X V) (T₂ : XTree X W) (h₁ : T₁.IsPhylogenetic)
    (h₂ : T₂.IsPhylogenetic) (x y : X) {t : V} {v : W}
    (ht : T₁.graph.Adj (T₁.label x) t) (hv : T₂.graph.Adj (T₂.label y) v)
    (hn : 2 ≤ Fintype.card X) :
    lemma3CoefficientSum T₁ T₂ t (T₁.label x) v (T₂.label y) =
      if x = y then 1 / (2 * (Fintype.card X : ℝ))
      else 1 / (2 * (Fintype.card X : ℝ) * ((Fintype.card X : ℝ) - 1)) := by
  classical
  letI : Nonempty X := ⟨x⟩
  let u := T₁.label x
  let w := T₂.label y
  let n : ℝ := Fintype.card X
  have hn' : 2 ≤ n := by
    change (2 : ℝ) ≤ (Fintype.card X : ℝ)
    exact_mod_cast hn
  have hn0 : n ≠ 0 := by linarith
  have hn1 : n - 1 ≠ 0 := by linarith
  let c := T₂.columnMass v w
  let a := jointMass T₁ T₂ t u v w
  have hsum :
      lemma3CoefficientSum T₁ T₂ t u v w =
        (1 / 2 : ℝ) * (a u w + c w * a u v / c v) := by
    unfold lemma3CoefficientSum
    rw [leaf_index_eq_map T₁ h₁ x ht, Finset.sum_map, Finset.sum_comm]
    change (∑ z₂ ∈ T₂.indexIFinset v w, ∑ z₁ ∈ T₁.branchIndices u,
      qCoefficient T₁ T₂ t u v w u z₁ z₂.1 z₂.2) = _
    simp_rw [sum_qCoefficient_centralRow T₁ T₂ t u v w _ _ hv.symm]
    rw [leaf_index_eq_map T₂ h₂ y hv, Finset.sum_map]
    change (∑ z ∈ T₂.branchIndices w, (1 / 2 : ℝ) * c z *
      (a u w + c w * a u v / c v)) = _
    rw [← Finset.sum_mul, ← Finset.mul_sum, sum_columnMass_allBranches, mul_one]
  have hfar : T₂.columnBlock v w v = ({y} : Finset X)ᶜ := by
    rw [T₂.columnBlock_of_adj v hv,
      T₂.edgeSide_reverse_eq_compl hv.symm, h₂.edgeSide_pendant_eq_singleton T₂ y hv]
  have hnear : T₂.columnBlock v w w = ({y} : Finset X) := by
    rw [T₂.columnBlock_center, labelFiber_eq_singleton T₂ h₂ y]
  have hrow : T₁.rowBlock t u u = ({x} : Finset X) := by
    rw [T₁.rowBlock_center, labelFiber_eq_singleton T₁ h₁ x]
  have hcast : ((Fintype.card X - 1 : ℕ) : ℝ) = n - 1 := by
    rw [Nat.cast_sub (by omega : 1 ≤ Fintype.card X), Nat.cast_one]
  have hc_leaf : c w = 1 / n := by
    change normalizedCard (T₂.columnBlock v w w) = _
    rw [hnear]
    simp [normalizedCard, n]
  have hc_other : c v = (n - 1) / n := by
    simp [c, XTree.columnMass, hfar, normalizedCard, Finset.card_compl, hcast, n]
  change lemma3CoefficientSum T₁ T₂ t u v w = if x = y then
    1 / (2 * n) else 1 / (2 * n * (n - 1))
  rw [hsum, hc_leaf, hc_other]
  by_cases hxy : x = y
  · have haw : a u w = 1 / n := by
      change normalizedCard (T₁.rowBlock t u u ∩ T₂.columnBlock v w w) = _
      rw [hrow, hnear]
      simp [hxy, normalizedCard, n]
    have hav : a u v = 0 := by
      change normalizedCard (T₁.rowBlock t u u ∩ T₂.columnBlock v w v) = _
      rw [hrow, hfar]
      simp [hxy, normalizedCard]
    rw [haw, hav, if_pos hxy]
    ring
  · have haw : a u w = 0 := by
      change normalizedCard (T₁.rowBlock t u u ∩ T₂.columnBlock v w w) = _
      rw [hrow, hnear, Finset.singleton_inter_of_notMem (by simpa using hxy)]
      simp [normalizedCard]
    have hav : a u v = 1 / n := by
      change normalizedCard (T₁.rowBlock t u u ∩ T₂.columnBlock v w v) = _
      rw [hrow, hfar, Finset.singleton_inter_of_mem (by simpa using hxy)]
      simp [normalizedCard, n]
    rw [haw, hav, if_neg hxy]
    field_simp [hn0, hn1]
    simp

private theorem pendant_determinant
    (T₁ : XTree X V) (T₂ : XTree X W) (h₁ : T₁.IsPhylogenetic)
    (h₂ : T₂.IsPhylogenetic) (x y : X) {t : V} {v : W}
    (ht : T₁.graph.Adj (T₁.label x) t) (hv : T₂.graph.Adj (T₂.label y) v)
    (hn : 2 ≤ Fintype.card X) :
    xCoefficient T₁ T₂ t (T₁.label x) v (T₂.label y) =
      if x = y then ((Fintype.card X : ℝ) - 1) / (Fintype.card X : ℝ)^2
      else -1 / (Fintype.card X : ℝ)^2 := by
  classical
  letI : Nonempty X := ⟨x⟩
  have hcast := Nat.cast_sub (R := ℝ) (by omega : 1 ≤ Fintype.card X)
  rw [xCoefficient_eq_edge_determinant T₁ T₂ ht.symm hv.symm,
    T₁.edgeSide_reverse_eq_compl ht.symm, T₂.edgeSide_reverse_eq_compl hv.symm,
    h₁.edgeSide_pendant_eq_singleton T₁ x ht, h₂.edgeSide_pendant_eq_singleton T₂ y hv]
  unfold orientedSplitDeterminant
  by_cases hxy : x = y
  · subst y
    simp [normalizedCard, Finset.card_compl, hcast]
    ring
  · have hx : x ∈ ({y} : Finset X)ᶜ := by simpa using hxy
    have hy : y ∈ ({x} : Finset X)ᶜ := by simpa using Ne.symm hxy
    rw [Finset.inter_comm (({x} : Finset X)ᶜ) ({y} : Finset X),
      Finset.singleton_inter_of_mem hx, Finset.singleton_inter_of_mem hy,
      Finset.singleton_inter_of_notMem (by simpa using hxy), if_neg hxy]
    simp [normalizedCard]
    ring

/-- The part of the \(q X^2\) sum whose two directed edges enter leaves. -/
noncomputable def pendantSquareSum (T₁ : XTree X V) (T₂ : XTree X W)
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic) : ℝ :=
  ∑ x : X, ∑ y : X,
    lemma3CoefficientSum T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x)
        (leafNeighbour T₂ h₂ y) (T₂.label y) *
      xCoefficient T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x)
        (leafNeighbour T₂ h₂ y) (T₂.label y) ^ 2

/-- The leaf–leaf entry of the table in the proof of Theorem 5.1. -/
theorem scaled_pendantSquareSum (T₁ : XTree X V) (T₂ : XTree X W)
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hn : 2 ≤ Fintype.card X) :
    (Fintype.card X : ℝ)^4 * pendantSquareSum T₁ T₂ h₁ h₂ =
      (((Fintype.card X : ℝ) - 1)^2 + 1) / 2 := by
  classical
  let n : ℝ := Fintype.card X
  have hn' : 2 ≤ n := by
    change (2 : ℝ) ≤ (Fintype.card X : ℝ)
    exact_mod_cast hn
  have hn0 : n ≠ 0 := by linarith
  have hn1 : n - 1 ≠ 0 := by linarith
  have hterm (x y : X) :
      n^4 * (lemma3CoefficientSum T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x)
          (leafNeighbour T₂ h₂ y) (T₂.label y) *
        xCoefficient T₁ T₂ (leafNeighbour T₁ h₁ x) (T₁.label x)
          (leafNeighbour T₂ h₂ y) (T₂.label y)^2) =
      if x = y then (n - 1)^2 / (2 * n) else 1 / (2 * n * (n - 1)) := by
    rw [pendant_coefficient_sum T₁ T₂ h₁ h₂ x y
        (adj_leafNeighbour T₁ h₁ x) (adj_leafNeighbour T₂ h₂ y) hn,
      pendant_determinant T₁ T₂ h₁ h₂ x y
        (adj_leafNeighbour T₁ h₁ x) (adj_leafNeighbour T₂ h₂ y) hn]
    by_cases hxy : x = y <;> simp only [hxy, if_true, if_false] <;>
      field_simp [show (Fintype.card X : ℝ) ≠ 0 from hn0,
        show (Fintype.card X : ℝ) - 1 ≠ 0 from hn1, n] <;> ring
  have hrow (x : X) :
      (∑ y : X, if x = y then (n - 1)^2 / (2 * n)
        else 1 / (2 * n * (n - 1))) = ((n - 1)^2 + 1) / (2 * n) := by
    have hmem : x ∈ (Finset.univ : Finset X) := Finset.mem_univ x
    rw [← Finset.sum_erase_add _ _ hmem, if_pos rfl]
    have hconst :
        (∑ y ∈ Finset.univ.erase x, if x = y then (n - 1)^2 / (2 * n)
            else 1 / (2 * n * (n - 1))) =
          ∑ _y ∈ Finset.univ.erase x, 1 / (2 * n * (n - 1)) := by
      refine Finset.sum_congr rfl fun y hy => if_neg (Finset.mem_erase.mp hy).1.symm
    rw [hconst, Finset.sum_const, nsmul_eq_mul, Finset.card_erase_of_mem hmem,
      Finset.card_univ, Nat.cast_sub (by omega : 1 ≤ Fintype.card X), Nat.cast_one]
    change (n - 1) * (1 / (2 * n * (n - 1))) + (n - 1)^2 / (2 * n) = _
    field_simp [hn0, hn1]
    ring
  change n^4 * pendantSquareSum T₁ T₂ h₁ h₂ = ((n - 1)^2 + 1) / 2
  unfold pendantSquareSum
  simp_rw [Finset.mul_sum, hterm, hrow]
  rw [Finset.sum_const, nsmul_eq_mul, Finset.card_univ]
  change n * (((n - 1)^2 + 1) / (2 * n)) = _
  field_simp [hn0]

private noncomputable def pendantEdge (T : XTree X V) (hT : T.IsPhylogenetic) :
    X ↪ V × V :=
  ⟨fun x => (leafNeighbour T hT x, T.label x), fun _ _ h => hT.1 (congrArg Prod.snd h)⟩

private theorem pendantEdge_mem_directed (T : XTree X V) (hT : T.IsPhylogenetic) (x : X) :
    pendantEdge T hT x ∈ T.directedEdgeFinset :=
  (T.mem_directedEdgeFinset _ _).2 (adj_leafNeighbour T hT x).symm

theorem pendantSquareSum_le_qSquareFamily
    (T₁ : XTree X V) (T₂ : XTree X W) (h₁ : T₁.IsPhylogenetic)
    (h₂ : T₂.IsPhylogenetic) :
    pendantSquareSum T₁ T₂ h₁ h₂ ≤ qSquareFamily T₁ T₂ := by
  classical
  let E₁ := Finset.univ.map (pendantEdge T₁ h₁)
  let E₂ := Finset.univ.map (pendantEdge T₂ h₂)
  have hE₁ : E₁ ⊆ T₁.directedEdgeFinset := by
    intro e he
    obtain ⟨x, _, rfl⟩ := Finset.mem_map.mp he
    exact pendantEdge_mem_directed T₁ h₁ x
  have hE₂ : E₂ ⊆ T₂.directedEdgeFinset := by
    intro e he
    obtain ⟨y, _, rfl⟩ := Finset.mem_map.mp he
    exact pendantEdge_mem_directed T₂ h₂ y
  let qTerm (e₁ : V × V) (e₂ : W × W) :=
    lemma3CoefficientSum T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 *
      xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2
  have hnonneg (e₁ : V × V) (e₂ : W × W) (he₂ : e₂ ∈ T₂.directedEdgeFinset) :
      0 ≤ qTerm e₁ e₂ := by
    have hadj := (T₂.mem_directedEdgeFinset _ _).1 he₂
    apply mul_nonneg _ (sq_nonneg _)
    unfold lemma3CoefficientSum
    exact Finset.sum_nonneg fun z₁ _ => Finset.sum_nonneg fun z₂ _ =>
      qCoefficient_nonneg_of_adj T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2 hadj z₂.1 z₂.2
  calc
    pendantSquareSum T₁ T₂ h₁ h₂ = ∑ e₁ ∈ E₁, ∑ e₂ ∈ E₂, qTerm e₁ e₂ := by
      simp_rw [E₁, E₂, Finset.sum_map]
      rfl
    _ ≤ ∑ e₁ ∈ T₁.directedEdgeFinset, ∑ e₂ ∈ E₂, qTerm e₁ e₂ :=
      Finset.sum_le_sum_of_subset_of_nonneg hE₁ fun _ _ _ =>
        Finset.sum_nonneg fun e₂ he₂ => hnonneg _ e₂ (hE₂ he₂)
    _ ≤ ∑ e₁ ∈ T₁.directedEdgeFinset, ∑ e₂ ∈ T₂.directedEdgeFinset, qTerm e₁ e₂ :=
      Finset.sum_le_sum fun e₁ _ =>
        Finset.sum_le_sum_of_subset_of_nonneg hE₂ fun e₂ he₂ _ => hnonneg e₁ e₂ he₂
    _ = qSquareFamily T₁ T₂ := by
      simp_rw [qTerm, lemma3CoefficientSum, Finset.sum_mul]
      rfl

/-- The finite deficit supplied by the leaf–leaf squares alone. The other
terms with a leaf centre are needed for the full shape-dependent bound. -/
theorem pendantDeficit_lower (T₁ : XTree X V) (T₂ : XTree X W)
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic)
    (hn : 2 ≤ Fintype.card X) :
    (((Fintype.card X : ℝ) - 1)^2 + 1) / 12 ≤
      quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) := by
  classical
  letI : LinearOrder V := LinearOrder.lift' (Fintype.equivFin V) (Fintype.equivFin V).injective
  letI : LinearOrder W := LinearOrder.lift' (Fintype.equivFin W) (Fintype.equivFin W).injective
  have hq := pendantSquareSum_le_qSquareFamily T₁ T₂ h₁.1 h₂.1
  have hsum : pendantSquareSum T₁ T₂ h₁.1 h₂.1 ≤ sumOfSquaresRhs T₁ T₂ := by
    unfold sumOfSquaresRhs
    linarith [sSquareFamily_nonneg T₁ T₂, bSquareFamily_nonneg T₁ T₂,
      pSquareFamily_nonneg T₁ T₂]
  have hscaled := mul_le_mul_of_nonneg_left hsum
    (pow_nonneg (Nat.cast_nonneg (α := ℝ) (Fintype.card X)) 4)
  rw [scaled_pendantSquareSum T₁ T₂ h₁.1 h₂.1 hn] at hscaled
  rw [quartetBound_sub_distance_eq_sumOfSquares T₁ T₂ h₁ h₂]
  linarith only [hscaled]

end CTV14
