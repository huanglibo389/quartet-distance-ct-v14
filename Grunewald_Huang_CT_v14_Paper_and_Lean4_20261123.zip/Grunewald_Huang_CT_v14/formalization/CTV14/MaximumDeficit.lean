import CTV14.ShapeBound
import QDFull.PhyloSyntaxBridge

/-!
The maximum ranges over the graph-theoretic binary phylogenetic trees
on the taxon set `Fin n`. The syntax-tree realization provides a witness
that this class is inhabited for the range of Theorem 5.2.
-/

namespace CTV14

open QDFull

/-- Distances attained by pairs of finite binary phylogenetic trees on
the common taxon set `Fin n`. -/
def attainedQuartetDistances (n : ℕ) : Set ℕ :=
  {d | ∃ (V W : Type) (iV : Fintype V) (iW : Fintype W),
    letI := iV
    letI := iW
    ∃ (T₁ : XTree (Fin n) V) (T₂ : XTree (Fin n) W),
      T₁.IsBinaryPhylogenetic ∧ T₂.IsBinaryPhylogenetic ∧
        QDFull.quartetDistance T₁ T₂ = d}

/-- The maximum (M_n) for the finite binary phylogenetic tree model. -/
noncomputable def maximumQuartetDistance (n : ℕ) : ℕ :=
  sSup (attainedQuartetDistances n)

private theorem attainedQuartetDistances_bddAbove (n : ℕ) :
    BddAbove (attainedQuartetDistances n) := by
  classical
  refine ⟨Fintype.card (Finset (Fin n)), ?_⟩
  rintro d ⟨V, W, iV, iW, T₁, T₂, _, _, rfl⟩
  exact Finset.card_le_univ (QDFull.quartetDisagreementSupports T₁ T₂)

theorem maximumQuartetDistance_attained (n : ℕ) (hn : 4 ≤ n) :
    maximumQuartetDistance n ∈ attainedQuartetDistances n := by
  classical
  obtain ⟨T⟩ := QuartetDistance.Lower.nonempty_phyloTree_fin n hn
  let t := PhyloSyntaxBridge.realizedXTree T
  have ht : t.IsBinaryPhylogenetic := PhyloSyntaxBridge.realizedXTree_isBinaryPhylogenetic T
  have h : (attainedQuartetDistances n).Nonempty :=
    ⟨QDFull.quartetDistance t t, _, _, _, _, t, t, ht, ht, rfl⟩
  exact Nat.sSup_mem h (attainedQuartetDistances_bddAbove n)

theorem le_maximumQuartetDistance {n d : ℕ} (hd : d ∈ attainedQuartetDistances n) :
    d ≤ maximumQuartetDistance n :=
  le_csSup (attainedQuartetDistances_bddAbove n) hd

/-- The lower inequality of Theorem 5.2, with its printed constant. -/
theorem log_lower_le_maximumQuartetDeficit (n : ℕ) (hn : 4 ≤ n) :
    (n : ℝ) * ((n : ℝ) - 1) * (1 + Real.logb 2 ((n : ℝ) - 1)) / 12 ≤
      quartetBound n - (maximumQuartetDistance n : ℝ) := by
  obtain ⟨V, W, iV, iW, T₁, T₂, h₁, h₂, hd⟩ := maximumQuartetDistance_attained n hn
  have h := log_lower_le_quartetDeficit T₁ T₂ h₁ h₂
  rw [Fintype.card_fin, hd] at h
  exact h

end CTV14
