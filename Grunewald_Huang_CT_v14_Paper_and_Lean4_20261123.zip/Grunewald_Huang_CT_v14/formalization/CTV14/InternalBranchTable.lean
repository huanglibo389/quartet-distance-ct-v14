import CTV14.BranchIndex
import CTV14.CentredSquares
import CTV14.LocalSquares

/-!
The actual local branch-mass table for two graph-theoretic binary
phylogenetic trees, indexed by any enumerations of the three branches.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV uW

section BranchEnumeration

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]
  (T : XTree X V) {u : V}

abbrev BranchEnumeration (u : V) := Fin 3 ≃ T.neighborFinset u

variable {T}

def BranchEnumeration.vertex (e : BranchEnumeration T u) (i : Fin 3) : V := (e i).val

namespace BranchEnumeration

variable (e : BranchEnumeration T u)

theorem vertex_injective : Function.Injective e.vertex := fun _ _ h =>
  e.injective (Subtype.ext h)

theorem adj (i : Fin 3) : T.graph.Adj u (e.vertex i) :=
  (T.mem_neighborFinset _ _).mp (e i).2

private theorem eq_univ (i : Fin 3) :
    (Finset.univ : Finset (Fin 3)) = {i, i + 1, i + 2} := by
  fin_cases i <;> decide

theorem neighborFinset_eq (i : Fin 3) :
    letI := Classical.decEq V
    T.neighborFinset u = {e.vertex i, e.vertex (i + 1), e.vertex (i + 2)} := by
  classical
  ext z
  simp only [Finset.mem_insert, Finset.mem_singleton]
  constructor
  · intro hz
    obtain ⟨j, hj⟩ := e.surjective ⟨z, hz⟩
    have he : e.vertex j = z := congrArg Subtype.val hj
    have hmem : j ∈ (Finset.univ : Finset (Fin 3)) := Finset.mem_univ _
    rw [eq_univ i] at hmem
    simp only [Finset.mem_insert, Finset.mem_singleton] at hmem
    rcases hmem with rfl | rfl | rfl <;> simp [he]
  · rintro (rfl | rfl | rfl) <;> exact (e _).2

private theorem cyclic_ne (i : Fin 3) :
    i ≠ i + 1 ∧ i ≠ i + 2 ∧ i + 1 ≠ i + 2 := by
  fin_cases i <;> decide

theorem sum_indexI {M : Type*} [AddCommMonoid M] (i : Fin 3) (f : V × V → M)
    (hf₁ : ∀ z, f (u, z) = 0) (hf₂ : ∀ z, f (z, u) = 0) :
    (∑ z ∈ T.indexIFinset (e.vertex i) u, f z) =
      f (e.vertex (i + 1), e.vertex (i + 2)) + f (e.vertex (i + 2), e.vertex (i + 1)) := by
  have ⟨h₁, h₂, h₃⟩ := cyclic_ne i
  exact sum_indexI_trivalent T u _ _ _ (e.neighborFinset_eq i)
    (e.vertex_injective.ne h₁) (e.vertex_injective.ne h₂) (e.vertex_injective.ne h₃) f hf₁ hf₂

theorem sum_neighbours {M : Type*} [AddCommMonoid M] (f : V → M) :
    (∑ z ∈ T.neighborFinset u, f z) = ∑ i : Fin 3, f (e.vertex i) := by
  rw [← Finset.sum_coe_sort]
  exact (Equiv.sum_comp e (fun z => f z.val)).symm

theorem sum_branchIndices {M : Type*} [AddCommMonoid M] (f : V → M) (hf : f u = 0) :
    (∑ z ∈ T.branchIndices u, f z) = ∑ i : Fin 3, f (e.vertex i) := by
  classical
  have he : T.branchIndices u = insert u (T.neighborFinset u) := by
    ext z
    simp [T.mem_branchIndices]
  have hself : u ∉ T.neighborFinset u := by simp
  rw [he, Finset.sum_insert hself, hf, zero_add, e.sum_neighbours]

section OrderedPaths

variable [LinearOrder V]

private def indexedPath (i : Fin 3) : V × V × V :=
  (min (e.vertex (i + 1)) (e.vertex (i + 2)), u, max (e.vertex (i + 1)) (e.vertex (i + 2)))

private theorem indexedPath_order (i : Fin 3) :
    (e.indexedPath i).1 < (e.indexedPath i).2.2 := by
  have h := e.vertex_injective.ne (cyclic_ne i).2.2
  rcases lt_or_gt_of_ne h with hlt | hgt
  · simpa [indexedPath, min_eq_left hlt.le, max_eq_right hlt.le] using hlt
  · simpa [indexedPath, min_eq_right hgt.le, max_eq_left hgt.le] using hgt

private theorem mem_indexedPath_endpoints (i : Fin 3) (z : V) :
    z = (e.indexedPath i).1 ∨ z = (e.indexedPath i).2.2 ↔
      ∃ j : Fin 3, j ≠ i ∧ e.vertex j = z := by
  have hcyclic : ∀ i j : Fin 3, j ≠ i ↔ j = i + 1 ∨ j = i + 2 := by decide
  rcases le_total (e.vertex (i + 1)) (e.vertex (i + 2)) with h | h <;>
    simp [indexedPath, min_eq_left h, min_eq_right h, max_eq_left h, max_eq_right h, hcyclic,
      eq_comm, or_comm]

private theorem indexedPath_injective : Function.Injective e.indexedPath := by
  intro i j hij
  by_contra hne
  have hmem := (e.mem_indexedPath_endpoints j (e.vertex i)).mpr ⟨i, hne, rfl⟩
  rw [← hij] at hmem
  obtain ⟨k, hk, he⟩ := (e.mem_indexedPath_endpoints i (e.vertex i)).mp hmem
  exact hk (e.vertex_injective he)

private theorem indexedPath_mem_pathsAt (i : Fin 3) : e.indexedPath i ∈ pathsAt T u := by
  have h₁ := e.adj (i + 1)
  have h₂ := e.adj (i + 2)
  have ho := e.indexedPath_order i
  rcases le_total (e.vertex (i + 1)) (e.vertex (i + 2)) with h | h
  · simp [indexedPath, min_eq_left h, max_eq_right h] at ho
    simpa [indexedPath, pathsAt, min_eq_left h, max_eq_right h] using And.intro h₁.symm ⟨h₂, ho⟩
  · simp [indexedPath, min_eq_right h, max_eq_left h] at ho
    simpa [indexedPath, pathsAt, min_eq_right h, max_eq_left h] using And.intro h₂.symm ⟨h₁, ho⟩

private theorem pathsAt_eq_image :
    pathsAt T u = Finset.univ.image e.indexedPath := by
  classical
  ext ⟨a, v, b⟩
  simp only [pathsAt, Finset.mem_filter, T.mem_canonicalLengthTwoPathFinset,
    Finset.mem_image, Finset.mem_univ, true_and]
  constructor
  · rintro ⟨⟨ha, hb, hab⟩, hvu⟩
    change v = u at hvu
    subst v
    obtain ⟨i, hi⟩ := e.surjective ⟨a, (T.mem_neighborFinset _ _).mpr ha.symm⟩
    obtain ⟨j, hj⟩ := e.surjective ⟨b, (T.mem_neighborFinset _ _).mpr hb⟩
    have he₁ : e.vertex i = a := congrArg Subtype.val hi
    have he₂ : e.vertex j = b := congrArg Subtype.val hj
    have hij : i ≠ j := fun h => hab.ne (he₁.symm.trans (h ▸ he₂))
    have hthird : ∀ i j : Fin 3, i ≠ j → ∃ k : Fin 3, i ≠ k ∧ j ≠ k := by decide
    obtain ⟨k, hik, hjk⟩ := hthird i j hij
    have hleft := (e.mem_indexedPath_endpoints k a).mpr ⟨i, hik, he₁⟩
    have hright := (e.mem_indexedPath_endpoints k b).mpr ⟨j, hjk, he₂⟩
    have ho := e.indexedPath_order k
    have hmid : (e.indexedPath k).2.1 = u := rfl
    refine ⟨k, ?_⟩
    have hends : (e.indexedPath k).1 = a ∧ (e.indexedPath k).2.2 = b := by grind
    exact Prod.ext hends.1 (Prod.ext hmid hends.2)
  · rintro ⟨i, hi⟩
    have hmem := e.indexedPath_mem_pathsAt i
    rw [hi] at hmem
    simpa only [pathsAt, Finset.mem_filter, T.mem_canonicalLengthTwoPathFinset] using hmem

theorem sum_paths (f : V × V × V → ℝ) (hf : ∀ a b, T.graph.Adj u a →
    T.graph.Adj u b → f (a, u, b) = f (b, u, a)) :
    (∑ z ∈ pathsAt T u, f z) =
      ∑ i : Fin 3, f (e.vertex (i + 1), u, e.vertex (i + 2)) := by
  classical
  rw [e.pathsAt_eq_image, Finset.sum_image e.indexedPath_injective.injOn]
  refine Finset.sum_congr rfl fun i _ => ?_
  rcases le_total (e.vertex (i + 1)) (e.vertex (i + 2)) with h | h
  · simp [indexedPath, min_eq_left h, max_eq_right h]
  · simp [indexedPath, min_eq_right h, max_eq_left h, hf _ _ (e.adj (i + 2)) (e.adj (i + 1))]

end OrderedPaths

end BranchEnumeration

end BranchEnumeration

section Tables

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W]
  (T₁ : XTree X V) (T₂ : XTree X W) {u : V} {w : W}
  (e : BranchEnumeration T₁ u) (g : BranchEnumeration T₂ w)

/-- The entries (a_{ij}) are normalized intersections of graph branches. -/
noncomputable def graphBranchTable : BranchMassTable :=
  fun i j => jointMass T₁ T₂ u u w w (e.vertex i) (g.vertex j)

theorem graphBranchTable_nonneg (i j : Fin 3) : 0 ≤ graphBranchTable T₁ T₂ e g i j :=
  normalizedCard_nonneg _

theorem rowTotal_graphBranchTable (h₂ : T₂.IsPhylogenetic) (hw : ¬ T₂.IsLeaf w) (i : Fin 3) :
    rowTotal (graphBranchTable T₁ T₂ e g) i = T₁.rowMass u u (e.vertex i) := by
  unfold rowTotal graphBranchTable
  have hzero : jointMass T₁ T₂ u u w w (e.vertex i) w = 0 := by
    simp [jointMass, jointBlock, h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]
  rw [← g.sum_branchIndices _ hzero, sum_jointMass_allColumnBranches]

theorem colTotal_graphBranchTable (h₁ : T₁.IsPhylogenetic) (hu : ¬ T₁.IsLeaf u) (j : Fin 3) :
    colTotal (graphBranchTable T₁ T₂ e g) j = T₂.columnMass w w (g.vertex j) := by
  unfold colTotal graphBranchTable
  have hzero : jointMass T₁ T₂ u u w w u (g.vertex j) = 0 := by
    simp [jointMass, jointBlock, h₁.labelFiber_eq_empty_of_not_leaf T₁ hu, normalizedCard]
  rw [← e.sum_branchIndices (fun z => jointMass T₁ T₂ u u w w z (g.vertex j)) hzero,
    sum_jointMass_allRowBranches]

theorem sum_graphBranchTable (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) :
    (∑ i, ∑ j, graphBranchTable T₁ T₂ e g i j) = 1 := by
  change (∑ i, rowTotal (graphBranchTable T₁ T₂ e g) i) = 1
  simp_rw [rowTotal_graphBranchTable T₁ T₂ e g h₂ hw]
  have hzero : T₁.rowMass u u u = 0 := by
    simp [XTree.rowMass, h₁.labelFiber_eq_empty_of_not_leaf T₁ hu, normalizedCard]
  rw [← e.sum_branchIndices _ hzero, sum_rowMass_allBranches]

theorem xCoefficient_eq_graphBranchTable (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (i j : Fin 3) :
    xCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w =
      centredEntry (graphBranchTable T₁ T₂ e g) i j := by
  rw [xCoefficient_eq_centered_jointMass T₁ T₂ (e.adj i).symm (g.adj j).symm,
    centredEntry, rowTotal_graphBranchTable T₁ T₂ e g h₂ hw i,
    colTotal_graphBranchTable T₁ T₂ e g h₁ hu j]
  rfl

private theorem qCoefficient_swap_row_arguments (T₁ : XTree X V) (T₂ : XTree X W)
    (t u a b : V) (v w c d : W) :
    qCoefficient T₁ T₂ t u v w a b c d = qCoefficient T₁ T₂ t u v w b a c d := by
  unfold qCoefficient
  ring

private theorem qCoefficient_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (hu : ¬ T₁.IsLeaf u)
    (t : V) (i j k l : Fin 3) :
    qCoefficient T₁ T₂ t u (g.vertex j) w (e.vertex (i + 1)) (e.vertex (i + 2))
        (g.vertex k) (g.vertex l) =
      (1 / 2 : ℝ) * colTotal (graphBranchTable T₁ T₂ e g) l /
        colTotal (graphBranchTable T₁ T₂ e g) j *
          complementPermanent (graphBranchTable T₁ T₂ e g) i j k := by
  rw [colTotal_graphBranchTable T₁ T₂ e g h₁ hu l, colTotal_graphBranchTable T₁ T₂ e g h₁ hu j]
  unfold qCoefficient complementPermanent graphBranchTable jointMass jointBlock
    XTree.rowBlock XTree.columnMass XTree.columnBlock
  ring

private theorem sum_qCoefficient_row_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (hu : ¬ T₁.IsLeaf u) (i j : Fin 3) (a b : W) :
    (∑ z ∈ T₁.indexIFinset (e.vertex i) u,
        qCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w z.1 z.2 a b) =
      qCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w (e.vertex (i + 1)) (e.vertex (i + 2)) a b +
        qCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w (e.vertex (i + 2)) (e.vertex (i + 1)) a b := by
  apply e.sum_indexI
  · intro z
    simp [qCoefficient, jointMass, jointBlock, h₁.labelFiber_eq_empty_of_not_leaf T₁ hu, normalizedCard]
  · intro z
    simp [qCoefficient, jointMass, jointBlock, h₁.labelFiber_eq_empty_of_not_leaf T₁ hu, normalizedCard]

theorem qTerm_eq_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (i j : Fin 3) :
    let A := graphBranchTable T₁ T₂ e g
    qTerm T₁ T₂ (e.vertex i, u) (g.vertex j, w) =
      internalEdgeWeight A i j * centredEntry A i j ^ 2 := by
  classical
  dsimp only
  rw [qTerm]
  change lemma3CoefficientSum T₁ T₂ (e.vertex i) u (g.vertex j) w *
    xCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w ^ 2 = _
  rw [xCoefficient_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw]
  congr 1
  unfold lemma3CoefficientSum
  rw [Finset.sum_comm]
  let f (z : W × W) := ∑ y ∈ T₁.indexIFinset (e.vertex i) u,
    qCoefficient T₁ T₂ (e.vertex i) u (g.vertex j) w y.1 y.2 z.1 z.2
  change (∑ z ∈ T₂.indexIFinset (g.vertex j) w, f z) = _
  rw [g.sum_indexI j f]
  · dsimp [f]
    rw [sum_qCoefficient_row_graphBranchTable T₁ T₂ e g h₁ hu,
      sum_qCoefficient_row_graphBranchTable T₁ T₂ e g h₁ hu]
    rw [qCoefficient_swap_row_arguments T₁ T₂ _ _ (e.vertex (i + 2)) (e.vertex (i + 1))
          _ _ (g.vertex (j + 1)) (g.vertex (j + 2)),
      qCoefficient_swap_row_arguments T₁ T₂ _ _ (e.vertex (i + 2)) (e.vertex (i + 1))
          _ _ (g.vertex (j + 2)) (g.vertex (j + 1))]
    simp_rw [qCoefficient_graphBranchTable T₁ T₂ e g h₁ hu, internalEdgeWeight]
    ring
  · intro z
    simp [f, qCoefficient, jointMass, jointBlock,
      h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]
  · intro z
    simp [f, qCoefficient, XTree.columnMass, h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]

theorem sTerm_eq_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (i j : Fin 3) :
    let A := graphBranchTable T₁ T₂ e g
    sTerm T₁ T₂ (e.vertex i, u) (g.vertex (j + 1), w, g.vertex (j + 2)) =
      complementPermanent A i (j + 1) (j + 2) *
        (centredEntry A i (j + 1) + centredEntry A i (j + 2)) ^ 2 := by
  classical
  dsimp only
  simp only [sTerm, sCoefficient, ← Finset.sum_mul,
    xCoefficient_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw]
  congr 1
  rw [sum_qCoefficient_row_graphBranchTable T₁ T₂ e g h₁ hu,
    qCoefficient_swap_row_arguments T₁ T₂ _ _ (e.vertex (i + 2)) (e.vertex (i + 1))]
  simp_rw [qCoefficient_graphBranchTable T₁ T₂ e g h₁ hu]
  have hp : colTotal (graphBranchTable T₁ T₂ e g) (j + 1) ≠ 0 := by
    rw [colTotal_graphBranchTable T₁ T₂ e g h₁ hu]
    exact ne_of_gt (T₂.columnMass_pos_of_adj (g.adj (j + 1)).symm)
  field_simp [hp]
  ring

theorem bTerm_eq_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (i j : Fin 3) :
    let A := graphBranchTable T₁ T₂ e g
    bTerm T₁ T₂ (e.vertex (i + 1), u, e.vertex (i + 2)) (g.vertex j, w) =
      internalEdgeWeight A i j / 2 *
        (centredEntry A (i + 1) j + centredEntry A (i + 2) j) ^ 2 := by
  classical
  dsimp only
  simp only [bTerm, bCoefficient, ← Finset.sum_mul,
    xCoefficient_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw]
  congr 1
  let f (z : W × W) := qCoefficient T₁ T₂ (e.vertex (i + 1)) u (g.vertex j) w
    (e.vertex (i + 2)) (e.vertex (i + 1)) z.1 z.2
  change (∑ z ∈ T₂.indexIFinset (g.vertex j) w, f z) = _
  rw [g.sum_indexI j f]
  · dsimp [f]
    simp only [qCoefficient_swap_row_arguments T₁ T₂ _ _ (e.vertex (i + 2)) (e.vertex (i + 1)),
      qCoefficient_graphBranchTable T₁ T₂ e g h₁ hu, internalEdgeWeight]
    ring
  · intro z
    simp [f, qCoefficient, jointMass, jointBlock,
      h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]
  · intro z
    simp [f, qCoefficient, XTree.columnMass, h₂.labelFiber_eq_empty_of_not_leaf T₂ hw, normalizedCard]

theorem pTerm_eq_graphBranchTable
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) (i j : Fin 3) :
    let A := graphBranchTable T₁ T₂ e g
    pTerm T₁ T₂ (e.vertex (i + 1), u, e.vertex (i + 2)) (g.vertex (j + 1), w, g.vertex (j + 2)) =
      complementPermanent A i (j + 1) (j + 2) / 2 *
        (centredEntry A (i + 1) (j + 1) + centredEntry A (i + 1) (j + 2) +
          centredEntry A (i + 2) (j + 1) + centredEntry A (i + 2) (j + 2)) ^ 2 := by
  classical
  dsimp only
  simp only [pTerm, pCoefficient, xCoefficient_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw,
    qCoefficient_swap_row_arguments T₁ T₂ _ _ (e.vertex (i + 2)) (e.vertex (i + 1)),
    qCoefficient_graphBranchTable T₁ T₂ e g h₁ hu]
  have hp : colTotal (graphBranchTable T₁ T₂ e g) (j + 1) ≠ 0 := by
    rw [colTotal_graphBranchTable T₁ T₂ e g h₁ hu]
    exact ne_of_gt (T₂.columnMass_pos_of_adj (g.adj (j + 1)).symm)
  field_simp [hp]

private theorem sTerm_reverse (e₁ : V × V) {a b : W}
    (ha : T₂.graph.Adj w a) (hb : T₂.graph.Adj w b) :
    sTerm T₁ T₂ e₁ (a, w, b) = sTerm T₁ T₂ e₁ (b, w, a) := by
  unfold sTerm sCoefficient
  refine Finset.sum_congr rfl fun z _ => ?_
  rw [qCoefficient_column_reindex T₁ T₂ _ _ _ _ a w b ha.symm hb.symm]
  rw [add_comm]

private theorem bTerm_reverse (e₂ : W × W) (a b : V) :
    bTerm T₁ T₂ (a, u, b) e₂ = bTerm T₁ T₂ (b, u, a) e₂ := by
  unfold bTerm bCoefficient
  refine Finset.sum_congr rfl fun z _ => ?_
  rw [qCoefficient_row_reindex T₁ T₂ a u b]
  rw [add_comm]

private theorem pTerm_reverse_row (p₂ : W × W × W) (a b : V) :
    pTerm T₁ T₂ (a, u, b) p₂ = pTerm T₁ T₂ (b, u, a) p₂ := by
  unfold pTerm pCoefficient
  rw [qCoefficient_row_reindex T₁ T₂ a u b]
  ring

private theorem pTerm_reverse_column (p₁ : V × V × V) {a b : W}
    (ha : T₂.graph.Adj w a) (hb : T₂.graph.Adj w b) :
    pTerm T₁ T₂ p₁ (a, w, b) = pTerm T₁ T₂ p₁ (b, w, a) := by
  unfold pTerm pCoefficient
  rw [qCoefficient_column_reindex T₁ T₂ _ _ _ _ a w b ha.symm hb.symm]
  ring

/-- The four graph square families at two internal centres, reindexed
by the two triples of branches. -/
theorem centredSquares_eq_internalFourFamilies [LinearOrder V] [LinearOrder W]
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) :
    centredSquares T₁ T₂ u w = internalFourFamilies (graphBranchTable T₁ T₂ e g) := by
  rw [centredSquares_eq_local_sums]
  have hS (t : V) := g.sum_paths (fun p => sTerm T₁ T₂ (t, u) p)
    (fun _ _ ha hb => sTerm_reverse T₁ T₂ (t, u) ha hb)
  have hB (v : W) := e.sum_paths (fun p => bTerm T₁ T₂ p (v, w))
    (fun a b _ _ => bTerm_reverse T₁ T₂ (v, w) a b)
  have hPcol (p : V × V × V) := g.sum_paths (pTerm T₁ T₂ p)
    (fun _ _ ha hb => pTerm_reverse_column T₁ T₂ p ha hb)
  rw [Finset.sum_comm (s := pathsAt T₁ u) (t := T₂.neighborFinset w)]
  simp_rw [e.sum_neighbours, g.sum_neighbours, hS, hB, hPcol]
  have hProw := e.sum_paths
    (fun p => ∑ j : Fin 3, pTerm T₁ T₂ p (g.vertex (j + 1), w, g.vertex (j + 2)))
    (fun a b _ _ => Finset.sum_congr rfl (fun _ _ => pTerm_reverse_row T₁ T₂ _ a b))
  rw [hProw]
  rw [Finset.sum_comm (f := fun j i : Fin 3 =>
    bTerm T₁ T₂ (e.vertex (i + 1), u, e.vertex (i + 2)) (g.vertex j, w))]
  simp_rw [qTerm_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw,
    sTerm_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw,
    bTerm_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw,
    pTerm_eq_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw, internalFourFamilies, Finset.sum_add_distrib]

/-- The coefficient formula of Theorem 5.2 for the actual (F_{u,w}). -/
theorem centredSquares_eq_internalCoefficients [LinearOrder V] [LinearOrder W]
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic)
    (hu : ¬ T₁.IsLeaf u) (hw : ¬ T₂.IsLeaf w) :
    let A := graphBranchTable T₁ T₂ e g
    centredSquares T₁ T₂ u w = (3 / 2 : ℝ) *
      ∑ i : Fin 3, ∑ j : Fin 3, internalCoefficient A i j * centredEntry A i j ^ 2 := by
  rw [centredSquares_eq_internalFourFamilies T₁ T₂ e g h₁ h₂ hu hw]
  exact internalFourFamilies_eq_coefficients _ (sum_graphBranchTable T₁ T₂ e g h₁ h₂ hu hw)

end Tables

end CTV14
