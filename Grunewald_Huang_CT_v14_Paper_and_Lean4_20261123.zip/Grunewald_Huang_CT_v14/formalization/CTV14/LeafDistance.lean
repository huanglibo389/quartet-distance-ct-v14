import QDFull.BinaryPhylogeneticQuartets
import Mathlib.Analysis.MeanInequalities
import Mathlib.Analysis.SpecialFunctions.Log.Base

/-!
The leaf-distance estimate used in Theorem 5.2. The identity for the
leaf weights is proved on the actual finite graph underlying a v8
XTree.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV

private theorem existsUnique_closer_neighbor {V : Type uV} {G : SimpleGraph V}
    (hG : G.IsTree) (r v : V) (hv : v ≠ r) :
    ∃! u, G.Adj v u ∧ G.dist r u < G.dist r v := by
  obtain ⟨p, hp⟩ := hG.connected.exists_walk_length_eq_dist v r
  have hnil : ¬ p.Nil := SimpleGraph.Walk.not_nil_of_ne hv
  have htail := p.length_tail_add_one hnil
  have hdist := G.dist_le p.tail
  refine ⟨p.snd, ⟨p.adj_snd hnil, ?_⟩, ?_⟩
  · rw [G.dist_comm (u := r) (v := p.snd), G.dist_comm (u := r) (v := v)]
    omega
  intro u hu
  obtain ⟨q, hq⟩ := hG.connected.exists_walk_length_eq_dist u r
  have hstep := hG.dist_eq_dist_add_one_of_adj r hu.1
  have hlt := hu.2
  rw [G.dist_comm (u := r) (v := u), G.dist_comm (u := r) (v := v)] at hstep hlt
  have hqlen : (SimpleGraph.Walk.cons hu.1 q).length = G.dist v r := by
    simp only [SimpleGraph.Walk.length_cons]
    omega
  have hwalk :
      SimpleGraph.Walk.cons hu.1 q = p :=
    congrArg Subtype.val (hG.isAcyclic.path_unique
      ⟨_, (SimpleGraph.Walk.cons hu.1 q).isPath_of_length_eq_dist hqlen⟩
      ⟨_, p.isPath_of_length_eq_dist hp⟩)
  simpa only [SimpleGraph.Walk.snd_cons] using
    congrArg SimpleGraph.Walk.snd hwalk

section

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V]

private noncomputable def otherLeaves (T : XTree X V) (r : V) : Finset V := by
  classical
  exact Finset.univ.filter fun v => T.IsLeaf v ∧ v ≠ r

private theorem sum_leaf_vertex_weights (T : XTree X V)
    (hT : T.IsBinaryPhylogenetic) (r : V) (hr : T.IsLeaf r) :
    ∑ v ∈ otherLeaves T r, (1 / 2 : ℝ) ^ T.graph.dist r v = 1 / 2 := by
  classical
  let weight (v : V) : ℝ := (1 / 2 : ℝ) ^ T.graph.dist r v
  let children (v : V) : Finset V :=
    Finset.univ.filter fun u => T.graph.Adj v u ∧ T.graph.dist r v < T.graph.dist r u
  let parents (v : V) : Finset V :=
    Finset.univ.filter fun u => T.graph.Adj v u ∧ T.graph.dist r u < T.graph.dist r v
  have hparents (v : V) : (∑ u ∈ parents v, weight v) =
      if v = r then 0 else weight v := by
    by_cases hv : v = r
    · subst v
      simp [parents]
    · obtain ⟨u, hu, huniq⟩ := existsUnique_closer_neighbor T.isTree r v hv
      have hsingle : parents v = {u} := by
        ext a
        simp only [parents, Finset.mem_filter, Finset.mem_univ, true_and,
          Finset.mem_singleton]
        exact ⟨huniq a, fun ha => ha.symm ▸ hu⟩
      simp [hsingle, hv]
  have hcount (v : V) :
      (children v).card = if v = r then 1 else if T.IsLeaf v then 0 else 2 := by
    by_cases hv : v = r
    · subst v
      have heq : children r = T.neighborFinset r := by
        ext a
        simp only [children, XTree.neighborFinset, Finset.mem_filter, Finset.mem_univ,
          true_and, SimpleGraph.dist_self]
        exact ⟨And.left, fun ha => ⟨ha, by rw [SimpleGraph.dist_eq_one_iff_adj.mpr ha]; decide⟩⟩
      rw [heq, XTree.card_neighborFinset, if_pos rfl]
      exact hr
    · obtain ⟨u, hu, huniq⟩ := existsUnique_closer_neighbor T.isTree r v hv
      have hmem : u ∈ T.neighborFinset v := by
        simpa [XTree.neighborFinset] using hu.1
      have herase : children v = (T.neighborFinset v).erase u := by
        ext a
        simp only [children, XTree.neighborFinset, Finset.mem_erase, Finset.mem_filter,
          Finset.mem_univ, true_and]
        refine ⟨fun ha => ⟨?_, ha.1⟩, fun ha => ⟨ha.2, ?_⟩⟩
        · intro h
          subst a
          exact (lt_asymm ha.2 hu.2)
        · rcases T.isTree.dist_eq_dist_add_one_of_adj r ha.2 with h | h
          · exact False.elim (ha.1 (huniq a ⟨ha.2, by omega⟩))
          · omega
      rw [herase, Finset.card_erase_of_mem hmem, XTree.card_neighborFinset, if_neg hv]
      by_cases hleaf : T.IsLeaf v
      · rw [if_pos hleaf]
        change Nat.card (T.graph.neighborSet v) = 1 at hleaf
        omega
      · rw [if_neg hleaf, hT.2 v hleaf]
  have hchildren (v : V) : (∑ u ∈ children v, weight u) =
      if v = r then 1 / 2 else if T.IsLeaf v then 0 else weight v := by
    have hfactor : (∑ u ∈ children v, weight u) =
        ((children v).card : ℝ) * (weight v / 2) := by
      rw [← nsmul_eq_mul, ← Finset.sum_const]
      refine Finset.sum_congr rfl fun u hu => ?_
      have hadj : T.graph.Adj v u ∧ T.graph.dist r v < T.graph.dist r u := by
        simpa [children] using hu
      have hdist : T.graph.dist r u = T.graph.dist r v + 1 := by
        rcases T.isTree.dist_eq_dist_add_one_of_adj r hadj.1 with h | h <;> omega
      simp only [weight, hdist, pow_succ]
      ring
    rw [hfactor, hcount]
    by_cases hv : v = r
    · subst v
      simp [weight]
    · by_cases hleaf : T.IsLeaf v <;> simp [hv, hleaf]
      ring
  have hswap : (∑ v, ∑ u ∈ children v, weight u) =
      ∑ v, ∑ u ∈ parents v, weight v := by
    simp_rw [children, parents, Finset.sum_filter]
    rw [Finset.sum_comm]
    simp only [SimpleGraph.adj_comm]
  have hlocal (v : V) :
      (∑ u ∈ parents v, weight v) - (∑ u ∈ children v, weight u) =
        (if v = r then -(1 / 2 : ℝ) else 0) +
        (if T.IsLeaf v ∧ v ≠ r then weight v else 0) := by
    by_cases hv : v = r
    · simp [hparents, hchildren, hv]
    · by_cases hleaf : T.IsLeaf v <;> simp [hparents, hchildren, hv, hleaf]
  have hsum := Finset.sum_congr (s₁ := Finset.univ) rfl (fun v _ => hlocal v)
  rw [Finset.sum_sub_distrib, ← hswap, sub_self, Finset.sum_add_distrib] at hsum
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true, ← Finset.sum_filter] at hsum
  unfold otherLeaves
  change (∑ v ∈ Finset.univ.filter (fun v => T.IsLeaf v ∧ v ≠ r), weight v) = _
  linarith

/-- The binary-tree leaf allocation in the proof of Theorem 5.2.
The probability of reaching \(y\) is twice the weight in this sum. -/
theorem sum_leaf_half_pow_dist [DecidableEq X] (T : XTree X V)
    (hT : T.IsBinaryPhylogenetic) (x : X) :
    ∑ y ∈ Finset.univ.erase x,
      (1 / 2 : ℝ) ^ T.graph.dist (T.label x) (T.label y) = 1 / 2 := by
  classical
  let e : X ↪ V := ⟨T.label, hT.1.1⟩
  have hmap : (Finset.univ.erase x).map e = otherLeaves T (T.label x) := by
    ext v
    simp only [otherLeaves, Finset.mem_map, Finset.mem_erase, Finset.mem_univ, and_true,
      Finset.mem_filter, true_and]
    constructor
    · rintro ⟨y, hne, rfl⟩
      exact ⟨hT.1.2.1 y, fun h => hne (e.injective h)⟩
    · rintro ⟨hleaf, hne⟩
      obtain ⟨y, rfl⟩ := hT.1.2.2 v hleaf
      exact ⟨y, fun h => hne (congrArg T.label h), rfl⟩
  have hsum := sum_leaf_vertex_weights T hT (T.label x) (hT.1.2.1 x)
  rw [← hmap, Finset.sum_map] at hsum
  exact hsum

/-- \(W(T)\), written as half of the ordered pair sum. Distances on the
diagonal vanish, and off-diagonal terms occur once in each order. -/
noncomputable def leafDistanceSum (T : XTree X V) : ℝ :=
  (∑ x : X, ∑ y : X, (T.graph.dist (T.label x) (T.label y) : ℝ)) / 2

theorem leafDistanceSum_eq_sum_unordered [LinearOrder X] (T : XTree X V) :
    leafDistanceSum T = ∑ x : X, ∑ y ∈ Finset.univ with x < y,
      (T.graph.dist (T.label x) (T.label y) : ℝ) := by
  let D (x y : X) : ℝ := T.graph.dist (T.label x) (T.label y)
  let H (x y : X) := if x < y then D x y else 0
  have h (x y : X) : D x y = H x y + H y x := by
    rcases lt_trichotomy x y with h | rfl | h
    · simp [H, h, not_lt_of_ge h.le]
    · simp [H, D]
    · simp [H, h, not_lt_of_ge h.le, D, SimpleGraph.dist_comm]
  simp only [Finset.sum_filter]
  change (∑ x : X, ∑ y : X, D x y) / 2 = ∑ x : X, ∑ y : X, H x y
  simp_rw [h, Finset.sum_add_distrib]
  rw [Finset.sum_comm (f := fun x y => H y x)]
  ring

private theorem lower_of_leaf_weights {ι : Type*} (s : Finset ι) (hs : s.Nonempty)
    (d : ι → ℕ) (hweights : ∑ i ∈ s, (1 / 2 : ℝ) ^ d i = 1 / 2) :
    (s.card : ℝ) * (1 + Real.logb 2 (s.card : ℝ)) ≤ ∑ i ∈ s, (d i : ℝ) := by
  let m : ℝ := s.card
  let L : ℝ := Real.log 2
  have hm : 0 < m := by
    dsimp [m]
    exact_mod_cast hs.card_pos
  have hL : 0 < L := Real.log_pos (by norm_num)
  have hw : (∑ _i ∈ s, m⁻¹) = 1 := by
    rw [Finset.sum_const, nsmul_eq_mul]
    exact mul_inv_cancel₀ hm.ne'
  have he (i : ι) : Real.exp (-L * (d i : ℝ)) = (1 / 2 : ℝ) ^ d i := by
    rw [mul_comm, Real.exp_nat_mul, show -L = -Real.log 2 from rfl,
      Real.exp_neg, Real.exp_log (by norm_num : (0 : ℝ) < 2), one_div]
  have hj := convexOn_exp.map_sum_le (t := s)
    (w := fun _ => m⁻¹) (p := fun i => -L * (d i : ℝ))
    (fun _ _ => inv_nonneg.mpr hm.le) hw (fun _ _ => Set.mem_univ _)
  simp only [smul_eq_mul, he] at hj
  have hin : (∑ i ∈ s, m⁻¹ * (-L * (d i : ℝ))) =
      -L * ((∑ i ∈ s, (d i : ℝ)) / m) := by
    rw [← Finset.mul_sum, ← Finset.mul_sum]
    ring
  rw [hin, ← Finset.mul_sum, hweights] at hj
  have hl := Real.log_le_log (Real.exp_pos _) hj
  rw [Real.log_exp, Real.log_mul (inv_ne_zero hm.ne') (by norm_num),
    Real.log_inv, Real.log_div (by norm_num) (by norm_num), Real.log_one] at hl
  have hprod : L * (1 + Real.log m / L) = L + Real.log m := by
    field_simp [hL.ne']
  have hmean : 1 + Real.logb 2 m ≤ (∑ i ∈ s, (d i : ℝ)) / m := by
    apply (mul_le_mul_iff_right₀ hL).mp
    change L * (1 + Real.log m / L) ≤ _
    rw [hprod]
    change -L * ((∑ i ∈ s, (d i : ℝ)) / m) ≤ -Real.log m + (0 - L) at hl
    linarith
  simpa only [mul_comm] using (le_div_iff₀ hm).mp hmean

/-- Jensen's inequality applied to the leaf weights gives the lower
bound for \(W(T)\) with the constant used in Theorem 5.2. -/
theorem leafDistanceSum_lower (T : XTree X V) (hT : T.IsBinaryPhylogenetic)
    (hn : 2 ≤ Fintype.card X) :
    (Fintype.card X : ℝ) * ((Fintype.card X : ℝ) - 1) *
        (1 + Real.logb 2 ((Fintype.card X : ℝ) - 1)) / 2 ≤ leafDistanceSum T := by
  classical
  let n : ℝ := Fintype.card X
  have hrow (x : X) : (n - 1) * (1 + Real.logb 2 (n - 1)) ≤
      ∑ y : X, (T.graph.dist (T.label x) (T.label y) : ℝ) := by
    have hmem : x ∈ (Finset.univ : Finset X) := Finset.mem_univ x
    have hc : (Finset.univ.erase x).card = Fintype.card X - 1 := by
      rw [Finset.card_erase_of_mem hmem, Finset.card_univ]
    have he : (Finset.univ.erase x).Nonempty := Finset.card_pos.mp (by omega)
    have h := lower_of_leaf_weights (Finset.univ.erase x) he
      (fun y => T.graph.dist (T.label x) (T.label y)) (sum_leaf_half_pow_dist T hT x)
    rw [hc, Nat.cast_sub (by omega : 1 ≤ Fintype.card X), Nat.cast_one] at h
    have hsum := Finset.sum_erase_add (Finset.univ : Finset X)
      (fun y => (T.graph.dist (T.label x) (T.label y) : ℝ)) hmem
    rw [SimpleGraph.dist_self, Nat.cast_zero, add_zero] at hsum
    rwa [hsum] at h
  have hsum := Finset.sum_le_sum (s := (Finset.univ : Finset X)) (fun x _ => hrow x)
  rw [Finset.sum_const, nsmul_eq_mul, Finset.card_univ] at hsum
  unfold leafDistanceSum
  apply (div_le_div_iff_of_pos_right (by norm_num : (0 : ℝ) < 2)).mpr
  simpa only [mul_assoc] using hsum

end

end CTV14
