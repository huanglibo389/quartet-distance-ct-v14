import Mathlib

/-!
The local three-by-three algebra in the proof of Theorem 5.2.
This statement starts with the four groups of squares indexed by the
omitted row and column. It applies once the graph terms have been
reindexed by the two triples of branches.
-/

namespace CTV14

open scoped BigOperators

abbrev BranchMassTable := Fin 3 → Fin 3 → ℝ

def rowTotal (A : BranchMassTable) (i : Fin 3) : ℝ :=
  ∑ j : Fin 3, A i j

def colTotal (A : BranchMassTable) (j : Fin 3) : ℝ :=
  ∑ i : Fin 3, A i j

/-- The centred entry \(X_{ij}=a_{ij}-r_i c_j\). -/
def centredEntry (A : BranchMassTable) (i j : Fin 3) : ℝ :=
  A i j - rowTotal A i * colTotal A j

/-- The two-term permanent on the rows other than i. -/
def complementPermanent (A : BranchMassTable) (i j k : Fin 3) : ℝ :=
  A (i + 1) j * A (i + 2) k + A (i + 1) k * A (i + 2) j

noncomputable def internalEdgeWeight (A : BranchMassTable) (i j : Fin 3) : ℝ :=
  colTotal A (j + 2) / colTotal A j * complementPermanent A i j (j + 1) +
    colTotal A (j + 1) / colTotal A j * complementPermanent A i j (j + 2)

/-- The coefficient \(\beta_{ij}\) in the internal-centre formula. -/
noncomputable def internalCoefficient (A : BranchMassTable) (i j : Fin 3) : ℝ :=
  complementPermanent A i (j + 1) (j + 2) + internalEdgeWeight A i j

/-- The four families after indexing the local terms by the omitted row and
column. The last two use one row reversal representative. -/
noncomputable def internalFourFamilies (A : BranchMassTable) : ℝ :=
  ∑ i : Fin 3, ∑ j : Fin 3,
    (internalEdgeWeight A i j * centredEntry A i j ^ 2 +
      complementPermanent A i (j + 1) (j + 2) *
        (centredEntry A i (j + 1) + centredEntry A i (j + 2)) ^ 2 +
      internalEdgeWeight A i j / 2 *
        (centredEntry A (i + 1) j + centredEntry A (i + 2) j) ^ 2 +
      complementPermanent A i (j + 1) (j + 2) / 2 *
        (centredEntry A (i + 1) (j + 1) + centredEntry A (i + 1) (j + 2) +
         centredEntry A (i + 2) (j + 1) + centredEntry A (i + 2) (j + 2)) ^ 2)

private theorem sum_fin3_cyclic (f : Fin 3 → ℝ) (j : Fin 3) :
    (∑ k : Fin 3, f k) = f j + f (j + 1) + f (j + 2) := by
  rw [Fin.sum_univ_three]
  fin_cases j
  · rfl
  · change _ = f 1 + f 2 + f 0
    abel
  · change _ = f 2 + f 0 + f 1
    abel

theorem internalFourFamilies_eq_coefficients (A : BranchMassTable)
    (hTotal : (∑ i : Fin 3, ∑ j : Fin 3, A i j) = 1) :
    internalFourFamilies A =
      (3 / 2 : ℝ) * ∑ i : Fin 3, ∑ j : Fin 3,
        internalCoefficient A i j * centredEntry A i j ^ 2 := by
  have hrows : (∑ i : Fin 3, rowTotal A i) = 1 := hTotal
  have hcols : (∑ j : Fin 3, colTotal A j) = 1 := by
    unfold colTotal
    rwa [Finset.sum_comm]
  have hr (i : Fin 3) : (∑ j : Fin 3, centredEntry A i j) = 0 := by
    simp only [centredEntry, Finset.sum_sub_distrib, ← Finset.mul_sum, hcols, mul_one]
    exact sub_self (rowTotal A i)
  have hc (j : Fin 3) : (∑ i : Fin 3, centredEntry A i j) = 0 := by
    simp only [centredEntry, Finset.sum_sub_distrib, ← Finset.sum_mul, hrows, one_mul]
    exact sub_self (colTotal A j)
  have hr' (i j : Fin 3) :
      centredEntry A i (j + 1) + centredEntry A i (j + 2) = -centredEntry A i j := by
    have h := hr i
    rw [sum_fin3_cyclic _ j] at h
    linarith
  have hc' (i j : Fin 3) :
      centredEntry A (i + 1) j + centredEntry A (i + 2) j = -centredEntry A i j := by
    have h := hc j
    rw [sum_fin3_cyclic _ i] at h
    linarith
  have hfour i j :
      centredEntry A (i + 1) (j + 1) + centredEntry A (i + 1) (j + 2) +
        centredEntry A (i + 2) (j + 1) + centredEntry A (i + 2) (j + 2) =
        centredEntry A i j := by
    linarith only [hr' (i + 1) j, hr' (i + 2) j, hc' i j]
  unfold internalFourFamilies
  simp_rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun i _ => Finset.sum_congr rfl fun j _ => ?_
  rw [hr', hc', hfour, internalCoefficient]
  ring

/-- The zero row and column sums bound every entry of the contrast
table by the sum of the four absolute contrasts in the child cells. -/
theorem abs_centredEntry_le_child_abs_sum (A : BranchMassTable)
    (hTotal : (∑ i, ∑ j, A i j) = 1) (i j : Fin 3) :
    |centredEntry A i j| ≤ |centredEntry A 1 1| + |centredEntry A 1 2| +
      |centredEntry A 2 1| + |centredEntry A 2 2| := by
  let X := centredEntry A
  change |X i j| ≤ |X 1 1| + |X 1 2| + |X 2 1| + |X 2 2|
  have hc : (∑ j, colTotal A j) = 1 := by
    unfold colTotal
    rwa [Finset.sum_comm]
  have hrow (a : Fin 3) : X a 0 + X a 1 + X a 2 = 0 := by
    rw [← Fin.sum_univ_three (fun b => X a b)]
    change (∑ b, (A a b - rowTotal A a * colTotal A b)) = 0
    rw [Finset.sum_sub_distrib, ← Finset.mul_sum, hc, mul_one]
    exact sub_self (rowTotal A a)
  have hcol (b : Fin 3) : X 0 b + X 1 b + X 2 b = 0 := by
    rw [← Fin.sum_univ_three (fun a => X a b)]
    change (∑ a, (A a b - rowTotal A a * colTotal A b)) = 0
    have hrowTotal : (∑ a, rowTotal A a) = 1 := hTotal
    rw [Finset.sum_sub_distrib, ← Finset.sum_mul, hrowTotal, one_mul]
    exact sub_self (colTotal A b)
  have hcase : ∀ k : Fin 3, k = 0 ∨ k = 1 ∨ k = 2 := by decide
  rcases hcase i with rfl | rfl | rfl <;> rcases hcase j with rfl | rfl | rfl <;>
    rw [abs_le] <;>
    constructor <;>
    linarith only [hrow 0, hrow 1, hrow 2, hcol 0, hcol 1, hcol 2,
      neg_abs_le (X 1 1), le_abs_self (X 1 1), neg_abs_le (X 1 2), le_abs_self (X 1 2),
      neg_abs_le (X 2 1), le_abs_self (X 2 1), neg_abs_le (X 2 2), le_abs_self (X 2 2)]

end CTV14
