import CTV14.BranchMoments
import CTV14.MixedLeafSquares

/-!
The leaf table and the shape-sensitive quartet bound (Theorem 5.1).
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV uW

section Local

variable {X : Type uX} {V : Type uV} [Fintype X] [Fintype V] [LinearOrder V]
  (T : XTree X V)

omit [LinearOrder V] in
private theorem neighborsAtLeaf (hT : T.IsPhylogenetic) (x : X) :
    T.neighborFinset (T.label x) = {leafNeighbour T hT x} := by
  classical
  ext z
  rw [T.mem_neighborFinset, Finset.mem_singleton]
  exact ⟨fun h => (hT.exists_unique_neighbor_label T x).unique h (adj_leafNeighbour T hT x),
    fun hz => hz ▸ adj_leafNeighbour T hT x⟩

private theorem pathsAt_eq_empty_of_leaf (hT : T.IsPhylogenetic) (x : X) :
    pathsAt T (T.label x) = ∅ := by
  classical
  apply Finset.eq_empty_iff_forall_notMem.mpr
  rintro ⟨a, u, b⟩ hp
  simp only [pathsAt, Finset.mem_filter, T.mem_canonicalLengthTwoPathFinset] at hp
  obtain ⟨⟨ha, hb, hab⟩, rfl⟩ := hp
  have h := (hT.exists_unique_neighbor_label T x).unique ha.symm hb
  exact hab.ne h

private theorem pathsAt_eq_triple {u a b c : V}
    (hab : a < b) (hbc : b < c)
    (hN : letI := Classical.decEq V; T.neighborFinset u = {a, b, c}) :
    letI := Classical.decEq V
    pathsAt T u = {(a, u, b), (a, u, c), (b, u, c)} := by
  classical
  letI : DecidableEq V := Classical.decEq V
  have hAdj (v : V) : T.graph.Adj u v ↔ v = a ∨ v = b ∨ v = c := by
    rw [← T.mem_neighborFinset, hN]
    simp
  ext ⟨v, z, w⟩
  simp only [pathsAt, Finset.mem_filter, T.mem_canonicalLengthTwoPathFinset,
    Finset.mem_insert, Finset.mem_singleton, Prod.mk.injEq]
  constructor
  · rintro ⟨⟨hv, hw, hvw⟩, rfl⟩
    have hv' := (hAdj v).mp hv.symm
    have hw' := (hAdj w).mp hw
    grind
  · rintro (⟨rfl, rfl, rfl⟩ | ⟨rfl, rfl, rfl⟩ | ⟨rfl, rfl, rfl⟩)
    · exact ⟨⟨((hAdj _).mpr (Or.inl rfl)).symm, (hAdj _).mpr (Or.inr (Or.inl rfl)), hab⟩, rfl⟩
    · exact ⟨⟨((hAdj _).mpr (Or.inl rfl)).symm, (hAdj _).mpr (Or.inr (Or.inr rfl)), hab.trans hbc⟩, rfl⟩
    · exact ⟨⟨((hAdj _).mpr (Or.inr (Or.inl rfl))).symm, (hAdj _).mpr (Or.inr (Or.inr rfl)), hbc⟩, rfl⟩

omit [LinearOrder V] in
private theorem card_taxa_ge_two (hT : T.IsPhylogenetic) : 2 ≤ Fintype.card X := by
  classical
  letI : Nonempty X := T.taxon_nonempty
  let x : X := Classical.choice (inferInstance : Nonempty X)
  have ha := adj_leafNeighbour T hT x
  have hs := T.edgeSide_nonempty_of_adj ha
  rw [T.edgeSide_reverse_eq_compl ha.symm, hT.edgeSide_pendant_eq_singleton T x ha] at hs
  obtain ⟨y, hy⟩ := hs
  exact Fintype.one_lt_card_iff.mpr ⟨y, x, by simpa using hy⟩

end Local

section TwoTrees

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W] [LinearOrder V] [LinearOrder W]
  (T₁ : XTree X V) (T₂ : XTree X W)

private theorem centredSquares_at_two_leaves
    (h₁ : T₁.IsPhylogenetic) (h₂ : T₂.IsPhylogenetic) (x y : X) :
    centredSquares T₁ T₂ (T₁.label x) (T₂.label y) =
      qTerm T₁ T₂ (leafNeighbour T₁ h₁ x, T₁.label x) (leafNeighbour T₂ h₂ y, T₂.label y) := by
  simp [centredSquares_eq_local_sums, neighborsAtLeaf T₁ h₁ x, neighborsAtLeaf T₂ h₂ y,
    pathsAt_eq_empty_of_leaf T₁ h₁ x, pathsAt_eq_empty_of_leaf T₂ h₂ y]

/-- The second row of the leaf contribution table in Theorem 5.1. -/
theorem scaled_sum_leaf_internal_centredSquares
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic)
    {w : W} (hw : ¬ T₂.IsLeaf w) :
    (Fintype.card X : ℝ)^4 * (∑ x : X, centredSquares T₁ T₂ (T₁.label x) w) =
      branchPairProducts T₂ w - 3 * branchProduct T₂ w / Fintype.card X := by
  classical
  letI : DecidableEq W := Classical.decEq W
  obtain ⟨a, b, c, hab, hbc, hN⟩ := exists_ordered_neighbor_triple T₂ h₂ hw
  have hac := hab.trans hbc
  have hNb : T₂.neighborFinset w = {b, a, c} := by
    rw [hN]
    ext k
    simp [or_left_comm]
  have hNc : T₂.neighborFinset w = {c, a, b} := by
    rw [hN]
    ext k
    simp [or_comm, or_left_comm]
  have hpath := pathsAt_eq_triple T₂ hab hbc hN
  have hf (x : X) : centredSquares T₁ T₂ (T₁.label x) w =
      (∑ v ∈ T₂.neighborFinset w, qTerm T₁ T₂ (leafNeighbour T₁ h₁.1 x, T₁.label x) (v, w)) +
      (∑ p ∈ pathsAt T₂ w, sTerm T₁ T₂ (leafNeighbour T₁ h₁.1 x, T₁.label x) p) := by
    simp [centredSquares_eq_local_sums, neighborsAtLeaf T₁ h₁.1 x, pathsAt_eq_empty_of_leaf T₁ h₁.1 x]
  simp_rw [hf, Finset.sum_add_distrib]
  rw [Finset.sum_comm (s := Finset.univ) (t := T₂.neighborFinset w),
    Finset.sum_comm (s := Finset.univ) (t := pathsAt T₂ w), hN, hpath]
  simp [Finset.sum_insert, hab.ne, hbc.ne, hac.ne]
  rw [sum_leaf_internal_qTerm T₁ T₂ h₁.1 h₂.1 hw hN hab.ne hac.ne hbc.ne,
    sum_leaf_internal_qTerm T₁ T₂ h₁.1 h₂.1 hw hNb hab.ne' hbc.ne hac.ne,
    sum_leaf_internal_qTerm T₁ T₂ h₁.1 h₂.1 hw hNc hac.ne' hbc.ne' hab.ne,
    sum_leaf_internal_sTerm T₁ T₂ h₁.1 h₂.1 hw hNc hac.ne' hbc.ne' hab.ne,
    sum_leaf_internal_sTerm T₁ T₂ h₁.1 h₂.1 hw hNb hab.ne' hbc.ne hac.ne,
    sum_leaf_internal_sTerm T₁ T₂ h₁.1 h₂.1 hw hN hab.ne hac.ne hbc.ne,
    branchPairProducts_eq_triple T₂ h₂.1 hw hN hab.ne hac.ne hbc.ne,
    branchProduct_eq_triple T₂ hN hab.ne hac.ne hbc.ne]
  have ⟨ha, hb, hc⟩ := adj_of_neighbor_triple T₂ hN
  have hs := neighbour_mass_sum_trivalent T₂ h₂.1 w a b c hw hN hab.ne hac.ne hbc.ne
  unfold XTree.rowMass at hs
  rw [T₂.rowBlock_of_adj a ha, T₂.rowBlock_of_adj a hb, T₂.rowBlock_of_adj a hc] at hs
  let n : ℝ := Fintype.card X
  have hn0 : n ≠ 0 := by
    letI : Nonempty X := T₂.taxon_nonempty
    change (Fintype.card X : ℝ) ≠ 0
    exact_mod_cast Fintype.card_ne_zero (α := X)
  have hscale (z : W) : branchSize T₂ w z = n * normalizedCard (T₂.edgeSide w z) := by
    unfold branchSize normalizedCard
    change _ = n * (_ / n)
    field_simp [hn0]
  rw [hscale a, hscale b, hscale c]
  change n^4 * _ = _ - _ / n
  have hunit : unitMass X = 1 / n := rfl
  rw [hunit]
  field_simp [hn0]
  linear_combination 3 * normalizedCard (T₂.edgeSide w a) *
    normalizedCard (T₂.edgeSide w b) * normalizedCard (T₂.edgeSide w c) * hs

/-- The third row of the leaf contribution table in Theorem 5.1. -/
theorem scaled_sum_internal_leaf_centredSquares
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic)
    {u : V} (hu : ¬ T₁.IsLeaf u) :
    (Fintype.card X : ℝ)^4 * (∑ x : X, centredSquares T₁ T₂ u (T₂.label x)) =
      3 * branchProduct T₁ u / ((Fintype.card X : ℝ) - 1) := by
  classical
  letI : DecidableEq V := Classical.decEq V
  obtain ⟨a, b, c, hab, hbc, hN⟩ := exists_ordered_neighbor_triple T₁ h₁ hu
  have hac := hab.trans hbc
  have hNb : T₁.neighborFinset u = {b, a, c} := by
    rw [hN]
    ext k
    simp [or_left_comm]
  have hNc : T₁.neighborFinset u = {c, a, b} := by
    rw [hN]
    ext k
    simp [or_comm, or_left_comm]
  have hpath := pathsAt_eq_triple T₁ hab hbc hN
  have hf (x : X) : centredSquares T₁ T₂ u (T₂.label x) =
      (∑ t ∈ T₁.neighborFinset u, qTerm T₁ T₂ (t, u) (leafNeighbour T₂ h₂.1 x, T₂.label x)) +
      (∑ p ∈ pathsAt T₁ u, bTerm T₁ T₂ p (leafNeighbour T₂ h₂.1 x, T₂.label x)) := by
    simp [centredSquares_eq_local_sums, neighborsAtLeaf T₂ h₂.1 x, pathsAt_eq_empty_of_leaf T₂ h₂.1 x]
  simp_rw [hf, Finset.sum_add_distrib]
  rw [Finset.sum_comm (s := Finset.univ) (t := T₁.neighborFinset u),
    Finset.sum_comm (s := Finset.univ) (t := pathsAt T₁ u), hN, hpath]
  simp [Finset.sum_insert, hab.ne, hbc.ne, hac.ne]
  rw [sum_internal_leaf_qTerm T₁ T₂ h₁.1 h₂.1 hu hN hab.ne hac.ne hbc.ne,
    sum_internal_leaf_qTerm T₁ T₂ h₁.1 h₂.1 hu hNb hab.ne' hbc.ne hac.ne,
    sum_internal_leaf_qTerm T₁ T₂ h₁.1 h₂.1 hu hNc hac.ne' hbc.ne' hab.ne,
    sum_internal_leaf_bTerm T₁ T₂ h₁.1 h₂.1 hu hNc hac.ne' hbc.ne' hab.ne,
    sum_internal_leaf_bTerm T₁ T₂ h₁.1 h₂.1 hu hNb hab.ne' hbc.ne hac.ne,
    sum_internal_leaf_bTerm T₁ T₂ h₁.1 h₂.1 hu hN hab.ne hac.ne hbc.ne,
    branchProduct_eq_triple T₁ hN hab.ne hac.ne hbc.ne]
  have ⟨ha, hb, hc⟩ := adj_of_neighbor_triple T₁ hN
  have hs := neighbour_mass_sum_trivalent T₁ h₁.1 u a b c hu hN hab.ne hac.ne hbc.ne
  unfold XTree.rowMass at hs
  rw [T₁.rowBlock_of_adj a ha, T₁.rowBlock_of_adj a hb, T₁.rowBlock_of_adj a hc] at hs
  let n : ℝ := Fintype.card X
  have hn : (2 : ℝ) ≤ n := by
    change (2 : ℝ) ≤ (Fintype.card X : ℝ)
    exact_mod_cast card_taxa_ge_two T₁ h₁.1
  have hn0 : n ≠ 0 := by linarith
  have hn1 : n - 1 ≠ 0 := by linarith
  have hscale (z : V) : branchSize T₁ u z = n * normalizedCard (T₁.edgeSide u z) := by
    unfold branchSize normalizedCard
    change _ = n * (_ / n)
    field_simp [hn0]
  rw [hscale a, hscale b, hscale c]
  change n^4 * _ = _ / (n - 1)
  have hunit : unitMass X = 1 / n := rfl
  rw [hunit]
  have hd : (1 - 1 / n) = (n - 1) / n := by field_simp [hn0]
  rw [hd]
  field_simp [hn0, hn1]
  linear_combination 3 * normalizedCard (T₁.edgeSide u a) *
    normalizedCard (T₁.edgeSide u b) * normalizedCard (T₁.edgeSide u c) * hs

private theorem leafCentredSquares_split :
    leafCentredSquares T₁ T₂ =
      (∑ u ∈ leafVertices T₁, ∑ w ∈ leafVertices T₂, centredSquares T₁ T₂ u w) +
      (∑ w ∈ internalVertices T₂, ∑ u ∈ leafVertices T₁, centredSquares T₁ T₂ u w) +
      (∑ u ∈ internalVertices T₁, ∑ w ∈ leafVertices T₂, centredSquares T₁ T₂ u w) := by
  classical
  rw [Finset.sum_comm (s := internalVertices T₂) (t := leafVertices T₁)]
  unfold leafCentredSquares
  simp only [leafVertices, internalVertices, Finset.sum_filter, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun u _ => ?_
  by_cases hu : T₁.IsLeaf u <;> simp only [hu, true_or, false_or, not_true_eq_false,
    not_false_eq_true, if_true, if_false, add_zero, zero_add]
  · rw [← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun w _ => by split_ifs <;> simp

/-- The scaled sum over all centre pairs with at least one leaf equals
the distance sum in the second tree. -/
theorem scaled_leafCentredSquares_eq_leafDistance
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    (Fintype.card X : ℝ)^4 * leafCentredSquares T₁ T₂ = leafDistanceSum T₂ := by
  classical
  let n : ℝ := Fintype.card X
  have hn : 2 ≤ Fintype.card X := card_taxa_ge_two T₁ h₁.1
  have hn' : (2 : ℝ) ≤ n := by
    change (2 : ℝ) ≤ (Fintype.card X : ℝ)
    exact_mod_cast hn
  have hn0 : n ≠ 0 := by linarith
  have hn1 : n - 1 ≠ 0 := by linarith
  have hP :
      (Fintype.card X : ℝ)^4 *
          (∑ x : X, ∑ y : X, centredSquares T₁ T₂ (T₁.label x) (T₂.label y)) =
        (((Fintype.card X : ℝ) - 1)^2 + 1) / 2 := by
    simp_rw [centredSquares_at_two_leaves T₁ T₂ h₁.1 h₂.1]
    exact scaled_pendantSquareSum T₁ T₂ h₁.1 h₂.1 hn
  have hMix₁ :
      (∑ w ∈ internalVertices T₂,
        (Fintype.card X : ℝ)^4 * (∑ x : X, centredSquares T₁ T₂ (T₁.label x) w)) =
        (∑ w ∈ internalVertices T₂, branchPairProducts T₂ w) -
          3 * (∑ w ∈ internalVertices T₂, branchProduct T₂ w) / n := by
    simp only [Finset.mul_sum, Finset.sum_div, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun w hw => ?_
    simpa only [Finset.mul_sum] using
      scaled_sum_leaf_internal_centredSquares T₁ T₂ h₁ h₂ (Finset.mem_filter.mp hw).2
  have hMix₂ :
      (∑ u ∈ internalVertices T₁,
        (Fintype.card X : ℝ)^4 * (∑ x : X, centredSquares T₁ T₂ u (T₂.label x))) =
        3 * (∑ u ∈ internalVertices T₁, branchProduct T₁ u) / (n - 1) := by
    simp only [Finset.mul_sum, Finset.sum_div]
    refine Finset.sum_congr rfl fun u hu => ?_
    simpa only [Finset.mul_sum] using
      scaled_sum_internal_leaf_centredSquares T₁ T₂ h₁ h₂ (Finset.mem_filter.mp hu).2
  rw [leafCentredSquares_split, leafVertices_eq_map T₁ h₁.1, leafVertices_eq_map T₂ h₂.1]
  simp only [Finset.sum_map, Function.Embedding.coeFn_mk, mul_add]
  rw [hP, Finset.mul_sum (s := internalVertices T₂), hMix₁,
    Finset.mul_sum (s := internalVertices T₁), hMix₂,
    sum_internal_branchProduct T₁ h₁, sum_internal_branchProduct T₂ h₂,
    leafDistanceSum_eq_choose_two_add_branchPairProducts T₂ h₂, Nat.cast_choose_two]
  change ((n - 1)^2 + 1) / 2 + (_ - 3 * (n * (n - 1) * (n - 2) / 6) / n) +
    3 * (n * (n - 1) * (n - 2) / 6) / (n - 1) = n * (n - 1) / 2 + _
  field_simp [hn0, hn1]
  ring

/-- The deficit formula (5.1) before using the symmetry of quartet distance. -/
theorem binaryDeficitFormula
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) =
      leafDistanceSum T₂ / 6 + (Fintype.card X : ℝ)^4 / 6 * internalCentredSquares T₁ T₂ := by
  rw [quartetBound_sub_distance_eq_centredSquares T₁ T₂ h₁ h₂,
    ← scaled_leafCentredSquares_eq_leafDistance T₁ T₂ h₁ h₂]
  ring

end TwoTrees

section Bounds

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W]
  (T₁ : XTree X V) (T₂ : XTree X W)

theorem quartetDistance_symm : quartetDistance T₁ T₂ = quartetDistance T₂ T₁ := by
  unfold quartetDistance
  congr 1
  ext s
  simp only [mem_quartetDisagreementSupports, TreesDisagreeOnQuartetSupport]
  constructor <;> rintro ⟨hcard, P, Q, hP, hQ, hTP, hTQ, hSP, hSQ, hPQ⟩ <;>
    exact ⟨hcard, Q, P, hQ, hP, hTQ, hTP, hSQ, hSP, hPQ.symm⟩

/-- Theorem 5.1 for finite binary phylogenetic (X)-trees. -/
theorem quartetDistance_le_shape_bound
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    (quartetDistance T₁ T₂ : ℝ) ≤
      quartetBound (Fintype.card X) - max (leafDistanceSum T₁) (leafDistanceSum T₂) / 6 := by
  classical
  letI : LinearOrder V := LinearOrder.lift' (Fintype.equivFin V) (Fintype.equivFin V).injective
  letI : LinearOrder W := LinearOrder.lift' (Fintype.equivFin W) (Fintype.equivFin W).injective
  have hforward := quartetDeficit_ge_leafDistance_of_leaf_identity T₁ T₂ h₁ h₂
    (scaled_leafCentredSquares_eq_leafDistance T₁ T₂ h₁ h₂)
  have hbackward := quartetDeficit_ge_leafDistance_of_leaf_identity T₂ T₁ h₂ h₁
    (scaled_leafCentredSquares_eq_leafDistance T₂ T₁ h₂ h₁)
  rw [← quartetDistance_symm T₁ T₂] at hbackward
  rcases le_total (leafDistanceSum T₁) (leafDistanceSum T₂) with h | h
  · rw [max_eq_right h]
    linarith only [hforward]
  · rw [max_eq_left h]
    linarith only [hbackward]

/-- The logarithmic lower bound on the deficit holds for every pair of
binary phylogenetic trees. -/
theorem log_lower_le_quartetDeficit
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    (Fintype.card X : ℝ) * ((Fintype.card X : ℝ) - 1) *
      (1 + Real.logb 2 ((Fintype.card X : ℝ) - 1)) / 12 ≤
        quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) := by
  classical
  letI : LinearOrder W := LinearOrder.lift' (Fintype.equivFin W) (Fintype.equivFin W).injective
  have hlog := leafDistanceSum_lower T₂ h₂ (card_taxa_ge_two T₂ h₂.1)
  have hmax : leafDistanceSum T₂ ≤ max (leafDistanceSum T₁) (leafDistanceSum T₂) := le_max_right _ _
  have hshape := quartetDistance_le_shape_bound T₁ T₂ h₁ h₂
  linarith only [hlog, hmax, hshape]

end Bounds

end CTV14
