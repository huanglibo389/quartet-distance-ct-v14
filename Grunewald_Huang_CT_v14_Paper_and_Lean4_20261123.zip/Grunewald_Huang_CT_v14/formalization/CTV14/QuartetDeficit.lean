import QDFull.BinaryPhylogeneticQuartetCounts
import Mathlib.Data.Nat.Choose.Cast

/-!
The exact deficit below \(U_n\) in Section 5, using the v8 quartet counts
and the v8 sum-of-squares identity.
-/

namespace CTV14

open QDFull

/-- The finite reference bound \(U_n\), in the manuscript's units. -/
noncomputable def quartetBound (n : ℕ) : ℝ :=
  (2 / 3 : ℝ) * n.choose 4 + n.choose 3 + (1 / 6 : ℝ) * n.choose 2

theorem quartetBound_eq_polynomial (n : ℕ) :
    quartetBound n = ((n : ℝ)^4 - 4 * (n : ℝ)^2 + 3 * n) / 36 := by
  by_cases hn : 4 ≤ n
  · have h3 := congrArg (fun k : ℕ => (k : ℝ))
      (Nat.descFactorial_eq_factorial_mul_choose n 3)
    have h4 := congrArg (fun k : ℕ => (k : ℝ))
      (Nat.descFactorial_eq_factorial_mul_choose n 4)
    have h1' : 1 ≤ n := by omega
    have h2' : 2 ≤ n := by omega
    have h3' : 3 ≤ n := by omega
    norm_num [Nat.descFactorial_succ, Nat.cast_sub h1', Nat.cast_sub h2',
      Nat.cast_sub h3', Nat.factorial] at h3 h4
    rw [quartetBound, Nat.cast_choose_two]
    linear_combination - h3 / 6 - h4 / 36
  · have : n < 4 := by omega
    interval_cases n <;> norm_num [quartetBound, Nat.choose]

section

universe uX uV uW
variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W]

/-- The binary specialization of the quartet-count formula, solved for the
deficit. The units are ordinary quartet counts. -/
theorem quartetBound_sub_distance_eq_covariance
    (T₁ : XTree X V) (T₂ : XTree X W)
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) =
      (Fintype.card X : ℝ)^4 * treeQuartetCovariance T₁ T₂ / 36 := by
  classical
  have hcount := treeQuartetCovariance_eq_quartetCounts T₁ T₂
  rw [card_commonDisplayedPartialQuartets_two T₁ T₂ h₁ h₂,
    card_commonDisplayedPartialQuartets_three T₁ T₂ h₁ h₂] at hcount
  have hfour : ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
      (quartetDistance T₁ T₂ : ℝ) = (Fintype.card X).choose 4 := by
    exact_mod_cast card_commonQuartets_add_quartetDistance T₁ T₂ h₁ h₂
  have hcard : (Fintype.card X : ℝ) ≠ 0 := by
    exact_mod_cast (Fintype.card_pos_iff.mpr T₁.taxon_nonempty).ne'
  push_cast at hcount
  have hscaled : (Fintype.card X : ℝ)^4 * treeQuartetCovariance T₁ T₂ =
      24 * ((commonDisplayedPartialQuartets T₁ T₂ 4).card : ℝ) +
      36 * ((Fintype.card X).choose 3 : ℝ) +
      6 * ((Fintype.card X).choose 2 : ℝ) -
      12 * (quartetDistance T₁ T₂ : ℝ) := by
    rw [hcount]
    field_simp [hcard]
    ring
  unfold quartetBound
  linear_combination - hscaled / 36 - (2 / 3 : ℝ) * hfour

/-- The coefficient multiplying the regrouped square sum in (5.1). -/
theorem quartetBound_sub_distance_eq_sumOfSquares
    [DecidableEq X] [LinearOrder V] [LinearOrder W]
    (T₁ : XTree X V) (T₂ : XTree X W)
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) =
      (Fintype.card X : ℝ)^4 / 6 * sumOfSquaresRhs T₁ T₂ := by
  rw [quartetBound_sub_distance_eq_covariance T₁ T₂ h₁ h₂,
    sumOfSquaresRhs_eq_treeQuartetCovariance_div_six]
  ring

end

end CTV14
