import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Data.Nat.ModEq
import Mathlib.Data.Real.Basic
import Mathlib.Tactic

/-!
The cardinalities used to compare the prefix-tree intervals and the
suffix-tree residue classes in the proof of Theorem 5.2.
-/

namespace CTV14

private theorem mul_add_lt_mul_add_iff {i j d r s : ℕ}
    (hr : r < d) (hs : s < d) :
    i * d + r < j * d + s ↔ i < j ∨ i = j ∧ r < s := by
  rcases lt_trichotomy i j with hij | rfl | hji
  · have h := Nat.mul_le_mul_right d (Nat.succ_le_of_lt hij)
    rw [Nat.succ_mul] at h
    have h' : i * d + r < j * d + s := by omega
    simp [hij, h']
  · simp
  · have h := Nat.mul_le_mul_right d (Nat.succ_le_of_lt hji)
    rw [Nat.succ_mul] at h
    have h' : ¬ i * d + r < j * d + s := by omega
    simp [not_lt_of_gt hji, ne_of_gt hji, h']

private theorem div_mul_add_mod (n d : ℕ) : n / d * d + n % d = n := by
  rw [Nat.mul_comm, Nat.div_add_mod]

private theorem mul_add_div_of_lt {d r : ℕ} (hr : r < d) (i : ℕ) :
    (i * d + r) / d = i := by
  have hd : 0 < d := by omega
  rw [Nat.mul_comm i d, Nat.mul_add_div hd, Nat.div_eq_of_lt hr]
  omega

/-- The number of labels of one residue class in an initial interval. -/
theorem card_range_filter_mod (n d r : ℕ) (hr : r < d) :
    ((Finset.range n).filter fun x => x % d = r).card =
      n / d + if r < n % d then 1 else 0 := by
  have hd : 0 < d := by omega
  have hlt (i : ℕ) :
      i * d + r < n ↔ i < n / d + if r < n % d then 1 else 0 := by
    calc
      _ ↔ i * d + r < n / d * d + n % d := by rw [div_mul_add_mod]
      _ ↔ _ := by
        rw [mul_add_lt_mul_add_iff hr (Nat.mod_lt n hd)]
        by_cases h : r < n % d
        · simp [h]
          omega
        · simp [h]
  rw [← Finset.card_range (n / d + if r < n % d then 1 else 0)]
  symm
  apply Finset.card_bij (fun i _ => i * d + r)
  · intro i hi
    rw [Finset.mem_filter, Finset.mem_range]
    exact ⟨(hlt i).2 (Finset.mem_range.mp hi), by simp [Nat.mod_eq_of_lt hr]⟩
  · intro i _ j _ heq
    simpa only [mul_add_div_of_lt hr] using congrArg (· / d) heq
  · intro x hx
    rw [Finset.mem_filter, Finset.mem_range] at hx
    have heq : x / d * d + r = x := by rw [← hx.2, div_mul_add_mod]
    refine ⟨x / d, Finset.mem_range.mpr ((hlt _).1 ?_), heq⟩
    simpa only [heq] using hx.1

/-- Every aligned block of length k * d has k labels of each
residue. In the proof, d can be the child modulus 2D. -/
theorem card_Ico_filter_mod_aligned (q k d r : ℕ) (hr : r < d) :
    ((Finset.Ico (q * d) ((q + k) * d)).filter fun x => x % d = r).card = k := by
  have hd : 0 < d := by omega
  have hlt (i j : ℕ) : i * d + r < j * d ↔ i < j := by
    rw [← Nat.add_zero (j * d), mul_add_lt_mul_add_iff hr hd]
    simp
  have hb (i : ℕ) : q * d ≤ i * d + r ↔ q ≤ i := by
    simpa only [not_lt] using not_congr (hlt i q)
  have hcard : (Finset.Ico q (q + k)).card =
      ((Finset.Ico (q * d) ((q + k) * d)).filter fun x => x % d = r).card := by
    apply Finset.card_bij (fun i _ => i * d + r)
    · intro i hi
      rw [Finset.mem_Ico] at hi
      rw [Finset.mem_filter, Finset.mem_Ico]
      exact ⟨⟨(hb i).2 hi.1, (hlt i (q + k)).2 hi.2⟩, by simp [Nat.mod_eq_of_lt hr]⟩
    · intro i _ j _ heq
      simpa only [mul_add_div_of_lt hr] using congrArg (· / d) heq
    · intro x hx
      rw [Finset.mem_filter, Finset.mem_Ico] at hx
      have heq : x / d * d + r = x := by rw [← hx.2, div_mul_add_mod]
      refine ⟨x / d, Finset.mem_Ico.mpr ⟨(hb _).1 ?_, (hlt _ (q + k)).1 ?_⟩, heq⟩
      · rw [heq]
        exact hx.1.1
      · rw [heq]
        exact hx.1.2
  rw [← hcard, Nat.card_Ico, Nat.add_sub_cancel_left]

/-- An interval intersection has the exact residue count after
translating the interval to start at zero. -/
theorem card_Ico_filter_mod (a len d r : ℕ) (hr : r < d) :
    ((Finset.Ico a (a + len)).filter fun x => x % d = r).card =
      len / d + if (r + d - a % d) % d < len % d then 1 else 0 := by
  have hd : 0 < d := by omega
  let δ := (r + d - a % d) % d
  have hδ : δ < d := Nat.mod_lt _ hd
  have hadd : a + δ ≡ r [MOD d] := by
    unfold Nat.ModEq
    have hsum : a % d + (r + d - a % d) = r + d := by
      have := Nat.mod_lt a hd
      omega
    dsimp [δ]
    rw [Nat.add_mod_mod, ← Nat.mod_add_mod, hsum]
    simp
  have hmod (i : ℕ) : (a + i) % d = r ↔ i % d = δ := by
    have hr' : r % d = r := Nat.mod_eq_of_lt hr
    have hδ' : δ % d = δ := Nat.mod_eq_of_lt hδ
    constructor
    · intro h
      have hi : a + i ≡ r [MOD d] := by simpa [Nat.ModEq, hr'] using h
      have hi' := Nat.ModEq.add_left_cancel' a (hi.trans hadd.symm)
      simpa [Nat.ModEq, hδ'] using hi'
    · intro h
      have hi : i ≡ δ [MOD d] := by simpa [Nat.ModEq, hδ'] using h
      simpa [Nat.ModEq, hr'] using (hi.add_left a).trans hadd
  rw [← card_range_filter_mod len d δ hδ]
  symm
  apply Finset.card_bij (fun i _ => a + i)
  · intro i hi
    rw [Finset.mem_filter, Finset.mem_range] at hi
    exact Finset.mem_filter.mpr ⟨Finset.mem_Ico.mpr ⟨by omega, by omega⟩, (hmod i).mpr hi.2⟩
  · intro i _ j _ hij
    omega
  · intro x hx
    rw [Finset.mem_filter, Finset.mem_Ico] at hx
    have hax : a + (x - a) = x := by omega
    refine ⟨x - a, Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (by omega), (hmod _).mp ?_⟩, hax⟩
    simpa only [hax] using hx.2

/-- The count in a possibly incomplete row interval differs from
its length divided by the modulus by at most one. -/
theorem abs_card_Ico_filter_mod_sub_length_div_le_one (a len d r : ℕ) (hr : r < d) :
    |(((Finset.Ico a (a + len)).filter fun x => x % d = r).card : ℝ) -
      (len : ℝ) / d| ≤ 1 := by
  have hd : 0 < d := by omega
  have hd' : (0 : ℝ) < d := by exact_mod_cast hd
  have hq := congrArg (fun k : ℕ => (k : ℝ)) (div_mul_add_mod len d)
  push_cast at hq
  have hrem : (0 : ℝ) ≤ (len % d : ℕ) := Nat.cast_nonneg _
  have hrem' : ((len % d : ℕ) : ℝ) ≤ (d : ℝ) := by exact_mod_cast (Nat.mod_lt len hd).le
  have hlo : ((len / d : ℕ) : ℝ) ≤ (len : ℝ) / d :=
    (le_div_iff₀ hd').mpr (by linarith only [hq, hrem])
  have hhi : (len : ℝ) / d ≤ ((len / d : ℕ) : ℝ) + 1 :=
    (div_le_iff₀ hd').mpr (by linarith only [hq, hrem'])
  rw [card_Ico_filter_mod a len d r hr, abs_le]
  push_cast
  split_ifs <;> norm_num <;> constructor <;> linarith only [hlo, hhi]

end CTV14
