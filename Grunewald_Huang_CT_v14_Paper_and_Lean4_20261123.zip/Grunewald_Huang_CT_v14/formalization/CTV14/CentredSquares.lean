import CTV14.LeafDistance
import CTV14.QuartetDeficit
import QDFull.CoefficientLowerBound

/-!
Regroup the four v8 sums by the two centres, as in \(F_{u,w}\) of
Section 5. The exact deficit splits into the leaf and internal terms.
-/

namespace CTV14

open QDFull
open scoped BigOperators

universe uX uV uW

private noncomputable def atCentres {α β V W : Type*} (s : Finset α) (t : Finset β)
    (first : α → V) (second : β → W) (f : α → β → ℝ) (u : V) (w : W) : ℝ := by
  classical
  exact ∑ a ∈ s, ∑ b ∈ t, if first a = u ∧ second b = w then f a b else 0

private theorem sum_atCentres {α β V W : Type*} [Fintype V] [Fintype W]
    (s : Finset α) (t : Finset β) (first : α → V) (second : β → W)
    (f : α → β → ℝ) :
    (∑ u : V, ∑ w : W, atCentres s t first second f u w) = ∑ a ∈ s, ∑ b ∈ t, f a b := by
  classical
  unfold atCentres
  rw [Finset.sum_comm]
  simp_rw [Finset.sum_comm (s := (Finset.univ : Finset V)) (t := s)]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  simp_rw [Finset.sum_comm (s := (Finset.univ : Finset V)) (t := t),
    Finset.sum_comm (s := (Finset.univ : Finset W)) (t := t)]
  apply Finset.sum_congr rfl
  intro b _
  by_cases h : first a ∈ (Finset.univ : Finset V)
  · simp [ite_and, eq_comm]
  · exact (h (Finset.mem_univ _)).elim

private theorem atCentres_nonneg {α β V W : Type*}
    (s : Finset α) (t : Finset β) (first : α → V) (second : β → W)
    (f : α → β → ℝ) (u : V) (w : W)
    (hf : ∀ a ∈ s, ∀ b ∈ t, 0 ≤ f a b) :
    0 ≤ atCentres s t first second f u w := by
  classical
  unfold atCentres
  refine Finset.sum_nonneg fun a ha => Finset.sum_nonneg fun b hb => ?_
  split_ifs with h
  · exact hf a ha b hb
  · exact le_rfl

section

variable {X : Type uX} {V : Type uV} {W : Type uW}
  [Fintype X] [Fintype V] [Fintype W] [LinearOrder V] [LinearOrder W]
  (T₁ : XTree X V) (T₂ : XTree X W)

noncomputable def qTerm (e₁ : V × V) (e₂ : W × W) : ℝ :=
  lemma3CoefficientSum T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 *
    xCoefficient T₁ T₂ e₁.1 e₁.2 e₂.1 e₂.2 ^ 2

noncomputable def sTerm (e₁ : V × V) (p₂ : W × W × W) : ℝ :=
  ∑ z ∈ T₁.indexIFinset e₁.1 e₁.2,
    sCoefficient T₁ T₂ e₁.1 e₁.2 z.1 z.2 p₂.1 p₂.2.1 p₂.2.2 *
      (xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.1 p₂.2.1 +
        xCoefficient T₁ T₂ e₁.1 e₁.2 p₂.2.2 p₂.2.1) ^ 2

noncomputable def bTerm (p₁ : V × V × V) (e₂ : W × W) : ℝ :=
  ∑ z ∈ T₂.indexIFinset e₂.1 e₂.2,
    bCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2 e₂.1 e₂.2 z.1 z.2 *
      (xCoefficient T₁ T₂ p₁.1 p₁.2.1 e₂.1 e₂.2 +
        xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 e₂.1 e₂.2) ^ 2

noncomputable def pTerm (p₁ : V × V × V) (p₂ : W × W × W) : ℝ :=
  pCoefficient T₁ T₂ p₁.1 p₁.2.1 p₁.2.2 p₂.1 p₂.2.1 p₂.2.2 *
    (xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.1 p₂.2.1 +
      xCoefficient T₁ T₂ p₁.1 p₁.2.1 p₂.2.2 p₂.2.1 +
      xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.1 p₂.2.1 +
      xCoefficient T₁ T₂ p₁.2.2 p₁.2.1 p₂.2.2 p₂.2.1) ^ 2

/-- \(F_{u,w}\) is the sum of the original square terms centred at \(u,w\). -/
noncomputable def centredSquares (u : V) (w : W) : ℝ :=
  atCentres T₁.directedEdgeFinset T₂.directedEdgeFinset Prod.snd Prod.snd
      (qTerm T₁ T₂) u w +
    atCentres T₁.directedEdgeFinset T₂.canonicalLengthTwoPathFinset
      Prod.snd (fun p => p.2.1) (sTerm T₁ T₂) u w +
    atCentres T₁.canonicalLengthTwoPathFinset T₂.directedEdgeFinset
      (fun p => p.2.1) Prod.snd (bTerm T₁ T₂) u w +
    atCentres T₁.canonicalLengthTwoPathFinset T₂.canonicalLengthTwoPathFinset
      (fun p => p.2.1) (fun p => p.2.1) (pTerm T₁ T₂) u w

private theorem atCentres_eq_filtered {α β V W : Type*}
    (s : Finset α) (t : Finset β) (first : α → V) (second : β → W)
    (f : α → β → ℝ) (u : V) (w : W) :
    letI := Classical.decEq V
    letI := Classical.decEq W
    atCentres s t first second f u w =
      ∑ a ∈ s.filter (fun a => first a = u), ∑ b ∈ t.filter (fun b => second b = w), f a b := by
  classical
  unfold atCentres
  simp only [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro a _
  by_cases h : first a = u <;> simp [h]

private def incomingEdge (u : V) : V ↪ V × V :=
  ⟨fun t => (t, u), fun _ _ h => congrArg Prod.fst h⟩

omit [LinearOrder V] in
private theorem incomingEdges_eq_map (T : XTree X V) (u : V) :
    letI := Classical.decEq V
    T.directedEdgeFinset.filter (fun e => e.2 = u) =
      (T.neighborFinset u).map (incomingEdge u) := by
  classical
  ext ⟨t, u'⟩
  simp only [Finset.mem_filter, T.mem_directedEdgeFinset, Finset.mem_map,
    T.mem_neighborFinset, incomingEdge, Function.Embedding.coeFn_mk, Prod.mk.injEq]
  constructor
  · rintro ⟨h, rfl⟩
    exact ⟨t, h.symm, rfl, rfl⟩
  · rintro ⟨v, h, rfl, rfl⟩
    exact ⟨h.symm, rfl⟩

/-- Canonical length-two paths whose middle vertex is (u). -/
noncomputable def pathsAt (T : XTree X V) (u : V) : Finset (V × V × V) := by
  letI : DecidableEq V := Classical.decEq V
  exact T.canonicalLengthTwoPathFinset.filter (fun p => p.2.1 = u)

theorem centredSquares_eq_local_sums (u : V) (w : W) :
    centredSquares T₁ T₂ u w =
      (∑ t ∈ T₁.neighborFinset u, ∑ v ∈ T₂.neighborFinset w, qTerm T₁ T₂ (t, u) (v, w)) +
      (∑ t ∈ T₁.neighborFinset u, ∑ p ∈ pathsAt T₂ w, sTerm T₁ T₂ (t, u) p) +
      (∑ p ∈ pathsAt T₁ u, ∑ v ∈ T₂.neighborFinset w, bTerm T₁ T₂ p (v, w)) +
      (∑ p ∈ pathsAt T₁ u, ∑ q ∈ pathsAt T₂ w, pTerm T₁ T₂ p q) := by
  classical
  simp_rw [centredSquares, atCentres_eq_filtered, incomingEdges_eq_map, pathsAt,
    Finset.sum_map, incomingEdge, Function.Embedding.coeFn_mk]

theorem sum_centredSquares_eq :
    (∑ u : V, ∑ w : W, centredSquares T₁ T₂ u w) = sumOfSquaresRhs T₁ T₂ := by
  classical
  simp_rw [centredSquares, Finset.sum_add_distrib, sum_atCentres]
  simp_rw [sumOfSquaresRhs, qTerm, lemma3CoefficientSum, Finset.sum_mul]
  rfl

theorem centredSquares_nonneg (u : V) (w : W) : 0 ≤ centredSquares T₁ T₂ u w := by
  unfold centredSquares
  refine add_nonneg (add_nonneg (add_nonneg ?_ ?_) ?_) ?_
  · apply atCentres_nonneg
    intro e₁ _ e₂ he₂
    have hadj := (T₂.mem_directedEdgeFinset _ _).1 he₂
    apply mul_nonneg _ (sq_nonneg _)
    unfold lemma3CoefficientSum
    exact Finset.sum_nonneg fun z₁ _ => Finset.sum_nonneg fun z₂ _ =>
      qCoefficient_nonneg_of_adj T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2 hadj z₂.1 z₂.2
  · apply atCentres_nonneg
    intro e₁ _ p₂ hp₂
    have hadj := (T₂.mem_canonicalLengthTwoPathFinset _ _ _).1 hp₂
    apply Finset.sum_nonneg
    intro z₁ _
    exact mul_nonneg (qCoefficient_nonneg_of_adj T₁ T₂ e₁.1 e₁.2 z₁.1 z₁.2
      hadj.1 p₂.2.2 p₂.1) (sq_nonneg _)
  · apply atCentres_nonneg
    intro p₁ _ e₂ he₂
    have hadj := (T₂.mem_directedEdgeFinset _ _).1 he₂
    apply Finset.sum_nonneg
    intro z₂ _
    exact mul_nonneg (qCoefficient_nonneg_of_adj T₁ T₂ p₁.1 p₁.2.1
      p₁.2.2 p₁.1 hadj z₂.1 z₂.2) (sq_nonneg _)
  · apply atCentres_nonneg
    intro p₁ _ p₂ hp₂
    have hadj := (T₂.mem_canonicalLengthTwoPathFinset _ _ _).1 hp₂
    exact mul_nonneg (qCoefficient_nonneg_of_adj T₁ T₂ p₁.1 p₁.2.1
      p₁.2.2 p₁.1 hadj.1 p₂.2.2 p₂.1) (sq_nonneg _)

/-- The sum of the terms with at least one leaf centre. -/
noncomputable def leafCentredSquares : ℝ := by
  classical
  exact ∑ u : V, ∑ w : W, if T₁.IsLeaf u ∨ T₂.IsLeaf w then centredSquares T₁ T₂ u w else 0

/-- The sum over two internal centres. -/
noncomputable def internalCentredSquares : ℝ := by
  classical
  exact ∑ u : V, ∑ w : W, if T₁.IsLeaf u ∨ T₂.IsLeaf w then 0 else centredSquares T₁ T₂ u w

theorem internalCentredSquares_nonneg : 0 ≤ internalCentredSquares T₁ T₂ := by
  unfold internalCentredSquares
  refine Finset.sum_nonneg fun u _ => Finset.sum_nonneg fun w _ => ?_
  split_ifs
  · exact le_rfl
  · exact centredSquares_nonneg T₁ T₂ u w

theorem leaf_add_internalCentredSquares_eq :
    leafCentredSquares T₁ T₂ + internalCentredSquares T₁ T₂ = sumOfSquaresRhs T₁ T₂ := by
  classical
  rw [← sum_centredSquares_eq T₁ T₂]
  simp_rw [leafCentredSquares, internalCentredSquares, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun u _ => Finset.sum_congr rfl fun w _ => ?_
  split_ifs <;> simp

/-- The deficit identity before evaluating the leaf-centred terms. -/
theorem quartetBound_sub_distance_eq_centredSquares
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic) :
    quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) =
      (Fintype.card X : ℝ)^4 / 6 *
        (leafCentredSquares T₁ T₂ + internalCentredSquares T₁ T₂) := by
  classical
  rw [leaf_add_internalCentredSquares_eq, quartetBound_sub_distance_eq_sumOfSquares T₁ T₂ h₁ h₂]

/-- Once the leaf sum is evaluated, the one-sided shape bound follows
from the nonnegative internal square terms. -/
theorem quartetDeficit_ge_leafDistance_of_leaf_identity
    (h₁ : T₁.IsBinaryPhylogenetic) (h₂ : T₂.IsBinaryPhylogenetic)
    (hLeaf : (Fintype.card X : ℝ)^4 * leafCentredSquares T₁ T₂ = leafDistanceSum T₂) :
    leafDistanceSum T₂ / 6 ≤
      quartetBound (Fintype.card X) - (quartetDistance T₁ T₂ : ℝ) := by
  rw [quartetBound_sub_distance_eq_centredSquares T₁ T₂ h₁ h₂, ← hLeaf]
  have hpos := mul_nonneg
    (pow_nonneg (Nat.cast_nonneg (α := ℝ) (Fintype.card X)) 4)
    (internalCentredSquares_nonneg T₁ T₂)
  nlinarith only [hpos]

end

end CTV14
