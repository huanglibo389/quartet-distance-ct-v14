# CT v8 manuscript-to-Lean correspondence — 2026-09-30

Both current 28-page CT manuscripts are locked in `MANUSCRIPT_LOCK.md`.
The mathematics from Section 2 through the end of the Discussion is identical
to the PTRF v8 baseline at the byte level. Author/anonymous metadata and the
journal's automatic numbering differ; neither is a mathematical change.
Page locations below come from the compiled auxiliary files, matched to the
delivered PDF and TeX bytes. Stable labels and statement content control.

“Direct theorem” means a terminal declaration states the printed conclusion
after translating notation and definitions. “Exact theorem chain” means
several proved declarations establish it. Neither phrase claims a literal
line-by-line transcription of prose. All 14 numbered statements are mapped;
52 selected declarations, including the principal definitions, were resolved
and their types printed in the independent signature audit.

Legacy names are deliberately retained: old Theorem 2 is now Theorem 3.3,
old Corollary 3 is now Corollary 4.4, and `lemma3` declarations supporting
old Lemma 6 now support Lemma 3.10. Internal names do not dictate PDF numbering.

| Manuscript item | Current location | Lean declaration(s) | Coverage |
|---|---|---|---|
| Lemma 3.1 (displaying edges and length-two paths) | label `lem:display-path`; author: PDF p. 7, TeX label line 532; anonymous: PDF p. 7, TeX label line 524 | `QDFull.XTree.edge_mem_quartetPathSubgraph_iff_displays`, `quartetPathSubgraph_connected_of_edge`, `quartetPathLineGraph_isTree_of_edge`, `displayingLengthTwoPathFinset_eq_quartetPathPaths`, `card_displayingLengthTwoPathFinset_add_one_eq_edges` | Exact theorem chain, including the path and `k-1` count assertions |
| Theorem 3.2 (edge/path inclusion--exclusion) | label `thm:inclusion-exclusion`; author: PDF p. 7, TeX label line 551; anonymous: PDF p. 7, TeX label line 543 | `QDFull.treeQuartetCovariance_eq_six_mul_inclusionExclusionCovariance` | Direct theorem; Lean's four blocks use the normalised `1/6` convention |
| Theorem 3.3 (four-family sum of squares) | label `thm:sum-of-squares`; author: PDF p. 7, TeX label line 587; anonymous: PDF p. 7, TeX label line 579 | `QDFull.sumOfSquaresRhs_eq_treeQuartetCovariance_div_six`, with `qSquareFamily`, `sSquareFamily`, `bSquareFamily`, `pSquareFamily` | Direct theorem; the manuscript's `P_i` and Lean's canonical path finset both select one representative from each reversal orbit |
| Lemma 3.4 (matrix identity) | label `lem:matrix-identity`; author: PDF p. 8, TeX label line 613; anonymous: PDF p. 8, TeX label line 605 | `QDTauStar.matrix_identity` | Direct theorem |
| Lemma 3.5 (partial-quartet reconstruction) | label `lem:partial-reconstruction`; author: PDF p. 14, TeX label line 1074; anonymous: PDF p. 14, TeX label line 1066 | `QDFull.XTree.displays_compl_split_of_all_partialQuartet_restrictions`, `edgeSplitSet_eq_of_same_partialQuartet_system`, `labelPreservingXTreeIsoOfSamePartialQuartetSystem`, `isBinaryPhylogenetic_of_all_three_and_four_partialQuartets_displayed` | Exact theorem chain; the last declaration packages the printed three- and four-taxon hypotheses into the binary-phylogenetic conclusion |
| Lemma 3.6 (vertex--side independence bridge) | label `lem:vertex-side-bridge`; author: PDF p. 14, TeX label line 1129; anonymous: PDF p. 14, TeX label line 1121 | `QDFull.vertexJointMass_eq_printed_cardinality`, `QDFull.vertexVariablesIndependent_iff_treesIndependent`, `QDFull.exists_positive_vertex_side_witness_of_not_treesIndependent` | Exact theorem chain |
| Corollary 3.7 (bounds and equality cases for `Q`) | label `cor:Q-bounds`; author: PDF p. 15, TeX label line 1183; anonymous: PDF p. 15, TeX label line 1175 | `QDFull.treeQuartetCovariance_nonneg`, `treeQuartetCovariance_le_universal_bound`, `treeQuartetCovariance_eq_zero_iff_treesIndependent`, `treeQuartetCovariance_eq_universal_bound_iff_identical` | Exact theorem chain for the manuscript's `card(X) >= 4` equality statement |
| Lemma 3.8 (quartet-count formula) | label `lem:Q-counts`; author: PDF p. 16, TeX label line 1226; anonymous: PDF p. 16, TeX label line 1218 | `QDFull.treeQuartetCovariance_eq_quartetCounts` | Direct theorem |
| Corollary 3.9 (finite two-thirds bound) | label `cor:two-thirds`; author: PDF p. 16, TeX label line 1251; anonymous: PDF p. 16, TeX label line 1243 | `QDFull.quartetDistance_le_twoThirds_bound` | Direct theorem |
| Lemma 3.10 (coefficient and global lower bounds) | label `lem:coefficient-lower-bound`; author: PDF p. 17, TeX label line 1291; anonymous: PDF p. 17, TeX label line 1283 | `QDFull.lemma3_coefficient_lower_bound`, `lemma3GlobalLowerBound`, `lemma3ScaledLowerBound_le_qSquareFamily`, `lemma3_global_split_covariance_lower_bound` | Exact theorem chain; the `lemma3` identifiers are legacy names |
| Proposition 4.1 (quartet compatibility index) | label `prop:compatibility`; author: PDF p. 18, TeX label line 1429; anonymous: PDF p. 18, TeX label line 1421 | `QDFull.XTree.IsNontrivial`, `commonDisplayedPartialQuartets_two_nonempty_of_adj`, `quartetCompatibilityDenominator_pos_of_nontrivial`, `quartetCompatibilityIndex_mem_unitInterval`, `quartetCompatibilityIndex_eq_zero_iff_treesIndependent`, `quartetCompatibilityIndex_eq_one_iff_splitUnionCompatible_of_nontrivial` | Exact theorem chain in the manuscript's non-trivial-tree domain; the positivity proof formalises the common support-two partial-quartet argument |
| Proposition 4.2 (quartet correlation) | label `prop:correlation`; author: PDF p. 19, TeX label line 1457; anonymous: PDF p. 19, TeX label line 1449 | `QDFull.quartetCorrelation_bounds`, `quartetCorrelation_eq_zero_iff_treesIndependent`, `positive_equal_quartet_indices_iff_labelPreservingIso_and_positive`, `quartetCorrelation_eq_one_of_labelPreservingIso_and_positive` | Exact theorem chain |
| Theorem 4.3 (tree and empirical distance covariance) | label `thm:tree-distance-covariance`; author: PDF p. 21, TeX label line 1585; anonymous: PDF p. 21, TeX label line 1577 | `QDFull.WeightedApplications.treeDistanceCovariance_eq_threeHalves_empirical` | Direct theorem |
| Ordered-four-draw length weighting equals the explicit edge-pair definition | label `thm:tree-distance-covariance`; author: PDF p. 21, TeX label line 1585; anonymous: PDF p. 21, TeX label line 1577 The preceding definitions are in the same subsection. | `QDFull.WeightedApplications.weightedTreeDrawContribution_eq_of_sameWitness`, `weightedTreeDrawContribution_eq_of_differentWitness`, `weightedTreeDrawContribution_eq_zero_of_noTreeEvent`, `weightedTreeDrawContribution_eq_edgePairSum`, `weightedFourDrawCovariance_eq_treeDistanceCovariance` | Added 2026-09-05: the source independently defines the weighted draw contribution, verifies all event cases, and proves pointwise edge expansion followed by finite averaging; repeated taxa and absent displayed patterns are included |
| Theorem 4.3 starting from the ordered-four-draw definition | label `thm:tree-distance-covariance`; author: PDF p. 21, TeX label line 1585; anonymous: PDF p. 21, TeX label line 1577 Uses the preceding ordered-four-draw definition. | `QDFull.WeightedApplications.weightedFourDrawCovariance_eq_threeHalves_empirical` | Added 2026-09-05: the weighted draw definition equals three halves of empirical distance covariance squared, through the newly proved bridge |
| Corollary 4.4 (strict positivity under dependence) | label `cor:tau-star`; author: PDF p. 22, TeX label line 1712; anonymous: PDF p. 22, TeX label line 1704 | `QDTauStar.populationTauStar_pos_of_not_coordinatesIndependent` | Direct theorem for every Borel probability law on `Real × Real` |
| Quantitative inequality `tau-star >= 2 BKR` | label `eq:tau-star-BKR-lower-bound`; author: PDF p. 23, TeX label line 1729; anonymous: PDF p. 23, TeX label line 1721 | `QDTauStar.two_bkrDiscrepancy_le_populationTauStar` | Direct theorem for every Borel probability law on `Real × Real` |
| Finite-support strictness from a nonzero interior CDF discrepancy | label `eq:finite-tau-BKR`; author: PDF p. 24, TeX label line 1826; anonymous: PDF p. 24, TeX label line 1818 Strictness is discussed immediately after this bound. | `QDTauStar.finiteTable_tauStar_gt_two_bkr_of_delta_ne_zero`, `finiteTable_tauStar_eq_two_bkr_implies_delta_eq_zero` | Direct finite-table theorems: a nonzero interior CDF discrepancy makes the inequality strict, and equality forces every interior discrepancy to vanish |
| `tau-star = 0` if and only if independence | label `cor:tau-star`; author: PDF p. 22, TeX label line 1712; anonymous: PDF p. 22, TeX label line 1704 Also stated in the abstract and introduction. | `QDTauStar.populationTauStar_eq_zero_iff_coordinatesIndependent` | Direct theorem at the level of the joint law; `CoordinatesIndependent` means equality of the joint law and the product of its marginals |
| Asymptotic two-thirds conclusion | label `cor:two-thirds`; author: PDF p. 16, TeX label line 1251; anonymous: PDF p. 16, TeX label line 1243 Also stated in the abstract and following sharpness discussion. | `QDFull.quartetDistance_le_twoThirds_bound`; `QDFull.PhyloSyntaxBridge.realizedNormalizedMaximum_tendsto_two_thirds` | Exact finite upper bound for binary phylogenetic `XTree`s, plus a sharp-limit theorem for the explicitly realised syntax-tree model |

## Domains, definitions and qualifications checked

- `XTree` is a general finite vertex-labelled tree with the required
  low-degree labelling condition, not a restriction to caterpillars or binary
  trees. Binary hypotheses are used where the manuscript requires them.
  Finite linear orders choose edge/path representatives; they are not a
  restriction on tree shapes. Nonempty taxa follow from the tree hypotheses.
- Quartet probabilities use ordered draws with replacement, with denominator
  `card(X)^4`. Common and different quartet events have weights 1 and -1/2.
  The four-family sum of squares represents Q/6. Canonical length-two paths
  select one orientation per reversal orbit, matching the printed P_i.
- Reconstruction preserves labels. The upper equality case has the printed
  cardinality-at-least-four condition. Compatibility is compared on the
  nontrivial-tree domain, where the denominator is proved positive. Positive
  self-covariances accompany the correlation equality statements.
- The weighted definition bridge is included: independently defined
  four-draw contributions have proved same/different/absent event cases,
  a pointwise edge-pair expansion, and the averaged identity. Thus Theorem
  4.3 is covered from the verbal weighted-draw definition, not only from the
  explicit edge sum. Positive edge lengths match the manuscript convention.
- The sign kernel uses strict middle cuts and retains ties. `populationTauStar`
  is a fourfold joint-law integral. `bkrDiscrepancy` integrates the squared
  CDF discrepancy against the product of the marginals, not the joint law.
  `CoordinatesIndependent` is equality to that product measure. The arbitrary
  law inequality and zero-characterisation need no density, continuity or
  moment hypotheses and do not assume the desired main conclusion.
- Finite strictness is represented through a nonzero interior CDF discrepancy
  for a nonnegative, normalised finite table after zero-marginal rows/columns
  are removed. `PositiveMassSupport p` is the subtype of positive cells;
  its supplied inhabitant is a positive cell, not an assumed inequality.
  This finite strictness result is not needed for Corollary 4.4.

## Explicit formal-scope boundaries

The manuscript's g_k and h_k rank occupied cells and choose zero on empty
cells. Lean instead uses the globally measurable full-partition `dyadicRank`.
These are not pointwise identical functions: on occupied cells their ranks
are related by increasing relabelling, and sampled points almost surely lie
in positive-mass cells. The existing Lean proof establishes the requisite
weak-order and limit results for its own quantizers and the same arbitrary-law
terminal theorems. This release does NOT add or claim a theorem identifying
the paper's g_k pointwise with Lean's rank function. This is an alternative
internal proof realisation, not a missing placeholder in the main theorem.

The general finite two-thirds bound is proved for binary phylogenetic XTrees.
The additional sharp-limit theorem uses the explicitly realised syntax-tree
model indicated in the table; it is not a separate certification of every
possible encoding of all tree isomorphism classes. Literature comparisons,
historical priority, references, prose and editorial assertions are outside
the kernel-checked scope. Successful compilation alone does not certify the
informal-to-formal translation; the correspondence review is a separate check.

Regression files with `Counterexample` in their names retain tests of earlier
incorrect formulations. Their presence does not assert a counterexample to
the current canonical-path sum-of-squares statement.
