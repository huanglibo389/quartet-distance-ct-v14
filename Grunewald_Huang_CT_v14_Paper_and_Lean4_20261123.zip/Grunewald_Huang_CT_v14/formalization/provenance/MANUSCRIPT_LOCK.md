# CT v8 manuscript lock — 2026-09-30

Title: *A Sum-of-Squares Decomposition for Quartet Covariance: Bivariate
Independence and Quartet Distance*.
Authors: Stefan Grünewald and Libo Huang. Target: *Combinatorial Theory*.
Both author and anonymous variants have 28 PDF pages. Relative paths below
are from the CT manuscript delivery folder. Manuscripts are delivered
separately, not duplicated in this source supplement.

| Manuscript file | SHA-256 |
|---|---|
| `Author_Copy/manuscript.tex` | `74ba5a6c4d59c9d98c291ceee0d8e19adebddab732a93acd2019cbd0d859ea74` |
| `Author_Copy/references.bib` | `9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8` |
| `Author_Copy/ct.sty` | `9c3a18dccb1ee260665c542955f74450d5fcc2b013d5227b409f477d68e06e50` |
| `Author_Copy/manuscript.bbl` | `3b63c671f3b0e289f6400fbf2dbc0a887b8ba44ff18d64066ba58e3aa5b11741` |
| `CT_v8_Author_Copy.pdf` | `3ac921012616b623417bcb31093afd825ee29896dcc6834fda25efe5b73489cb` |
| `Anonymous_Submission/manuscript.tex` | `dada0c08d347a61903cb0e76f87ab2ed5a5b9387e949b77c8b76de65bf2b74a3` |
| `Anonymous_Submission/references.bib` | `9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8` |
| `Anonymous_Submission/ct.sty` | `9c3a18dccb1ee260665c542955f74450d5fcc2b013d5227b409f477d68e06e50` |
| `Anonymous_Submission/manuscript.bbl` | `3b63c671f3b0e289f6400fbf2dbc0a887b8ba44ff18d64066ba58e3aa5b11741` |
| `CT_v8_Anonymous_Submission.pdf` | `88e96e233a4346e61b115d6e44b1ec7a2bb709eea7f9460110ee1e3d2483d937` |

## Mathematical-content identity and proof-source provenance

The complete mathematical source substring beginning with Section 2
(`Tree and quartet covariance framework`) and ending immediately before the
PTRF `backmatter` command occurs byte-for-byte in both CT manuscripts.
Its SHA-256 is `769f652021bbe9dfdfea2c5702625fe82f76a8cbdb39852ee17506808265a618`.
All 14 numbered statements and all 14 proof environments were also compared
individually, as were all equation/align/gather environments, including
unnumbered variants. They are identical to the PTRF source.

The source baseline is `Grunewald_Huang_PTRF_v8.tex`, SHA-256
`b691af256df8edb11503ddcc47c01bc88977d97af3b4447b814105517cf9b1ce`. This includes the 2026-09-05 zero-mass-cell wording.
All 142 Lean source files, dependency lock files and licences are byte-for-byte
unchanged from the integrated 2026-09-05 supplement, including the completed
weighted-draw bridge. Only alignment, audit and release documentation changes.
The prior PTRF documentation is preserved under `history/PTRF_20260905/`;
its old page references and old hashes are historical, not current locks.

Current build and axiom checks were rerun, not inferred from historical logs.
See `BUILD_AND_AUDIT.md` and `THEOREM_CORRESPONDENCE.md`. If a locked file
changes, recheck the correspondence and refresh its hash before submission.
