# v14 manuscript-to-Lean correspondence

## Sources

| Source | Identifier |
| --- | --- |
| v14 `Grunewald_Huang_CT_v14.tex`, 22 November 2026 | SHA-256 `43d922241dca693a14fd99f329f6f808a2ea1d7373241f53cc369534e62500f2` |
| v14 PDF from the same directory | SHA-256 `6ea7b3d5195b2a7dffb54a7d67bb7938b1b7bd501300ad872c91b96cb90fab2a` |
| v8 editorial author TeX, 16 November 2026 | SHA-256 `119ee0427a00923a0808033376516a340542c45ed61d1dc07c8f3a8072427` |
| Desktop v8 supplement, 30 September 2026 | `Grunewald_Huang_CT_v8_20260930/Lean_Alignment_20260930/CT_v8_Lean4_Supplement` |

Sections 2–4 of v14 agree with the v8 editorial author TeX after
removing terminal whitespace at the section boundary. This includes
all fourteen numbered statements. The desktop supplement is the
source of the original Lean modules and their pins. Replaying the
52 signature checks and ten definition printouts in this project
produces the same output as the v8 audit. The more detailed
statement and scope notes are preserved in
[`provenance/THEOREM_CORRESPONDENCE.md`](provenance/THEOREM_CORRESPONDENCE.md).

## Sections 2–4

| v14 item and stable TeX label | Principal Lean declaration or theorem chain |
| --- | --- |
| Lemma 3.1, `lem:display-path` | `XTree.edge_mem_quartetPathSubgraph_iff_displays`, `quartetPathSubgraph_connected_of_edge`, `quartetPathLineGraph_isTree_of_edge`, `displayingLengthTwoPathFinset_eq_quartetPathPaths`, `card_displayingLengthTwoPathFinset_add_one_eq_edges` |
| Theorem 3.2, `thm:inclusion-exclusion` | `treeQuartetCovariance_eq_six_mul_inclusionExclusionCovariance` |
| Theorem 3.3, `thm:sum-of-squares` | `sumOfSquaresRhs_eq_treeQuartetCovariance_div_six`, with `qSquareFamily`, `sSquareFamily`, `bSquareFamily`, `pSquareFamily` |
| Lemma 3.4, `lem:matrix-identity` | `QDTauStar.matrix_identity` |
| Lemma 3.5, `lem:partial-reconstruction` | `XTree.displays_compl_split_of_all_partialQuartet_restrictions`, `edgeSplitSet_eq_of_same_partialQuartet_system`, `labelPreservingXTreeIsoOfSamePartialQuartetSystem`, `isBinaryPhylogenetic_of_all_three_and_four_partialQuartets_displayed` |
| Lemma 3.6, `lem:vertex-side-bridge` | `vertexJointMass_eq_printed_cardinality`, `vertexVariablesIndependent_iff_treesIndependent`, `exists_positive_vertex_side_witness_of_not_treesIndependent` |
| Corollary 3.7, `cor:Q-bounds` | `treeQuartetCovariance_nonneg`, `treeQuartetCovariance_le_universal_bound`, `treeQuartetCovariance_eq_zero_iff_treesIndependent`, `treeQuartetCovariance_eq_universal_bound_iff_identical` |
| Lemma 3.8, `lem:Q-counts` | `treeQuartetCovariance_eq_quartetCounts` |
| Corollary 3.9, `cor:two-thirds` | `quartetDistance_le_twoThirds_bound` |
| Lemma 3.10, `lem:coefficient-lower-bound` | `lemma3_coefficient_lower_bound`, `lemma3GlobalLowerBound`, `lemma3ScaledLowerBound_le_qSquareFamily`, `lemma3_global_split_covariance_lower_bound` |
| Proposition 4.1, `prop:compatibility` | `quartetCompatibilityDenominator_pos_of_nontrivial`, `quartetCompatibilityIndex_mem_unitInterval`, `quartetCompatibilityIndex_eq_zero_iff_treesIndependent`, `quartetCompatibilityIndex_eq_one_iff_splitUnionCompatible_of_nontrivial` |
| Proposition 4.2, `prop:correlation` | `quartetCorrelation_bounds`, `quartetCorrelation_eq_zero_iff_treesIndependent`, `positive_equal_quartet_indices_iff_labelPreservingIso_and_positive`, `quartetCorrelation_eq_one_of_labelPreservingIso_and_positive` |
| Theorem 4.3, `thm:tree-distance-covariance` | `WeightedApplications.weightedFourDrawCovariance_eq_treeDistanceCovariance` and `weightedFourDrawCovariance_eq_threeHalves_empirical` |
| Corollary 4.4, `cor:tau-star` | `QDTauStar.populationTauStar_pos_of_not_coordinatesIndependent`, `populationTauStar_eq_zero_iff_coordinatesIndependent`, `two_bkrDiscrepancy_le_populationTauStar` |

Unqualified v8 names above are in `QDFull` or the subnamespace indicated
in the original map. The ordered-four-draw bridge in Theorem 4.3 and
the arbitrary Borel law formulation for sign covariance are included.
The previous sharp-limit theorem is stated for graphs realized from
the v8 syntax trees. The v14 maximum below is defined directly using
all finite binary `XTree` pairs on `Fin n`.

## Section 5

| v14 item | Lean correspondence | Scope |
| --- | --- | --- |
| Reference bound $U_n$ | `QuartetDeficit.lean`: `quartetBound_eq_polynomial`, `quartetBound_sub_distance_eq_covariance` | Exact on the original quartet distance and covariance |
| $F_{u,w}$ and the leaf table | `CentredSquares.lean`, `PendantSquares.lean`, `MixedLeafSquares.lean`, `BranchMoments.lean`, `ShapeBound.lean`: `scaled_leafCentredSquares_eq_leafDistance` | All three leaf rows. The branch-pair and branch-triple sums are evaluated on the original graph trees |
| Deficit identity, `eq:binary-deficit` | `ShapeBound.lean`: `binaryDeficitFormula` | Exact identity with $W(T_2)/6$ and the internal contribution |
| Theorem 5.1, `thm:shape-bound` | `ShapeBound.lean`: `quartetDistance_le_shape_bound` | The printed maximum of $W(T_1)$ and $W(T_2)$, for arbitrary binary phylogenetic pairs |
| Theorem 5.2, lower inequality | `LeafDistance.lean`: `sum_leaf_half_pow_dist`, `leafDistanceSum_lower`. `MaximumDeficit.lean`: `maximumQuartetDistance_attained`, `log_lower_le_maximumQuartetDeficit` | The printed constant and logarithm, for all $n\ge4$ |
| Internal coefficients, `eq:internal-coefficients` | `InternalBranchTable.lean`: `centredSquares_eq_internalCoefficients` | Actual $F_{u,w}$, for any enumeration of each set of three neighbours |
| Local upper estimate for Theorem 5.2 | `LocalUpperBound.lean`: `centredSquares_le_childMasses` | $F_{u,w}\le378psZ^2$ under positive, balanced column masses and the stated bound on $B$ or the single occupied child-cell condition |
| Residue intersection counts for Theorem 5.2 | `ResidueCounts.lean`: `card_range_filter_mod`, `card_Ico_filter_mod_aligned`, `card_Ico_filter_mod`, `abs_card_Ico_filter_mod_sub_length_div_le_one` | Exact counts and the error at most one for arbitrary intervals |
| Depth-block upper estimates | `DepthBlockEstimates.lean`. `highDepthBlock_le`, `lowDepthBlock_le` | Finite sum bounds from the parent mass, joint mass and contrast estimates |
| Theorem 5.2, upper inequality | `DepthSummation.lean`: `maximumQuartetDeficit_le_of_depth_estimates` | Conditional on an actual tree pair meeting the diameter, original-depth and per-depth square bounds |

The remaining obligation for the upper inequality is to construct the
two trees for each $n\ge4$, identify their graph branches with the
truncated prefix intervals and suffix residue classes, and prove the
depth-block hypotheses for that pair. The asymptotic two-sided order
in the abstract therefore remains outside the verified coverage.

The relabelling mean is verified in `RelabellingMean.lean` for independent
finite laws on the v8 syntax-tree model when either law is exchangeable
under relabelling.

## Verification

- [Source and dependency alignment](verification/source-alignment.log)
- [Integrated build](verification/integrated-build.log)
- [Axiom audit with selected v14 signatures](verification/axiom-audit.log)
- [v8 signatures printed in the v14 environment](verification/v8-signatures.log).
  Reproduce with `lake env lean verification/V8Signatures.lean`.

The shape-bound proof uses the paper's coefficients and exact table.
It obtains the graph branch moments by summing over the two
orientations of each tree edge, which gives the same values as the
leaf-pair and median counting arguments in the manuscript.
