# Quartet covariance — CT v14

Stefan Grünewald and Libo Huang. Manuscript dated 22 November 2026.

- [Paper PDF](paper/Grunewald_Huang_CT_v14.pdf)
- [LaTeX source](paper/Grunewald_Huang_CT_v14.tex), with the CT style and bibliography in the same directory
- [Lean 4 supplement](formalization/README.md) and [manuscript correspondence](formalization/FORMALIZATION_MAP.md)
- [SHA-256 file manifest](SHA256SUMS)

The supplement retains the v8 formalization for Sections 2–4 and extends it through
Theorem 5.1 and the lower inequality of Theorem 5.2. The upper inequality of
Theorem 5.2 remains conditional on constructing the prefix and suffix trees
and verifying their per-depth estimates.

## Build the Lean supplement

With Elan available, run from the package directory.

```sh
cd formalization
lake exe cache get
lake --no-cache build
lake env lean verification/AxiomAudit.lean
lake env lean verification/V8Signatures.lean
```

The toolchain and mathlib revision are fixed in `lean-toolchain` and
`lake-manifest.json`. The original code and third-party licenses are in
the [formalization directory](formalization/).

## Rebuild the PDF

The paper directory includes the bibliography used for the supplied PDF.
Run from the package directory with Tectonic 0.17.0 available.

```sh
cd paper
tectonic --keep-logs --keep-intermediates Grunewald_Huang_CT_v14.tex
```

## License

The author-written Lean 4 code uses the [MIT License](LICENSE). The
manuscript retains its authors’ copyright. [Third-party notices](formalization/THIRD_PARTY_NOTICES.md)
cover the vendored code.
