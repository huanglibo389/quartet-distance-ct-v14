# Fresh CT alignment build and audit — 2026-09-30

## Environment and actual rebuild

Lean v4.32.0; mathlib commit `81a5d257c8e410db227a6665ed08f64fea08e997`.
All nine external dependency HEADs match the unchanged manifest, with no
tracked source modifications. Existing pinned external dependency caches
were reused. No web search, dependency download, cache-fetch command or
dependency update was performed. This does not claim an OS-level network lock.

The new project's local `.lake/build` did not exist when the check started.
The pinned Lake executable ran:

```text
lake --no-cache build BernoulliSupplementAudit QuartetDistance
```

**Exit 0; Build completed successfully (8798 jobs); 234.55 seconds.** All 142
local Lean files are reachable from these roots and all 142 corresponding
modules appear as freshly built, not replayed. The job count includes external
dependency jobs; it is not a count of new mathematical theorems. There were
332 existing non-fatal style/linter warnings, no compilation errors.

## Source and transitive-dependency audits

All 142 Lean files / 53,709 lines were scanned, stripping nested comments and
string literals. There are zero active occurrences of `sorry`, `admit`,
`sorryAx`, `axiom`, `constant`, `opaque`, `unsafe`, or `native_decide`.
Four literal `axiom` occurrences are comments. No literal `sorry` occurs.
All proof-file hashes equal those of the original integrated supplement.

A separate Lean command enumerated every declaration from the local proof
modules, including private/generated declarations, and collected transitive
axiom dependencies, not merely those of the advertised main theorems:

```text
AUDIT_TOTAL declarations=6226 theorems=4507 declaration_bearing_modules=137 unexpected=0
```

Exit 0, 72.46 seconds. Every dependency set is a subset of
`{propext, Classical.choice, Quot.sound}`. In particular there is no
`sorryAx` dependency and no additional assumed theorem. The 137 figure counts
modules that introduce declarations; aggregator/audit modules need not do so.
This is not foundational axiom-freeness and does not eliminate trust in the
Lean kernel/toolchain or the informal-to-formal correspondence review.

The independent statement audit printed 52 selected declaration types and
10 central definitions/structures; exit 0, 3.60 seconds. The release's own
27 terminal `#print axioms` commands also ran in the successful build.

## Manuscript and archive checks

Both CT manuscript variants match the mathematical body of the PTRF v8 source
byte-for-byte; all 14 numbered statement environments and 14 proof environments
were separately compared. Numbering and current TeX/PDF locations were taken
from the compiled CT files, not copied from PTRF. Hashes include both PDF and
TeX variants plus bibliography/style inputs. See the CT v8 section of `MANUSCRIPT_LOCK.md`.

The clean archive excludes `.lake`, symlinks and generated proof objects.
After packaging, it is reopened, CRC-tested, and every entry compared against
the release source and its `SHA256SUMS` entry. Exact file counts and ZIP digest
are recorded in the external `RELEASE_CHECK.json`, avoiding self-referential
checksums. The separate evidence ZIP retains full logs and audit source.

No manuscript text or formal proof was edited and no external submission was
made. Prior dated records are retained explicitly as historical provenance.
