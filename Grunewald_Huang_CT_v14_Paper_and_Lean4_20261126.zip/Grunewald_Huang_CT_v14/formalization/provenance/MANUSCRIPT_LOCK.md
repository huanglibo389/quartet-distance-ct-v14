# Manuscript lock

## CT v14 — 26 November 2026

*A Sum-of-Squares Decomposition for Quartet Covariance: Quartet Distance and
Bivariate Independence*, Stefan Grünewald and Libo Huang. The signed PDF has
30 pages and includes the Lean repository link under Code availability.

| Packaged manuscript file | SHA-256 |
| --- | --- |
| [Grunewald_Huang_CT_v14.tex](../../paper/Grunewald_Huang_CT_v14.tex) | `8d1ae1be4c9e1b376d9b30f1bca999e3fac220039a7dad8070d29cd1b9ff075f` |
| [Grunewald_Huang_CT_v14.pdf](../../paper/Grunewald_Huang_CT_v14.pdf) | `e43dc66482aae9a92e23f957bc31502275f77fc483e8e054f359dfe67a364a0f` |
| [ct.sty](../../paper/ct.sty) | `9c3a18dccb1ee260665c542955f74450d5fcc2b013d5227b409f477d68e06e50` |
| [references.bib](../../paper/references.bib) | `7870152229a45078372c1dd936a371a0b7cd7f0f709c572f63ff4c1749fc25d6` |
| [Grunewald_Huang_CT_v14.bbl](../../paper/Grunewald_Huang_CT_v14.bbl) | `1b41a27ca25983e53bcbfe3b4f55deb9c064ee841785e015d2a450161da2de34` |

The source from Section 2 through the end of Section 5, with trailing
whitespace removed, has SHA-256 `1de33c773d69b615600a24b5186a4f9987948bb9fae551c6d388ae90853c6d9f`. It is byte-identical
to that part of the 22 November v14 manuscript. The
[correspondence map](../FORMALIZATION_MAP.md) records the Lean declarations
and their hypotheses. The verification logs in `../verification/` record the
build, signature check and axiom audit for this package.

## CT v8 baseline — 30 September 2026

The following lock records the original v8 supplement and manuscript files.

Title: *A Sum-of-Squares Decomposition for Quartet Covariance: Bivariate
Independence and Quartet Distance*.
Authors: Stefan Grünewald and Libo Huang. Target: *Combinatorial Theory*.
Both author and anonymous variants have 28 PDF pages. Relative paths below
are from the CT manuscript delivery folder. Manuscripts are delivered
separately, not duplicated in this source supplement.

| Manuscript file | SHA-256 |
|---|---|
| `Author_Copy/manuscript.tex` | `74ba5a6c4d59c9d98c291ceee0d8e19adebddab732a93acd2019cbd0d859ea74` |
| `Author_Copy/references.bib` | `9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8` |
| `Author_Copy/ct.sty` | `9c3a18dccb1ee260665c542955f74450d5fcc2b013d5227b409f477d68e06e50` |
| `Author_Copy/manuscript.bbl` | `3b63c671f3b0e289f6400fbf2dbc0a887b8ba44ff18d64066ba58e3aa5b11741` |
| `CT_v8_Author_Copy.pdf` | `3ac921012616b623417bcb31093afd825ee29896dcc6834fda25efe5b73489cb` |
| `Anonymous_Submission/manuscript.tex` | `dada0c08d347a61903cb0e76f87ab2ed5a5b9387e949b77c8b76de65bf2b74a3` |
| `Anonymous_Submission/references.bib` | `9082a66ab956dc4abed7c2a478127cb1ea274d9dc0a7eebca674f0e091e18df8` |
| `Anonymous_Submission/ct.sty` | `9c3a18dccb1ee260665c542955f74450d5fcc2b013d5227b409f477d68e06e50` |
| `Anonymous_Submission/manuscript.bbl` | `3b63c671f3b0e289f6400fbf2dbc0a887b8ba44ff18d64066ba58e3aa5b11741` |
| `CT_v8_Anonymous_Submission.pdf` | `88e96e233a4346e61b115d6e44b1ec7a2bb709eea7f9460110ee1e3d2483d937` |

### Mathematical-content identity and proof-source provenance

The complete mathematical source substring beginning with Section 2
(`Tree and quartet covariance framework`) and ending immediately before the
PTRF `backmatter` command occurs byte-for-byte in both CT manuscripts.
Its SHA-256 is `769f652021bbe9dfdfea2c5702625fe82f76a8cbdb39852ee17506808265a618`.
All 14 numbered statements and all 14 proof environments were also compared
individually, as were all equation/align/gather environments, including
unnumbered variants. They are identical to the PTRF source.

The source baseline is `Grunewald_Huang_PTRF_v8.tex`, SHA-256
`b691af256df8edb11503ddcc47c01bc88977d97af3b4447b814105517cf9b1ce`. This includes the 2026-09-05 zero-mass-cell wording.
All 142 Lean source files, dependency lock files and licences are byte-for-byte
unchanged from the integrated 2026-09-05 supplement, including the completed
weighted-draw bridge. Only alignment, audit and release documentation changes.
The prior PTRF documentation is preserved under `history/PTRF_20260905/`;
its old page references and old hashes are historical, not current locks.

Current build and axiom checks were rerun, not inferred from historical logs.
See `BUILD_AND_AUDIT.md` and `THEOREM_CORRESPONDENCE.md`. If a locked file
changes, recheck the correspondence and refresh its hash before submission.
